//
//  adminSideMenu.swift
//  Hoopoe
//
//  Created by PRK on 2/25/17.
//  Copyright © 2017 rising. All rights reserved.
//

import Foundation
import UIKit

protocol SideMenuViewDelegate {
    
    func onTapEditProfileButton(sender:AnyObject) -> Void
    func onTapPotentialMatchesButton(sender: AnyObject) -> Void
    func onTapMatchSettingsButton(sender: AnyObject) -> Void
    func onTapLogoutButton(sender:AnyObject) -> Void
    func onTapMatchesButton(sender: AnyObject) -> Void
    func onTapChatsListButton(sender: AnyObject) -> Void
}

class adminSideMenu: UIViewController{
    

    var delegate: SideMenuViewDelegate?
    
    @IBOutlet weak var imageCover: UIImageView!
    @IBOutlet weak var buttonAvatar: UIButton!    
    @IBOutlet weak var textUserName: UILabel!
    
    
    
    
    @IBOutlet weak var imageEditProfile: UIImageView!
    @IBOutlet weak var btnEditProfile: UIButton!
    
    @IBOutlet weak var imagePotential: UIImageView!
    @IBOutlet weak var btnPotential: UIButton!
    
    @IBOutlet weak var imageChat: UIImageView!
    @IBOutlet weak var btnChat: UIButton!
    
    @IBOutlet weak var imageMatch: UIImageView!
    @IBOutlet weak var btnMatch: UIButton!
    
    @IBOutlet weak var imageSetting: UIImageView!
    @IBOutlet weak var btnSetting: UIButton!
    
    
    func RedAnimation() {
        
        switch curSel {
        case 0:
            
            btnEditProfile.setTitleColor(.black, for: .normal)
            btnPotential.setTitleColor(.black, for: .normal)
            btnChat.setTitleColor(.black, for: .normal)
            btnMatch.setTitleColor(.black, for: .normal)
            btnSetting.setTitleColor(.black, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile.jpg") //menu_icon_profile.jpg
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch.jpg") //menu_icon_potenMatch.jpg
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_chat.jpg") //menu_icon_chat.jpg
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match.jpg") //menu_icon_match.jpg
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting.jpg") //menu_icon_setting.jpg
            
        case 1:
            btnEditProfile.setTitleColor(.red, for: .normal)
            btnPotential.setTitleColor(.black, for: .normal)
            btnChat.setTitleColor(.black, for: .normal)
            btnMatch.setTitleColor(.black, for: .normal)
            btnSetting.setTitleColor(.black, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile_red.png") //red
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch.jpg") //menu_icon_potenMatch.jpg
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_chat.jpg") //menu_icon_chat.jpg
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match.jpg") //menu_icon_match.jpg
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting.jpg") //menu_icon_setting.jpg
            
        case 2:
            btnEditProfile.setTitleColor(.black, for: .normal)
            btnPotential.setTitleColor(.red, for: .normal)
            btnChat.setTitleColor(.black, for: .normal)
            btnMatch.setTitleColor(.black, for: .normal)
            btnSetting.setTitleColor(.black, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile.jpg") //menu_icon_profile.jpg
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch_red.png") //red
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_chat.jpg") //menu_icon_chat.jpg
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match.jpg") //menu_icon_match.jpg
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting.jpg") //menu_icon_setting.jpg

        case 3:
            btnEditProfile.setTitleColor(.black, for: .normal)
            btnPotential.setTitleColor(.black, for: .normal)
            btnChat.setTitleColor(.red, for: .normal)
            btnMatch.setTitleColor(.black, for: .normal)
            btnSetting.setTitleColor(.black, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile.jpg") //menu_icon_profile.jpg
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch.jpg") //menu_icon_potenMatch.jpg
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_match_red.png") //red
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match.jpg") //menu_icon_match.jpg
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting.jpg") //menu_icon_setting.jpg

        case 4:
            btnEditProfile.setTitleColor(.black, for: .normal)
            btnPotential.setTitleColor(.black, for: .normal)
            btnChat.setTitleColor(.black, for: .normal)
            btnMatch.setTitleColor(.red, for: .normal)
            btnSetting.setTitleColor(.black, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile.jpg") //menu_icon_profile.jpg
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch.jpg") //menu_icon_potenMatch.jpg
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_chat.jpg") //menu_icon_chat.jpg
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match_red.png") //red
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting.jpg") //menu_icon_setting.jpg
            
        case 5:
            btnEditProfile.setTitleColor(.black, for: .normal)
            btnPotential.setTitleColor(.black, for: .normal)
            btnChat.setTitleColor(.black, for: .normal)
            btnMatch.setTitleColor(.black, for: .normal)
            btnSetting.setTitleColor(.red, for: .normal)
            
            imageEditProfile.image    = #imageLiteral(resourceName: "menu_icon_profile.jpg") //menu_icon_profile.jpg
            imagePotential.image      = #imageLiteral(resourceName: "menu_icon_potenMatch.jpg") //menu_icon_potenMatch.jpg
            imageChat.image           = #imageLiteral(resourceName: "menu_icon_chat.jpg") //menu_icon_chat.jpg
            imageMatch.image          = #imageLiteral(resourceName: "menu_icon_match.jpg") //menu_icon_match.jpg
            imageSetting.image        = #imageLiteral(resourceName: "menu_icon_setting_red.png") //red
            
        default: break
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        curSel = 0
        RedAnimation()
        
    }
    
    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        textUserName.text = curProfileInfo.name
        
        self.imageCover.image = coverImageThumb_UI
        self.buttonAvatar.setBackgroundImage(avatarThumb_UI, for: .normal)
    }
    
    
    @IBAction func onTapEditProfileButton(_ sender: Any) {
        
        curSel = 1
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        //self.revealViewController().dismiss(animated: true, completion: nil)
        self.delegate?.onTapEditProfileButton(sender: sender as AnyObject)        
        
        //self.navigationController?.popViewController(animated: true)
        //self.performSegue(withIdentifier: "HomeToEditProfile", sender: nil)
    }

    @IBAction func onTapPotentialMatchesButton(_ sender: Any) {
        
        curSel = 2
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapPotentialMatchesButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapChatsListButton(_ sender: Any) {
        
        curSel = 3
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapChatsListButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapMatchesButton(_ sender: Any) {
        
        curSel = 4
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapMatchesButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapMatchSettingsButton(_ sender: Any) {
        
        curSel = 5
        RedAnimation()
        
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapMatchSettingsButton(sender: sender as AnyObject)
    }
    
    @IBAction func onTapLogoutButton(_ sender: Any) {
        self.revealViewController().revealToggle(animated: true)
        self.delegate?.onTapLogoutButton(sender: sender as AnyObject)
    }
    
}
