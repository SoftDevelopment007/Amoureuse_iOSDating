//
//  Global.swift
//  Amoureuse
//
//  Created by LEE on 3/30/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import ImageSlideshow

//adminView
var curSel: Int = 0



struct ProfileInfo{
    
    var title:  String
    
    //Private
    var dob:  String
    var role: String
    
    //Public    
    var avatarStandard:     String
    var avatarThumb:        String
    var coverImageStandard: String
    var coverImageThumb:    String
    
    var bio:                String
    var gender:             String
    var interests:          String
    var name:               String
    var yearOfBirth:        String
    
    var gridImage:          Array<String>
}

//This is necessary for update, since using last "CreatedAt"
var g_NewProfileFlag_private: Int = 0
var g_NewProfileFlag_public: Int = 0
//-----------------------------------------------------------

//This is necessary for only once read from firebase data.
var initialDataLoaded_private   = false;
var initialDataLoaded_public    = false;
var initialGridPictures         = false;
var initialSearchingUsers       = false;
var initialPotential            = false;
var initialMatch                = false;

//home
var initialChatList             = false;
var initialChannelHeaders       = false;
var initialConversations        = false;

//var g_AutoUpLoadChannelHeaders_locations_Flag = false;
//-----------------------------------------------------------

var curProfileInfo: ProfileInfo = ProfileInfo(
                                              title: "",
    
                                              dob: "",
                                              role: "",
                                              
                                              avatarStandard: "",
                                              avatarThumb: "",
                                              coverImageStandard: "",
                                              coverImageThumb: "",
                                              bio: "",
                                              gender: "",
                                              interests: "",
                                              name: "",
                                              yearOfBirth: "",
                                              gridImage: []
                                             )

var avatarThumb_UI:        UIImage =  #imageLiteral(resourceName: "profile.png")        // profile.png
var coverImageThumb_UI:    UIImage = #imageLiteral(resourceName: "splash")   //splash

var Temp_avatarThumb_UI:     UIImage = #imageLiteral(resourceName: "profile.png")
var Temp_coverImageThumb_UI: UIImage = #imageLiteral(resourceName: "splash")


var g_gridImage   =   Array<UIImage>()

//This is necessary for slideshow
var g_localSource = Array<ImageSource>()
//-----------------------------------------------------------

//Settings
var g_gender:      Int = 3
var g_maxDistance: Int = 5
var g_age_maximum: Int = 56
var g_age_minimum: Int = 18
//-----------------------------------------------------------

//Current Location
var g_latitude:  Double = 0.0
var g_longitude: Double = 0.0
//-----------------------------------------------------------

//Potential data
struct UserInfo {
    //var backgroundUrl: String
    //var avatarUrl: String
    
    var title:        String
    
    
    var avatarUrl:    String
    var coverUrl:     String
    
    var name:         String
    var bio:          String
    var gender:       String
    var interests:    String
    
    var avatarImage:  UIImage
    var coverImage:   UIImage
    
    var uid:          String
}

//====================================================================================================================
var g_Potential_Array: [UserInfo] = []

//This is necessary for slideshow
var g_Potential_localSource = Array<ImageSource>()

//var Potential_Grid_standardUrl:     Array<String>   = Array<String>()
var g_Potential_Grid_thumbUrl:        Array<String>   = Array<String>()
//var Potential_Grid_standardImage:   Array<UIImage>  = Array<UIImage>()
var g_Potential_Grid_thumbImage:      Array<UIImage>  = Array<UIImage>()

var g_Potential_index: Int = -1

//====================================================================================================================
var g_Match_Array: [UserInfo] = []

//This is necessary for slideshow
var g_Match_localSource = Array<ImageSource>()

//var Match_Grid_standardUrl:     Array<String>   = Array<String>()
var g_Match_Grid_thumbUrl:        Array<String>   = Array<String>()
//var Match_Grid_standardImage:   Array<UIImage>  = Array<UIImage>()
var g_Match_Grid_thumbImage:      Array<UIImage>  = Array<UIImage>()

var g_Match_index: Int = -1




//Potential data
struct ChatListInfo {
    
    var name:           String
    var lastMessage:    String
    var time:           Date
    
    var avatarImage:    UIImage
    
    var uid:            String
}

//====================================================================================================================
var g_ChatList_Array: [ChatListInfo] = []
var g_ChatList_index: Int = -1



//ChatViewController
 var temp_avatarImage: UIImage?
 var temp_title: String?
 var temp_name: String?
 var temp_uid: String?











