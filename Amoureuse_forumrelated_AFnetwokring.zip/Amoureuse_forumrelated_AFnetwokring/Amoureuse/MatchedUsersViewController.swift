//
//  MatchedUsersViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/8/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import SDWebImage

import CoreLocation
import ImageSlideshow

    
class MatchedUsersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var textBackNoSearchLabel: UILabel!
    @IBOutlet weak var BackNoSearchImageView: UIImageView!
    
    //var refreshControl = UIRefreshControl()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        tableView.tableHeaderView = UIView()
        
        tableView.delegate = self
        tableView.dataSource = self

        
        //=================================================================================
        
        DownLoadMatch(completion: {
            
            
            
            if self.LocationCNT > 0 {
                
                ProgressHUD.show("Loading...")
                self.DownLoadMatch1(completion: {
                    
                    if self.success == true {
                        
                        ProgressHUD.dismiss()
                        self.success = false
                        self.textBackNoSearchLabel.isHidden = true
                        self.BackNoSearchImageView.isHidden = true
                    } else {
                        
                        ProgressHUD.dismiss()
                        self.textBackNoSearchLabel.isHidden = false
                        self.BackNoSearchImageView.isHidden = false
                    }
                })
            } else {
                
            }
        })
        //================================================================================
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        
        if g_Match_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        /*if g_Match_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
        
        tableView.reloadData()*/
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //====================================================================================
    //
    //
    //      DownLoadMatch()
    //
    //
    //====================================================================================
    var success: Bool = false
    var LocationCNT: Int = 0
    
    
    func DownLoadMatch(completion: @escaping (Void) -> Void) {
        
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        Ref_locations.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialMatch) {
                
                if snapshot.exists() {
                    
                    initialMatch = true
                    
                    print("location snapshot exists")
                    print(snapshot.childrenCount)
                    
                    self.LocationCNT = Int(snapshot.childrenCount) + 1
                    completion()
                } else {
                    
                    print("LocationCNT = 0")
                    self.LocationCNT = 0
                    completion()
                }
            }
        })
    }
    
    func DownLoadMatch1(completion: @escaping (Void) -> Void) {
        
        self.success = false
        //initialMatch = false
        
        g_Match_Array.removeAll()
        self.tableView.reloadData()
        
        g_Match_localSource.removeAll()
        g_Match_Grid_thumbUrl.removeAll()
        g_Match_Grid_thumbImage.removeAll()
        g_Match_index = -1
        
        
        
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        let date = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        
        
        var FlagCnt_1: Int = 0
        
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        Ref_locations.observe(.childAdded, with: { (snapshot: FIRDataSnapshot!) in
            
            if snapshot.exists() {
                
                let uid = snapshot.key //the uid of each user
                print(uid)
                print("location snapshot exists")
                
                //**********************************************************************************************************************************************
//                for snap in snapshot.children {
                    
                    //------------------------------------------------------------------------------------------------------------------------------------------
                    if uid != (user?.uid)! {
                        
                        
                        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        let Ref_channelLikes_B = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!)
                        Ref_channelLikes_B.observe(.value, with: { (channelLikes_B_snapshot: FIRDataSnapshot!) in
                            if channelLikes_B_snapshot.exists() {
                                
                                if let channelLikes_B_dict = channelLikes_B_snapshot.value as? NSDictionary {
                                    
                                    print(channelLikes_B_dict)
                                    
                                    let Ref_channelLikes_B_1 = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(uid)
                                    Ref_channelLikes_B_1.observe(.value, with: { (channelLikes_B_snapshot_1: FIRDataSnapshot!) in
                                        if channelLikes_B_snapshot_1.exists() {
                                            
                                            DispatchQueue.main.async {
                                                print("------------- real channel uid B -------------")
                                                print(uid)
                                                print("----------------------------------------------")
                                                
                                                
                                                var Match_Status_channelLikes_B = (channelLikes_B_dict[uid])! as? Bool
                                                print(Match_Status_channelLikes_B!)
                                                
                                                if Match_Status_channelLikes_B! == true {
                                                    
                                                    print("========================= Again Real B ==========================================================================================")
                                                    let Ref_channelLikes_A = FIRDatabase.database().reference().child("channelLikes").child(uid) //.child((user?.uid)!)
                                                    Ref_channelLikes_A.observe(.value, with: { (channelLikes_A_snapshot: FIRDataSnapshot!) in
                                                        if channelLikes_A_snapshot.exists() {
                                                            
                                                            if let channelLikes_A_dict = channelLikes_A_snapshot.value as? NSDictionary {
                                                                
                                                                print(channelLikes_A_dict)
                                                                
                                                                let Ref_channelLikes_A_1 = FIRDatabase.database().reference().child("channelLikes").child(uid).child((user?.uid)!)
                                                                Ref_channelLikes_A_1.observe(.value, with: { (channelLikes_A_snapshot_1: FIRDataSnapshot!) in
                                                                    
                                                                    if channelLikes_A_snapshot_1.exists() {
                                                                        
                                                                        DispatchQueue.main.async {
                                                                            
                                                                            print("------------- real channel uid A -------------")
                                                                            print(uid)
                                                                            print("----------------------------------------------")
                                                                            
                                                                            
                                                                            var Match_Status_channelLikes_A = (channelLikes_A_dict[(user?.uid)!])! as? Bool
                                                                            print(Match_Status_channelLikes_A!)
                                                                            
                                                                            if Match_Status_channelLikes_A == true {
                                                                                
                                                                                print("========================= Again Real A =========================")
                                                                                //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                                                DispatchQueue.main.async {
                                                                                    
                                                                                    let Ref_Profiles_uid = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                                                    Ref_Profiles_uid.observe(.value, with: { (public_snapshot: FIRDataSnapshot!) in
                                                                                        
                                                                                        //DownLoad public.
                                                                                        if let public_dict = public_snapshot.value as?  NSDictionary {
                                                                                            
                                                                                            var yearOfBirth = public_dict["yearOfBirth"]        as? String ?? ""
                                                                                            var gender      = public_dict["gender"]             as? String ?? ""
                                                                                            
                                                                                            var avatarUrl   = public_dict["avatarThumb"]        as? String ?? ""
                                                                                            var coverUrl    = public_dict["coverImageThumb"]    as? String ?? ""
                                                                                            var name        = public_dict["name"]               as? String ?? ""
                                                                                            var bio         = public_dict["bio"]                as? String ?? ""
                                                                                            var interests   = public_dict["interests"]          as? String ?? ""
                                                                                            
                                                                                            
                                                                                            let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                                            yearOfBirth = yearOfBirth.substring(to: index)
                                                                                            print(yearOfBirth) // 2017
                                                                                            
                                                                                            //Condition1 Age ======================================================================================
                                                                                            if (Int(year) - Int(yearOfBirth)!) >= g_age_minimum && (Int(year) - Int(yearOfBirth)!) <= g_age_maximum {
                                                                                                print(yearOfBirth)
                                                                                                //Condition2 Gender -------------------------------------------------------------------------------
                                                                                                if  (gender == "Male" && g_gender == 1)   ||
                                                                                                    (gender == "Female" && g_gender == 2) ||
                                                                                                    (g_gender == 3) {
                                                                                                    
                                                                                                    //Condition3 Distance .........................................................................
                                                                                                    let Ref_Locations_uid = FIRDatabase.database().reference().child("locations").child(uid).child("l")
                                                                                                    Ref_Locations_uid.observe(.value, with: { (Location_snapshot: FIRDataSnapshot!) in
                                                                                                        
                                                                                                        print(Location_snapshot.value!)
                                                                                                        
                                                                                                        if let Location_dict = Location_snapshot.value as?  [Double] {
                                                                                                            
                                                                                                            let latitude = Double(Location_dict[0])
                                                                                                            let longitude = Double(Location_dict[1])
                                                                                                            
                                                                                                            print(latitude)
                                                                                                            print(longitude)
                                                                                                            print(g_latitude)
                                                                                                            print(g_longitude)
                                                                                                            
                                                                                                            
                                                                                                            let coordinate1 = CLLocation(latitude: latitude, longitude: longitude)
                                                                                                            let coordinate2 = CLLocation(latitude: g_longitude, longitude: g_longitude)
                                                                                                            let distanceInMeters = coordinate1.distance(from: coordinate2)
                                                                                                            
                                                                                                            print(distanceInMeters)
                                                                                                            print(g_maxDistance)
                                                                                                            
                                                                                                            if(distanceInMeters <= Double(g_maxDistance) * 1000.0)
                                                                                                            {
                                                                                                                // under g_maxDistance
                                                                                                                
                                                                                                                //================================================================================
                                                                                                                // Start DownLoad Ok_Conditioned users...
                                                                                                                //================================================================================
                                                                                                                
                                                                                                                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                                                                                                                print(uid)
                                                                                                                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                                                                                                                
                                                                                                                DispatchQueue.main.async {
                                                                                                                    
                                                                                                                    //avatarImage DownLoad
                                                                                                                    let downloader_avatar = SDWebImageDownloader.shared()
                                                                                                                    downloader_avatar.downloadImage(with: NSURL(string: avatarUrl)! as URL, options: [], progress: nil, completed: { (image_avatar, data, error_avatar, finished_avatar) in
                                                                                                                        
                                                                                                                        if error_avatar != nil {
                                                                                                                            
                                                                                                                            print("some error!")
                                                                                                                            
                                                                                                                            FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                            if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                                                completion()
                                                                                                                            }
                                                                                                                            
                                                                                                                        } else {
                                                                                                                            
                                                                                                                            DispatchQueue.main.async{
                                                                                                                                
                                                                                                                                if image_avatar != nil {
                                                                                                                                    
                                                                                                                                    //coverImage DownLoad
                                                                                                                                    let downloader_cover = SDWebImageDownloader.shared()
                                                                                                                                    downloader_cover.downloadImage(with: NSURL(string: coverUrl)! as URL, options: [], progress: nil, completed: { (image_cover, data, error_cover, finished_cover) in
                                                                                                                                        
                                                                                                                                        if error_cover != nil {
                                                                                                                                            
                                                                                                                                            print("some error!")
                                                                                                                                            
                                                                                                                                            FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                                            if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                                                                completion()
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                        } else {
                                                                                                                                            
                                                                                                                                            DispatchQueue.main.async{
                                                                                                                                                
                                                                                                                                                if image_cover != nil {
                                                                                                                                                    
                                                                                                                                                    var Potentila_temp: UserInfo = UserInfo( title:     "",
                                                                                                                                                                                             avatarUrl: "",
                                                                                                                                                                                             coverUrl:  "",
                                                                                                                                                                                             name:      "",
                                                                                                                                                                                             bio:       "",
                                                                                                                                                                                             gender:    "",
                                                                                                                                                                                             interests: "",
                                                                                                                                                                                             
                                                                                                                                                                                             avatarImage:  #imageLiteral(resourceName: "profile.png"),
                                                                                                                                                                                             coverImage:   #imageLiteral(resourceName: "splash"),
                                                                                                                                                                                             
                                                                                                                                                                                             uid:       ""
                                                                                                                                                    )
                                                                                                                                                    
                                                                                                                                                    Potentila_temp.avatarUrl   = avatarUrl
                                                                                                                                                    Potentila_temp.coverUrl    = coverUrl
                                                                                                                                                    Potentila_temp.name        = name
                                                                                                                                                    Potentila_temp.bio         = bio
                                                                                                                                                    Potentila_temp.gender      = gender
                                                                                                                                                    Potentila_temp.interests   = interests
                                                                                                                                                    
                                                                                                                                                    Potentila_temp.uid         = uid
                                                                                                                                                    
                                                                                                                                                    Potentila_temp.title       = "\(Potentila_temp.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                                                                                                    
                                                                                                                                                    Potentila_temp.avatarImage = Utils.profileImage(image: image_avatar!)
                                                                                                                                                    Potentila_temp.coverImage = image_cover!
                                                                                                                                                    
                                                                                                                                                    //New Data Append & Reload
                                                                                                                                                    //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                                                                                                               /*     g_Match_Array.append(Potentila_temp)
                                                                                                                                                    //initialMatch = true
                                                                                                                                                    self.tableView.reloadData()
                                                                                                                                               */
                                                                                                                                                    if g_Match_Array.count < 1 {
                                                                                                                                                        
                                                                                                                                                        g_Match_Array.append(Potentila_temp)
                                                                                                                                                        //g_Match_index = g_Match_Array // - 1
                                                                                                                                                        
                                                                                                                                                        self.tableView.reloadData()
                                                                                                                                                        //self.success = true
                                                                                                                                                        //completion()
                                                                                                                                                        
                                                                                                                                                    } else {
                                                                                                                                                        if let search_index = g_Match_Array.index(where: {$0.uid == uid}) {
                                                                                                                                                            
                                                                                                                                                            g_Match_Array[search_index] = Potentila_temp
                                                                                                                                                            //g_Match_index = g_Match_Array.count // - 1
                                                                                                                                                            
                                                                                                                                                            self.tableView.reloadData()
                                                                                                                                                            //self.success = true
                                                                                                                                                            //completion()
                                                                                                                                                            
                                                                                                                                                        } else {
                                                                                                                                                            
                                                                                                                                                            g_Match_Array.append(Potentila_temp)
                                                                                                                                                            //g_Match_index = g_Match_Array.count // - 1
                                                                                                                                                            
                                                                                                                                                            self.tableView.reloadData()
                                                                                                                                                            //self.success = true
                                                                                                                                                            //completion()
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                                                                                                                                                    
                                                                                                                                                    print(FlagCnt_1)
                                                                                                                                                    print(uid)
                                                                                                                                                    
                                                                                                                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                                                    //print(Int(snapshot.childrenCount - 1))
                                                                                                                                                    if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                                                                        
                                                                                                                                                        print(FlagCnt_1)
                                                                                                                                                        
                                                                                                                                                        self.success = true
                                                                                                                                                        //self.tableView.reloadData()
                                                                                                                                                        completion()
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                    })
                                                                                                                                    
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                        
                                                                                                                        
                                                                                                                    })
                                                                                                                    
                                                                                                                }
                                                                                                                
                                                                                                                //=================================================================================
                                                                                                                
                                                                                                            } else {
                                                                                                                // out of g_maxDistance
                                                                                                                print("don't find distance march.")
                                                                                                                
                                                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                                    self.success = false
                                                                                                                    completion()
                                                                                                                }
                                                                                                            }
                                                                                                            
                                                                                                        } else {
                                                                                                            print("Error - Not Found Location...")
                                                                                                            
                                                                                                            FlagCnt_1 = FlagCnt_1 + 1
                                                                                                            if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                                self.success = false
                                                                                                                completion()
                                                                                                            }
                                                                                                        }
                                                                                                        
                                                                                                    }) { (error) in
                                                                                                        print(error.localizedDescription)
                                                                                                        self.success = false
                                                                                                    }
                                                                                                    //.............................................................................................
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                } else {
                                                                                                    print("don't find -- gender march.")
                                                                                                    
                                                                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                                                                    if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                        self.success = false
                                                                                                        completion()
                                                                                                    }
                                                                                                }
                                                                                                // ------------------------------------------------------------------------------------------------
                                                                                                
                                                                                                
                                                                                            } else {
                                                                                                print("don't find -- age march.")
                                                                                                
                                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                                if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                                    self.success = false
                                                                                                    completion()
                                                                                                }
                                                                                            }
                                                                                            //=====================================================================================================
                                                                                            
                                                                                        }
                                                                                    })
                                                                                }
                                                                                //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                                                print("========================= Again Real A =========================")
                                                                                
                                                                            } else {
                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                if FlagCnt_1 == self.LocationCNT - 1 {
                                                                                    self.success = false
                                                                                    completion()
                                                                                }
                                                                            }
                                                                        }
                                                                        
                                                                    } else {
                                                                        FlagCnt_1 = FlagCnt_1 + 1
                                                                        if FlagCnt_1 == self.LocationCNT - 1 {
                                                                            self.success = false
                                                                            completion()
                                                                        }
                                                                    }
                                                                    
                                                                    
                                                                })
                                                                
                                                            }
                                                        } else {
                                                            self.success = false
                                                            completion()
                                                        }
                                                    })
                                                    
                                                    print("========================= Again Real B ===========================================================================================")
                                                    
                                                } else {
                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                    if FlagCnt_1 == self.LocationCNT - 1 {
                                                        self.success = false
                                                        completion()
                                                    }
                                                }
                                                
                                            }
                                            
                                        } else {
                                            FlagCnt_1 = FlagCnt_1 + 1
                                            if FlagCnt_1 == self.LocationCNT - 1 {
                                                self.success = false
                                                completion()
                                            }
                                        }
                                        
                                    })
                                    
                                }
                                
                            } else {
                                FlagCnt_1 = FlagCnt_1 + 1
                                if FlagCnt_1 == self.LocationCNT - 1 {
                                    self.success = false
                                    completion()
                                }
                            }
                            
                        })
                        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        
                        
//                    }
                    //--------------------------------------------------------------------------------------------------------------------------------------------
                    } else {
                        FlagCnt_1 = FlagCnt_1 + 1
                        if FlagCnt_1 == self.LocationCNT - 1 {
                            
                            self.success = false
                            if g_Match_Array.count < 1 {
                                self.textBackNoSearchLabel.isHidden = false
                                self.BackNoSearchImageView.isHidden = false
                            } else {
                                self.textBackNoSearchLabel.isHidden = true
                                self.BackNoSearchImageView.isHidden = true
                            }
                            completion()
                        }
                }
            }
        })
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //=========================================================================================
    //
    //  Table Delegates
    //
    //=========================================================================================
    
    func initView() {
        tableView.reloadData()
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return g_Match_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if g_Match_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MatchedUserTableCell") as? MatchedUserTableCell
        
        
        
        
        
        cell?.avatarButton.setBackgroundImage(g_Match_Array[indexPath.row].avatarImage, for: .normal)
        cell?.coverImageView.image = g_Match_Array[indexPath.row].coverImage
        
        cell?.textNameAgeLabel.text     = g_Match_Array[indexPath.row].title
        cell?.textAboutLabel.text       = g_Match_Array[indexPath.row].bio
        cell?.textInterestLabel.text    = g_Match_Array[indexPath.row].interests
        
        
        
        
        
        
        if indexPath.row == SECTION_INDEX {
            //cell?.ExpandButton.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png
        } else {
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)     //potential_menu_under.png
            //cell?.ExpandButton.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
        }
        
        
        
        
        
        cell?.chatButton.tag = indexPath.row
        //cell?.ExpandButton.addTarget(self, action: #selector(PotentialMatchesViewController.onTappedDisLikeButton(_:)), for: .touchUpInside)
        
        cell?.ExpandButton.tag  =  indexPath.row
        //cell?.ExpandButton.addTarget(self, action: #selector(PotentialMatchesViewController.onTappedExpandButton(_:)), for: .touchUpInside)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? MatchedUserTableCell
        
        
        g_Match_index = indexPath.row
        
        temp_avatarImage = g_Match_Array[g_Match_index].avatarImage
        temp_title       = g_Match_Array[g_Match_index].name
        temp_name        = g_Match_Array[g_Match_index].name
        temp_uid         = g_Match_Array[g_Match_index].uid
        
        self.performSegue(withIdentifier: StorySegues.FromMatchToMatchDetail.rawValue, sender: self)

        
        /*for dlg in (self.navigationController?.viewControllers)! {
         if dlg is HomeViewController {
         
         (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.name
         (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
         (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
         }
         }*/
        
        /*ProgressHUD.show("Loading...")
        DownLoadPictures(index: indexPath.row, completion: {
            
            g_index = indexPath.row
            self.performSegue(withIdentifier: StorySegues.FromPotentialToDetail.rawValue, sender: self)
            
            ProgressHUD.dismiss()
        })*/
        
    }
    
    var SECTION_INDEX: Int = -1
    
    //Change cell size
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == SECTION_INDEX {
            return (410 + 0)
        } else {
            return (330 + 0)
        }
    }
    
    //====================================================================================================================
    //
    //  Cell Button Methods
    //
    //====================================================================================================================
    @IBAction func onTappedExpandButton(_ sender: Any) {
        
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MatchedUserTableCell
        
        
        
        /*if (sender as! UIButton).backgroundImage(for: .normal) == #imageLiteral(resourceName: "potential_menu_above.png") {   //potential_menu_above.png
            
            (sender as! UIButton).setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png
            
            SECTION_INDEX = -1
            tableView.reloadData()
            
        } else {
            
            (sender as! UIButton).setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
            
            SECTION_INDEX = index
            tableView.reloadData()
        }*/
        
        if cell?.ExpandButton_1.backgroundImage(for: .normal) == #imageLiteral(resourceName: "potential_menu_above.png") {   //potential_menu_above.png
            
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png
            
            SECTION_INDEX = -1
            tableView.reloadData()
            
        } else {
            
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
            
            SECTION_INDEX = index
            tableView.reloadData()
        }
        
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.popViewController(animated: true)
    }
        
    
    @IBAction func onTappedChatButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MatchedUserTableCell
        
        //let user = FIRAuth.auth()?.currentUser
        
        //ProgressHUD.show("Loading...")
        //DownLoadPictures(index: indexPath.row, completion: {
        
        g_Match_index = index        

        temp_avatarImage = g_Match_Array[g_Match_index].avatarImage
        temp_title       = g_Match_Array[g_Match_index].name
        temp_name        = g_Match_Array[g_Match_index].name
        temp_uid         = g_Match_Array[g_Match_index].uid
       
        
        self.performSegue(withIdentifier: StorySegues.FromMatchToChatView.rawValue, sender: self)
        
        //self.performSegue(withIdentifier: StorySegues.FromMatchToChatContent.rawValue, sender: self)
        
            
        //    ProgressHUD.dismiss()
        //})
    }
    
    

}
