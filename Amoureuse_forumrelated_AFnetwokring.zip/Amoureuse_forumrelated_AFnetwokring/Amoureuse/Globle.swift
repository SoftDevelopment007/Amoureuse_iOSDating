//
//  Globle.swift
//  Pier_88_Health_Swift
//
//  Created by Rohit Ajmera on 2/13/17.
//  Copyright © 2017 Rohit Ajmera. All rights reserved.
//

import UIKit

class Globle: NSObject {

//    let IDIOM = UI_USER_INTERFACE_IDIOM()
//    let IPAD =  UIUserInterfaceIdiom.pad
//    let IPHONE = UIUserInterfaceIdiom.phone
    
    let kOFFSET_FOR_KEYBOARD:Float = 80.0
    let APP_TIMEOUT:TimeInterval = 100.0
    
     let APP_APIHEADER =   "https://fcm.googleapis.com/fcm/"

}
