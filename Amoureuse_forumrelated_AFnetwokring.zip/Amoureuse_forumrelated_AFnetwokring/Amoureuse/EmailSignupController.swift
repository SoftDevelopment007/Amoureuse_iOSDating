//
//  EmailSignupController.swift
//  Amoureuse
//
//  Created by LEE on 3/17/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Firebase
import FirebaseAuth

import Foundation
import UIKit

class EmailSignupController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var passwordcheckUIImageView: UIImageView!
    
    var keyboardSize: CGSize = CGSize(width: 0, height: 0)
    var bTextViewMove: Bool = false
    var nTextViewMoveDistance: Int = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        
        passwordTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textFieldDidChange(_ textField: UITextField) {
        if (passwordTextField.text?.isEmpty)! {
            passwordcheckUIImageView.image = #imageLiteral(resourceName: "icon_password_false.jpg")
        }
        else {
            passwordcheckUIImageView.image = #imageLiteral(resourceName: "icon_password_true.jpg")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func onTappedSaveButton(_ sender: Any) {
        if ((usernameTextField.text?.characters.count)! < 1 || (emailTextField.text?.characters.count)! < 1 || (passwordTextField.text?.characters.count)! < 1) {
            self.view.dodo.error(UserDialogs.CompleteRequireFields.rawValue)
            return
        }
        
        //For Email_Signup using Firebase
        if self.emailTextField.text == "" || self.passwordTextField.text == ""
        {
            let alertController = UIAlertController(title: "Alert!", message: "Please enter an email and password.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            ProgressHUD.show("Loading...")
            
            FIRAuth.auth()?.createUser(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!) { (user, error) in
                
                if error == nil
                {
                    //self.signupButton.alpha = 1.0
                    self.usernameTextField.text = user!.email
                    self.emailTextField.text = ""
                    self.passwordTextField.text = ""
                    
                    DispatchQueue.main.async {
                        
                        ProgressHUD.dismiss()
                        
                        UserDefaults.standard.set(false, forKey: "Signed")
                        
                        let transition = CATransition()
                        transition.duration = 0.3
                        transition.type = "flip"
                        transition.subtype = kCATransitionFromLeft
                        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
                       
                        self.performSegue(withIdentifier: StorySegues.FromEmailsignupToSignin.rawValue, sender: self)
                    }
                }
                else
                {
                    
                    ProgressHUD.dismiss()
                    
                    let alertController = UIAlertController(title: "Alert!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
        }
    }
}


