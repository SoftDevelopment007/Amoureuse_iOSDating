//
//  DetailViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/8/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import ImageSlideshow


class DetailViewController: UIViewController {

    
    @IBOutlet weak var imageCover: UIImageView!
    @IBOutlet weak var buttonAvatar: UIButton!
    
    
    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textAboutLabel: UILabel!
    @IBOutlet weak var textInterestLabel: UILabel!
    
    //Grid Image
    @IBOutlet weak var gridImage1: UIImageView!
    @IBOutlet weak var gridImage2: UIImageView!
    @IBOutlet weak var gridImage3: UIImageView!
    @IBOutlet weak var gridImage4: UIImageView!
    @IBOutlet weak var gridImage5: UIImageView!
    @IBOutlet weak var gridImage6: UIImageView!
    
    //SlidShow
    @IBOutlet weak var slideshow: ImageSlideshow!
    
    @IBOutlet weak var image3Coma: UIImageView!
    @IBOutlet weak var btn3Coma: UIButton!
    @IBOutlet weak var btnRemove: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ShowRefresh()
        
        
        
        
        //SlideShow==========================================================================
        //slideshow.backgroundColor = UIColor.white
        slideshow.slideshowInterval = 5.0
        slideshow.pageControlPosition = PageControlPosition.underScrollView
        slideshow.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        slideshow.pageControl.pageIndicatorTintColor = UIColor.black
        slideshow.contentScaleMode = UIViewContentMode.scaleAspectFill
        
        slideshow.currentPageChanged = { page in
            //print("current page:", page)
        }
        
        // try out other sources such as `afNetworkingSource`, `alamofireSource` or `sdWebImageSource` or `kingfisherSource`
        slideshow.setImageInputs(g_Potential_localSource)
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(DetailViewController.didTap))
        slideshow.addGestureRecognizer(recognizer)
        //====================================================================================

    }

    func didTap() {
        
        if g_Potential_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }

    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        self.textNameLabel.text     =   g_Potential_Array[g_Potential_index].title
        self.textAboutLabel.text    =   g_Potential_Array[g_Potential_index].bio
        self.textInterestLabel.text =   g_Potential_Array[g_Potential_index].interests
        
        
        self.imageCover.image =  g_Potential_Array[g_Potential_index].coverImage
        self.buttonAvatar.setBackgroundImage(g_Potential_Array[g_Potential_index].avatarImage, for: .normal)
        
        ShowRefresh()
        slideshow.setImageInputs(g_Potential_localSource)
    }
    
    @IBAction func onTappedFullScreenViewButton(_ sender: Any) {
        if g_Potential_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
 
    
    func ShowRefresh() {
        
        if g_Potential_Grid_thumbImage.count > 0 {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
            
            for i in 0 ... g_Potential_Grid_thumbImage.count - 1 {
                
                if i == 0 {
                    gridImage1.image = g_Potential_Grid_thumbImage[0]
                }
                if i == 1 {
                    gridImage2.image = g_Potential_Grid_thumbImage[1]
                }
                if i == 2 {
                    gridImage3.image = g_Potential_Grid_thumbImage[2]
                }
                if i == 3 {
                    gridImage4.image = g_Potential_Grid_thumbImage[3]
                }
                if i == 4 {
                    gridImage5.image = g_Potential_Grid_thumbImage[4]
                }
                if i == 5 {
                    gridImage6.image = g_Potential_Grid_thumbImage[5]
                }
            }
            
        } else {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
        }
    }





    
    
    
    



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
  
    
    @IBAction func onTappedDisLikeButton(_ sender: Any) {
        
        let user = FIRAuth.auth()?.currentUser
        
        //This is Dislikes
        /*let newMessage_dislike = FIRDatabase.database().reference().child("dislikes").childByAutoId()
        let messageData1 = ["potentialId": g_Potential_Array[g_index].uid, "userId": (user?.uid)!, "createdAt": [".sv": "timestamp"]] as [String : Any]
        //let messageData = ["createdAt": [".sv": "timestamp"], "potentialId": g_Potential_Array[index].uid, "userId": (user?.uid)!] as [String : Any]
        newMessage_dislike.setValue(messageData1)
        
        print(g_Potential_Array[g_index].uid)
        print((user?.uid)!)
        print([".sv": "timestamp"]) //FIRServerValue.timestamp()*/
        
        
        //This is channelLikes
        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Potential_Array[g_Potential_index].uid)
        newMessage_channelLikes.setValue(false)
        
        print(g_Potential_Array[g_Potential_index].uid)
        print((user?.uid)!)
        
        g_Potential_Array.remove(at: g_Potential_index)
        //tableView.reloadData()
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func onTappedLikeButton(_ sender: Any) {
        
        let user = FIRAuth.auth()?.currentUser
        
        //This is likes
        /*let newMessage_like = FIRDatabase.database().reference().child("likes").childByAutoId()
        let messageData1 = ["createdAt": [".sv": "timestamp"], "potentialId": g_Potential_Array[g_index].uid, "userId": (user?.uid)!] as [String : Any]
        newMessage_like.setValue(messageData1)*/
        
        
        //This is channelLikes
        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Potential_Array[g_Potential_index].uid)
        newMessage_channelLikes.setValue(true)
        
        print(g_Potential_Array[g_Potential_index].uid)
        print((user?.uid)!)
        
        
        g_Potential_Array.remove(at: g_Potential_index)
        //tableView.reloadData()
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTapped3ComaButton(_ sender: Any) {
        self.btn3Coma.isHidden = true
        self.image3Coma.isHidden = true
        self.btnRemove.isHidden = false
    }
    
    @IBAction func onTappedRemoveButton(_ sender: Any) {
        let user = FIRAuth.auth()?.currentUser

        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Potential_Array[g_Potential_index].uid)
        newMessage_channelLikes.setValue(false)
        
        print(g_Potential_Array[g_Potential_index].uid)
        print((user?.uid)!)
        
        g_Potential_Array.remove(at: g_Potential_index)

        self.btn3Coma.isHidden = false
        self.image3Coma.isHidden = false
        self.btnRemove.isHidden = true
        
        self.navigationController?.popViewController(animated: true)
    }
    

}
