//
//  EditProfileViewController.swift
//  Amoureuse
//
//  Created by LEE on 3/10/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import JVFloatLabeledTextField
import DatePickerDialog

import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import SDWebImage


var imgencodeStr = ""


class EditProfileViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, WDImagePickerDelegate, UIImagePickerControllerDelegate {

    //WDImagePicker
    var imagePicker: WDImagePicker!
    var WDImageFlag: Int = 0

    var fixedImage: UIImage?
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var userImageButton: UIButton!
    
    @IBOutlet weak var textFieldName: JVFloatLabeledTextField!
    
    @IBOutlet weak var textFieldDateOfBirth: JVFloatLabeledTextField!
    var textFieldDateOfBirth_pub: String = ""
    
    @IBOutlet weak var textFieldGender: JVFloatLabeledTextField!
    @IBOutlet weak var textFieldAbout: JVFloatLabeledTextField!
    @IBOutlet weak var textFieldInterest: JVFloatLabeledTextField!
    
    var GenderPickOption = ["Male", "Female"]
    
    //For Upload Images
    var downcount = 0
    var fileUrl_user_standard_1:  String = ""
    var fileUrl_user_thumb_2:     String = ""
    var fileUrl_back_standard_3:  String = ""
    var fileUrl_back_thumb_4:     String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        GenderPickerDid()
    }

    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        textFieldName.text            = curProfileInfo.name
        textFieldDateOfBirth.text     = curProfileInfo.dob
        textFieldDateOfBirth_pub      = curProfileInfo.yearOfBirth
        textFieldGender.text          = curProfileInfo.gender
        textFieldAbout.text           = curProfileInfo.bio
        textFieldInterest.text        = curProfileInfo.interests
        
        self.backgroundImage.image = coverImageThumb_UI
        self.userImageButton.setBackgroundImage(avatarThumb_UI, for: .normal)
    }

    
    
    func GenderPickerDid() {
        let pickerView = UIPickerView()
        
        pickerView.delegate = self
        
        textFieldGender.inputView = pickerView
        
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: self.view.frame.size.height/6, width: self.view.frame.size.width, height: 40.0))
        
        toolBar.layer.position = CGPoint(x: self.view.frame.size.width/2, y: self.view.frame.size.height-20.0)
        
        toolBar.barStyle = UIBarStyle.blackTranslucent
        
        toolBar.tintColor = UIColor.white
        
        toolBar.backgroundColor = UIColor.black
        
        
        let defaultButton = UIBarButtonItem(title: "Default", style: UIBarButtonItemStyle.plain, target: self, action: #selector(EditProfileViewController.tappedToolBarBtn))
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(EditProfileViewController.donePressed))
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: self, action: nil)
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width / 3, height: self.view.frame.size.height))
        
        label.font = UIFont(name: "Helvetica", size: 12)
        
        label.backgroundColor = UIColor.clear
        
        label.textColor = UIColor.white
        
        label.text = "Select Gender"
        
        label.textAlignment = NSTextAlignment.center
        
        let textBtn = UIBarButtonItem(customView: label)
        
        toolBar.setItems([defaultButton,flexSpace,textBtn,flexSpace,doneButton], animated: true)
        
        textFieldGender.inputAccessoryView = toolBar
    }
    func donePressed(_ sender: UIBarButtonItem) {
        textFieldGender.resignFirstResponder()
    }
    func tappedToolBarBtn(_ sender: UIBarButtonItem) {
        textFieldGender.text = "Male"
        textFieldGender.resignFirstResponder()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return GenderPickOption.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return GenderPickOption[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textFieldGender.text = GenderPickOption[row]
    }
    //----------------------------------------------------------------------------------------------------------
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    @IBAction func onTapBackButton(_ sender: Any) {
        
        //============================================================
        //ProgressHUD.show()
        ProgressHUD.show("Updating...")
        //============================================================

        UploadGridPicture()
        
        UploadProfile()
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    @IBAction func onTappedDateButton(_ sender: Any) {
        
        DatePickerDialog().show(title: "Select Birthday", doneButtonTitle: "Save", cancelButtonTitle: "Cancel", minimumDate: nil, maximumDate: nil, datePickerMode: .date) { (date) in
            if date != nil {
               
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                //dateFormatter.dateStyle = .medium
                var strDate = dateFormatter.string(from: date!)
                
                self.textFieldDateOfBirth?.text = strDate
                
                dateFormatter.dateFormat = "yyyy-MM"
                strDate = dateFormatter.string(from: date!)
                self.textFieldDateOfBirth_pub  = strDate
            }
        }
    }
    
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    @IBAction func onTappedBackgroundButton(_ sender: Any) {
        
        self.WDImageFlag = 2
        
        curProfileInfo.dob                  = (self.textFieldDateOfBirth.text)!
        curProfileInfo.role                 = "user"
        
        coverImageThumb_UI                  = self.backgroundImage.image!
        avatarThumb_UI                      = self.userImageButton.backgroundImage(for: .normal)!
        
        curProfileInfo.bio                  = (self.textFieldAbout.text)!
        curProfileInfo.gender               = (self.textFieldGender.text)!
        curProfileInfo.interests            = (self.textFieldInterest.text)!
        curProfileInfo.name                 = (self.textFieldName.text)!
        curProfileInfo.yearOfBirth          = self.textFieldDateOfBirth_pub
        
       
        //WDImagePicker --------------------------------------------------------------------------
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: 280, height: 200)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Options", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "PhotoLibary", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)

    }
    
    @IBAction func onTappedUserImageButton(_ sender: Any) {
        
        self.WDImageFlag = 1
        
        curProfileInfo.dob                  = (self.textFieldDateOfBirth.text)!
        curProfileInfo.role                 = "user"
        
        coverImageThumb_UI                  = self.backgroundImage.image!
        avatarThumb_UI                      = self.userImageButton.backgroundImage(for: .normal)!
        
        curProfileInfo.bio                  = (self.textFieldAbout.text)!
        curProfileInfo.gender               = (self.textFieldGender.text)!
        curProfileInfo.interests            = (self.textFieldInterest.text)!
        curProfileInfo.name                 = (self.textFieldName.text)!
        curProfileInfo.yearOfBirth          = self.textFieldDateOfBirth_pub
        
        
        //WDImagePicker -----------------------------------------------------------------------------
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: 280, height: 200)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Options", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "PhotoLibary", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        if self.WDImageFlag == 1 {
            
            self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 80, height: 80))
            avatarThumb_UI = Utils.profileImage(image: self.fixedImage!)
            self.userImageButton.setBackgroundImage(avatarThumb_UI, for: .normal)
        }
        
        if self.WDImageFlag == 2 {
            
            self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 150, height: 100)) //(375, 220)
            
            coverImageThumb_UI = self.fixedImage!
            self.backgroundImage.image = coverImageThumb_UI
        }

        
        textFieldName.text            = curProfileInfo.name
        textFieldDateOfBirth.text     = curProfileInfo.dob
        textFieldDateOfBirth_pub      = curProfileInfo.yearOfBirth
        textFieldGender.text          = curProfileInfo.gender
        textFieldAbout.text           = curProfileInfo.bio
        textFieldInterest.text        = curProfileInfo.interests
        
        self.backgroundImage.image = coverImageThumb_UI
        self.userImageButton.setBackgroundImage(avatarThumb_UI, for: .normal)
        
        
        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func onTappedGridButton(_ sender: Any) {
        
        curProfileInfo.dob                  = (self.textFieldDateOfBirth.text)!
        curProfileInfo.role                 = "user"
        
        coverImageThumb_UI                  = self.backgroundImage.image!
        avatarThumb_UI                      = self.userImageButton.backgroundImage(for: .normal)!
        
        curProfileInfo.bio                  = (self.textFieldAbout.text)!
        curProfileInfo.gender               = (self.textFieldGender.text)!
        curProfileInfo.interests            = (self.textFieldInterest.text)!
        curProfileInfo.name                 = (self.textFieldName.text)!
        curProfileInfo.yearOfBirth          = self.textFieldDateOfBirth_pub
        
        self.performSegue(withIdentifier: StorySegues.FromEditToGridImages.rawValue, sender: self)
    }
    
    func UploadGridPicture() {
        
        let user = FIRAuth.auth()?.currentUser
        let newMessage_grid = FIRDatabase.database().reference().child("gridPictures").child((user?.uid)!)
        
        newMessage_grid.removeValue()
        
        if g_gridImage.count < 1 {
            return
        }
        
        var standard_array: [String: AnyObject] = [:]
        var thumb_array: [String: AnyObject] = [:]
        
        let newMessage_grid_standard = FIRDatabase.database().reference().child("gridPictures").child((user?.uid)!).child("standard")
        let newMessage_grid_thumb = FIRDatabase.database().reference().child("gridPictures").child((user?.uid)!).child("thumb")
        
        
        for i in 0 ... g_gridImage.count - 1 {
            
            let filePath_grid_standard = "gridPictures/\((user?.uid)!)/\(i+1)_standard.jpg"
            let filePath_grid_thumb = "gridPictures/\((user?.uid)!)/\(i+1)_thumb.jpg"

            
            let temp_image_grid_standard = g_gridImage[i]
            let temp_image_grid_thumb = Utils.imageWithImage(image: g_gridImage[i], newSize: CGSize(width: 120, height: 120))
            
            var data_grid_standard: NSData = NSData()
            data_grid_standard = UIImageJPEGRepresentation(temp_image_grid_standard, 0.1)! as NSData
            let metadata_grid_standard = FIRStorageMetadata()
            metadata_grid_standard.contentType = "image/jpg"
            var fileUrl_grid_standard: String = ""
            
            var data_grid_thumb: NSData = NSData()
            data_grid_thumb = UIImageJPEGRepresentation(temp_image_grid_thumb, 0.1)! as NSData
            let metadata_grid_thumb = FIRStorageMetadata()
            metadata_grid_thumb.contentType = "image/jpg"
            var fileUrl_grid_thumb: String = ""
            
            FIRStorage.storage().reference().child(filePath_grid_thumb).put(data_grid_thumb as Data , metadata: metadata_grid_thumb, completion: { (metadata, error) in
                
                // Validate user input
                fileUrl_grid_thumb = (metadata?.downloadURLs?[0].absoluteString)!
                // Go back to the main thread to update the UI
                DispatchQueue.main.async {
                    if fileUrl_grid_thumb != "" {
                        
                        FIRStorage.storage().reference().child(filePath_grid_standard).put(data_grid_standard as Data , metadata: metadata_grid_standard, completion: { (metadata, error) in
                            
                            // Validate user input
                            fileUrl_grid_standard = (metadata?.downloadURLs?[0].absoluteString)!
                            // Go back to the main thread to update the UI
                            DispatchQueue.main.async {
                                if fileUrl_grid_standard != "" {
                                    
                                    standard_array["\(i)"] = fileUrl_grid_standard as AnyObject?
                                    thumb_array["\(i)"] = fileUrl_grid_thumb as AnyObject?
                                    
                                    
                                    let messageData = ["standard": standard_array, "thumb": thumb_array]
                                    newMessage_grid.setValue(messageData)
                                    
                                }
                            }
                        })
                        
                    }
                }
            })
            
        }
    }
    
    
    //=====================================================================================================================
    func downloadedFrom(image: UIImage, filePath: String, completion: @escaping (String) -> Void){
        
        var data: NSData = NSData()
        data = UIImageJPEGRepresentation(image, 0.1)! as NSData
        let metadata = FIRStorageMetadata()
        metadata.contentType = "image/jpg"
        
        var DownloadUrl: String = ""
        
        FIRStorage.storage().reference().child(filePath).put(data as Data , metadata: metadata, completion: { (metadata, error) in
            
            if error == nil {
                
                self.downcount += 1
                DownloadUrl = (metadata?.downloadURLs?[0].absoluteString)!
                completion(DownloadUrl)
            }
        })
    }
    
    func UploadProfile(){
        
        self.downcount = 0
        let user = FIRAuth.auth()?.currentUser
        
        downloadedFrom(image: self.imageWithImage(image: avatarThumb_UI, newSize: CGSize(width: 60, height: 60)), filePath: "avatars/\((user?.uid)!)/avatar_standard.jpg", completion: { downloadUrl in
            self.fileUrl_user_standard_1 = downloadUrl
            self.downCompleted()
        })
        downloadedFrom(image: self.imageWithImage(image: avatarThumb_UI, newSize: CGSize(width: 60, height: 60)), filePath: "avatars/\((user?.uid)!)/avatar_thumb.jpg", completion: { downloadUrl in
            self.fileUrl_user_thumb_2 = downloadUrl
            self.downCompleted()
        })
        
        downloadedFrom(image: self.imageWithImage(image: backgroundImage.image!, newSize: CGSize(width: 600, height: 240)), filePath: "covers/\((user?.uid)!)/cover_image_standard.jpg", completion: { downloadUrl in
            self.fileUrl_back_standard_3 = downloadUrl
            self.downCompleted()
        })
        downloadedFrom(image: self.imageWithImage(image: backgroundImage.image!, newSize: CGSize(width: 600, height: 240)), filePath: "covers/\((user?.uid)!)/cover_image_thumb.jpg", completion: { downloadUrl in
            self.fileUrl_back_thumb_4 = downloadUrl
            self.downCompleted()
        })
        
    }
    
    func downCompleted() {
        if downcount >= 4 {
            DispatchQueue.main.async {
                ProgressHUD.dismiss()
                self.downcount = 3
                
                
                curProfileInfo.dob                  = (self.textFieldDateOfBirth.text)!
                curProfileInfo.role                 = "user"
                curProfileInfo.avatarStandard       = self.fileUrl_user_standard_1
                curProfileInfo.avatarThumb          = self.fileUrl_user_thumb_2
                curProfileInfo.coverImageStandard   = self.fileUrl_back_standard_3
                curProfileInfo.coverImageThumb      = self.fileUrl_back_thumb_4
                curProfileInfo.bio                  = (self.textFieldAbout.text)!
                curProfileInfo.gender               = (self.textFieldGender.text)!
                curProfileInfo.interests            = (self.textFieldInterest.text)!
                curProfileInfo.name                 = (self.textFieldName.text)!
                curProfileInfo.yearOfBirth          = self.textFieldDateOfBirth_pub
                
                let date = Date()
                let calendar = Calendar.current
                let year = calendar.component(.year, from: date)
                
                var yearOfBirth = curProfileInfo.yearOfBirth
                let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                yearOfBirth = yearOfBirth.substring(to: index)
                print(yearOfBirth) // 2017
                curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                
                let user = FIRAuth.auth()?.currentUser
                
                
                let newMessage_private = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("private")
                if g_NewProfileFlag_private == 0 {
                    let messageData_private = ["createdAt": [".sv": "timestamp"], "dob": self.textFieldDateOfBirth.text, "role": "user", "updatedAt": [".sv": "timestamp"]] as [String : Any]
                    newMessage_private.setValue(messageData_private)
                } else {
                    let messageData_private = ["dob": self.textFieldDateOfBirth.text, "role": "user", "updatedAt": FIRServerValue.timestamp()] as [String : Any]
                    newMessage_private.updateChildValues(messageData_private)
                }
                
                
                let newMessage_public = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("public")
                if g_NewProfileFlag_public == 0 {
                    
                    let messageData_public =
                        [
                            "avatarStandard":       self.fileUrl_user_standard_1,
                            "avatarThumb":          self.fileUrl_user_thumb_2,
                            "coverImageStandard":   self.fileUrl_back_standard_3,
                            "coverImageThumb":      self.fileUrl_back_thumb_4,
                            "updatedAt":            [".sv": "timestamp"],
                            "createdAt":            [".sv": "timestamp"],
                            "gender":               (self.textFieldGender.text)!,
                            "interests":            (self.textFieldInterest.text)!,
                            "name":                 (self.textFieldName.text)!,
                            "yearOfBirth":          self.textFieldDateOfBirth_pub,
                            "bio":                  (self.textFieldAbout.text)!
                            ] as [String : Any]
                    
                    newMessage_public.setValue(messageData_public)
                    
                    g_NewProfileFlag_public = 1
                    
                    let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                    let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                    rearView.delegate = frontView
                    let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                    self.navigationController?.pushViewController(swViewController!, animated: true)
                    
                } else {
                    
                    let messageData_public =
                        [
                            "avatarStandard":       self.fileUrl_user_standard_1,
                            "avatarThumb":          self.fileUrl_user_thumb_2,
                            "coverImageStandard":   self.fileUrl_back_standard_3,
                            "coverImageThumb":      self.fileUrl_back_thumb_4,
                            "updatedAt":            FIRServerValue.timestamp(),
                            //"createdAt":            createdAt_public,
                            "gender":               (self.textFieldGender.text)!,
                            "interests":            (self.textFieldInterest.text)!,
                            "name":                 (self.textFieldName.text)!,
                            "yearOfBirth":          self.textFieldDateOfBirth_pub,
                            "bio":                  (self.textFieldAbout.text)!
                            ] as [String : Any]
                    
                    newMessage_public.updateChildValues(messageData_public)
                    
                    let transition = CATransition()
                    transition.duration = 0.3
                    transition.type = "flip"
                    transition.subtype = kCATransitionFromLeft
                    self.navigationController?.view.layer.add(transition, forKey: kCATransition)
                    self.navigationController?.popViewController(animated: true)
                    
                }
                
                
            }
        }
    }
    
}
