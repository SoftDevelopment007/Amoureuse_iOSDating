//
//  HomeViewController.swift
//  coloringbook
//
//  Created by Iulian Dima on 7/29/16.
//  Copyright © 2016 Tapptil. All rights reserved.
//

import UIKit
import Firebase

import FBSDKCoreKit
import FBSDKLoginKit

import GoogleSignIn

import FirebaseAuth
import FirebaseDatabase

import ImageSlideshow

import SDWebImage

import CoreLocation

class HomeViewController: UIViewController,  SideMenuViewDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var adminsidemenu_btn: UIButton!
    
    @IBOutlet weak var imageCover: UIImageView!
    @IBOutlet weak var buttonAvatar: UIButton!
    
    
    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textAboutLabel: UILabel!
    @IBOutlet weak var textInterestLabel: UILabel!
    
    //Grid Image
    @IBOutlet weak var gridImage1: UIImageView!
    @IBOutlet weak var gridImage2: UIImageView!
    @IBOutlet weak var gridImage3: UIImageView!
    @IBOutlet weak var gridImage4: UIImageView!
    @IBOutlet weak var gridImage5: UIImageView!
    @IBOutlet weak var gridImage6: UIImageView!
    
    //SlidShow
    @IBOutlet weak var slideshow: ImageSlideshow!
    //let localSource = [ImageSource(imageString: "photo0")!, ImageSource(imageString: "photo1")!, ImageSource(imageString: "photo2")!, ImageSource(imageString: "photo3")!]
    
    //Current Location
    var locationManager:CLLocationManager!
    
    //Current my uid
    var myUID: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //good initial--------------------------------------------
        UserDefaults.standard.set(true, forKey: "Signed")
        //--------------------------------------------------------
        
        
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        
        
        let user = FIRAuth.auth()?.currentUser
        self.myUID = user?.uid
        
        //Google
        //GIDSignIn.sharedInstance().delegate = self
        //GIDSignIn.sharedInstance().uiDelegate = self
        
        
        if self.revealViewController() != nil {            
            adminsidemenu_btn.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
 
        
        
        ShowRefresh()
        
        
        
        
        //SlideShow==========================================================================
        //slideshow.backgroundColor = UIColor.white
        slideshow.slideshowInterval = 5.0
        slideshow.pageControlPosition = PageControlPosition.underScrollView
        slideshow.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        slideshow.pageControl.pageIndicatorTintColor = UIColor.black
        slideshow.contentScaleMode = UIViewContentMode.scaleAspectFill
        
        slideshow.currentPageChanged = { page in
            //print("current page:", page)
        }
        
        // try out other sources such as `afNetworkingSource`, `alamofireSource` or `sdWebImageSource` or `kingfisherSource`
        slideshow.setImageInputs(g_localSource)
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(HomeViewController.didTap))
        slideshow.addGestureRecognizer(recognizer)
        //====================================================================================
        
        //====================================================================================
        //
        //
        
        AutoUpLoadChannelHeaders()
        
        //
        //
        //====================================================================================
        
    }
    
    func didTap() {
        
        if g_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
    
    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        //Get Location========================================================================
        //
        determineMyCurrentLocation()
        //
        //====================================================================================
        
        
        self.textNameLabel.text = curProfileInfo.title
        self.textAboutLabel.text = curProfileInfo.bio
        self.textInterestLabel.text = curProfileInfo.interests
        
        
        self.imageCover.image = coverImageThumb_UI
        self.buttonAvatar.setBackgroundImage(avatarThumb_UI, for: .normal)
        
        ShowRefresh()
        slideshow.setImageInputs(g_localSource)
    }

    @IBAction func onTappedFullScreenView(_ sender: Any) {
        if g_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
    
    func ShowRefresh() {       
        
        if g_gridImage.count > 0 {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
            
            for i in 0 ... g_gridImage.count - 1 {
                
                if i == 0 {
                    gridImage1.image = g_gridImage[0]
                }
                if i == 1 {
                    gridImage2.image = g_gridImage[1]
                }
                if i == 2 {
                    gridImage3.image = g_gridImage[2]
                }
                if i == 3 {
                    gridImage4.image = g_gridImage[3]
                }
                if i == 4 {
                    gridImage5.image = g_gridImage[4]
                }
                if i == 5 {
                    gridImage6.image = g_gridImage[5]
                }
            }
            
        } else {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil

        }
    }
    
    
    /*override func viewDidAppear(_ animated: Bool) {
        self.textNameLabel.text = curProfileInfo.name
        self.textAboutLabel.text = curProfileInfo.bio
        self.textInterestLabel.text = curProfileInfo.interests
        
        
        self.imageCover.image = coverImageThumb_UI
        self.buttonAvatar.setBackgroundImage(avatarThumb_UI, for: .normal)
    }*/
    
    
    @IBAction func onTapGoToEditProfileButton(_ sender: Any) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToEditProfile.rawValue, sender: self)

    }

    //SideMenuViewDelegate - onTapEditProfileButton
    func onTapEditProfileButton(sender: AnyObject) {
        
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToEditProfile.rawValue, sender: self)
    }
    
    func onTapPotentialMatchesButton(sender: AnyObject) {
        /*let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        
        initialPotential = false
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToPotentialMatches.rawValue, sender: self)
    }
    
    func onTapMatchesButton(sender: AnyObject) {
        /*let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        
        initialMatch = false
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToMatched.rawValue, sender: self)
    }
    
    func  onTapChatsListButton(sender: AnyObject) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        //=================================================================================
        /*ProgressHUD.show("Loading...")
        DownLoadChatList(completion: {
            
            if self.success == true {
                
                ProgressHUD.dismiss()
                self.success = false
                self.performSegue(withIdentifier: StorySegues.FromHomeToChatsList.rawValue, sender: self)
                //ProgressHUD.dismiss()
            }
        })*/
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToChatsList.rawValue, sender: self)
        //================================================================================
        
    }
    
    //SideMenuViewDelegate - onTapMatchSettingsButton
    func onTapMatchSettingsButton(sender: AnyObject) {
        
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.performSegue(withIdentifier: StorySegues.FromHomeToSettings.rawValue, sender: self)
    }
    
    //SideMenuViewDelegate - onTapLogoutButton
    func onTapLogoutButton(sender: AnyObject) {
        
        ProgressHUD.show("Loading...")
        
        
        //=================================================================================
        /*initialDataLoaded_private   = false;
        initialDataLoaded_public    = false;
        initialGridPictures         = false;
        initialSearchingUsers       = false;
        initialPotential            = false;*/
       
        g_gridImage.removeAll()
        g_localSource.removeAll()
        
        g_Potential_Array.removeAll()
        g_Potential_localSource.removeAll()
        g_Potential_index = -1
        
 
        g_Match_Array.removeAll()
        g_Match_localSource.removeAll()
        g_Match_index = -1

        g_ChatList_Array.removeAll()
        g_ChatList_index = -1
        
        g_NewProfileFlag_private = 0
        g_NewProfileFlag_public = 0
        
        curProfileInfo.dob                  = ""
        curProfileInfo.role                 = ""
        
        
        avatarThumb_UI              = #imageLiteral(resourceName: "profile.png")        // profile.png
        coverImageThumb_UI          = #imageLiteral(resourceName: "splash")  //splash
        
        Temp_avatarThumb_UI         = #imageLiteral(resourceName: "profile.png")
        Temp_coverImageThumb_UI     = #imageLiteral(resourceName: "splash")
        
        curProfileInfo.bio                  = ""
        curProfileInfo.gender               = ""
        curProfileInfo.interests            = ""
        curProfileInfo.name                 = ""
        curProfileInfo.yearOfBirth          = ""
        
        
        //================================================================================
        
        
        
        
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        
        //logout--------------------------------------------------------------------------
        if FBSDKAccessToken.current() != nil {
            
            ProgressHUD.dismiss()
            
            let logout = FBSDKLoginManager()
            logout.logOut()
            
            UserDefaults.standard.set(false, forKey: "Signed")
            self.revealViewController().revealToggle(animated: true)
            self.performSegue(withIdentifier: StorySegues.FromHomeToSignin.rawValue, sender: self)
         }
        
//        GIDSignIn.sharedInstance().signOut()
        
        //try! FIRAuth.auth()!.signOut()
        do {
            try! FIRAuth.auth()!.signOut()
            
            ProgressHUD.dismiss()
            
            
            
            
            
            UserDefaults.standard.set(false, forKey: "Signed")
            self.revealViewController().revealToggle(animated: true)
            self.performSegue(withIdentifier: StorySegues.FromHomeToSignin.rawValue, sender: self)

        } catch let signOutError as NSError {
            print ("Error signing out: \(signOutError)")
        }
        
  
    }

    
    
    /*var geoFire: NSObject?
    
    func UpLoadLocations() {
        
        let user = FIRAuth.auth()?.currentUser
        let geofireRef = FIRDatabase.database().reference().child("locations").child((user?.uid)!)
        geoFire = GeoFire(firebaseRef: geofireRef)
        
        //updateUserLocation()
        
    }*/
    /*func updateUserLocation() {
     
     let myLocation:CLLocation = locations[0] as CLLocation
     
     if let myLocation = myLocation {
     
     let userID = FIRAuth.auth()!.currentUser!.uid
     geoFire!.setLocation(myLocation, forKey: userID) { (error) in
     if (error != nil) {
     debugPrint("An error occured: \(error)")
     } else {
     print("Saved location successfully!")
     }
     }
     
     }
     }*/
    
    //====================================================
    //
    //   Get Location
    //
    //====================================================
    var location_l_0: String = ""
    var location_l_1: String = ""
    
    func determineMyCurrentLocation() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
            //locationManager.startUpdatingHeading()
        }
    }
    
    var LocationUpload_Flag: Bool = false
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let userLocation:CLLocation = locations[0] as CLLocation
        
        
        let geofireRef = FIRDatabase.database().reference().child("locations")
        let geoFire = GeoFire(firebaseRef: geofireRef)
       
        if self.LocationUpload_Flag == false {
           
            //One time Upload Location
            geoFire!.setLocation(userLocation, forKey: self.myUID!) { (error) in
                if (error != nil) {
                    debugPrint("An error occured: \(error)")
                } else {
                    //print("Saved location successfully!")
                    
                    self.LocationUpload_Flag = true
                }
            }
        }
        

        g_latitude  = userLocation.coordinate.latitude
        g_longitude = userLocation.coordinate.longitude
        
        
        // Call stopUpdatingLocation() to stop listening for location updates,
        // other wise this function will be called every time when user location changes.
        
        // manager.stopUpdatingLocation()
        
/*
        //Show Current Locations------------------------------------------------------------------------------
        print("user latitude = \(userLocation.coordinate.latitude)")
        print("user longitude = \(userLocation.coordinate.longitude)")
        
        //====================================================================================================
        location_l_0 = "\(userLocation.coordinate.latitude)"
        location_l_1 = "\(userLocation.coordinate.longitude)"
        
        //UploadLocation()
        //=====================================================================================================
*/
        
        
    }
    
   
    /*func UploadLocation() {
        let user = FIRAuth.auth()?.currentUser
     
        let newMessage_Location = FIRDatabase.database().reference().child("locations").child((user?.uid)!)
     
        let messageData_Location_g = ["g": "123"]
        newMessage_Location.child("g").setValue(messageData_Location_g)
     
        let messageData_Location_l = ["0": location_l_0, "1": location_l_1]
        newMessage_Location.child("l").setValue(messageData_Location_g)
    }*/
    
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // ChatHeader Update
    //
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
    func AutoUpLoadChannelHeaders() {
 
        let user = FIRAuth.auth()?.currentUser
        print(String(describing: user?.email))
        print(String(describing:user?.uid))
 
 
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        Ref_locations.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
 
            if !g_AutoUpLoadChannelHeaders_locations_Flag {
 
                if snapshot.exists() {
 
                    g_AutoUpLoadChannelHeaders_locations_Flag = true
 
                    print("location snapshot exists")
                    print(snapshot.childrenCount)
*/
                    //************************************************************************************************************
/*                    for snap in snapshot.children {
                        let userSnap = snap as! FIRDataSnapshot
                        let uid = userSnap.key //the uid of each user
 
                        //========================================================================================================
                        if uid != (user?.uid)! {
 
                            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                            Message_Ref.observe(.childAdded , with: { snapshot_conversasion in
 
                                if snapshot_conversasion.exists() {
                                    print("Message_Ref snapshot exists")
 
                                    //--------------------------------------------------------------------------------------------
                                    let Ref_chatheader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                    Ref_chatheader.observe(.value, with: { (snapshot_chatheader: FIRDataSnapshot!) in
 
                                        if snapshot_chatheader.exists() {
*/
                                            //print("Ref_chatheader snapshot exists")
 
                                            /*let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                             let messageData = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                                             newMessage_channelHeader.updateChildValues(messageData)*/
 
/*                                            if let dict_chatheader = snapshot_chatheader.value as? [String: AnyObject] {
 
                                                DispatchQueue.main.async{
 
                                                    //print(dict_chatheader)
 
                                                    let updatedAt_header    = dict_chatheader["updatedAt"]      as! Double
                                                    print(updatedAt_header)
 
 
                                                    let Ref_LatestMessage = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                                                    //.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
                                                    Ref_LatestMessage.queryOrdered(byChild: "updatedAt").queryLimited(toFirst: 1).observe(.childAdded, with: { snapshot_query in
 
                                                        //print("The key: \(snapshot.key)") //the key
 
                                                        if let dict_query = snapshot_query.value as? [String: AnyObject] {
 
                                                            //print(dict_query)
 
                                                            let updatedAt_query    = dict_query["updatedAt"]       as! Double
                                                            //print(updatedAt_query)
                                                            let reply_query    = dict_query["reply"]               as! Bool
                                                            //print(reply_query)
 
                                                            if updatedAt_query < updatedAt_header  && reply_query == true {
 
                                                                if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
 
                                                                } else {
*/
                                                                    /*let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                                     Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                                                     
                                                                     if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                                     print(dict_SenderName)
                                                                     let SenderName    = dict_SenderName["name"]  as! String
                                                                     
                                                                     print(SenderName)
                                                                     self.view.dodo.error("New Message Received from \(SenderName).")
                                                                     }
                                                                     })*/
/*                                                                    self.view.dodo.error("New Message Received from SenderName.")
                                                                    
                                                                }
                                                            }
                                                        }
                                                        //print(snapshot_query) //the key
                                                        
                                                    })
                                                }
                                            }
                                            
                                            
                                        } else {
                                            
                                            let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                            let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                                            newMessage_channelHeader.setValue(messageData)
                                            
                                            
                                            
                                            if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
                                                
                                            } else {
*/
                                                /*let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                 Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                                 
                                                 if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                 print(dict_SenderName)
                                                 let SenderName    = dict_SenderName["name"]  as! String
                                                 
                                                 print(SenderName)
                                                 self.view.dodo.error("New Message Received from \(SenderName).")
                                                 }
                                                 })*/
/*                                                self.view.dodo.error("New Message Received from SenderName.")
                                                
                                            }
                                        }
                                    })
                                }
                            })
                            
                        }
                    }
                }
            }
        })
    }
 */
    
    func AutoUpLoadChannelHeaders() {
        
        let user = FIRAuth.auth()?.currentUser
        print(String(describing: user?.email))
        print(String(describing:user?.uid))
        
        
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        Ref_locations.observe(.childAdded, with: { (snapshot: FIRDataSnapshot!) in
            
            if snapshot.exists() {
                
                let uid = snapshot.key //the uid of each user
                print(uid)
                print("location snapshot exists")
                
                
                    let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                    Message_Ref.queryOrdered(byChild: "updatedAt").queryLimited(toLast : 1).observe(.childAdded, with: { snapshot_conversasion in
                    //Message_Ref.observe(.childAdded , with: { snapshot_conversasion in
                        
                        if snapshot_conversasion.exists() {
                            print("Message_Ref snapshot exists")
                            
                                if let dict_conversations          = snapshot_conversasion.value       as? [String: AnyObject] {
                                    
                                    let updatedAt_conversations     = dict_conversations["updatedAt"]  as! Double
                                    let reply_conversations         = dict_conversations["reply"]      as! Bool
                                
                                
                                    let Ref_chatheader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                    Ref_chatheader.observe(.value, with: { (snapshot_chatheader: FIRDataSnapshot!) in
                                        
                                            if snapshot_chatheader.exists() {
                                                
                                                if let dict_chatheader     = snapshot_chatheader.value        as? [String: AnyObject] {
                                                    
                                                    let updatedAt_header    = dict_chatheader["updatedAt"]    as! Double
                                                    
                                                    if (updatedAt_conversations - 1) > updatedAt_header  && reply_conversations == true {
                                                        
                                                            if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
                                                                
                                                            } else {
                                                                
                                                                let messageData = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                                                                Ref_chatheader.updateChildValues(messageData)
                                                                
                                                                
                                                                
                                                                
                                                                let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                                Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                                                    
                                                                    if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                                        
                                                                        //print(dict_SenderName)
                                                                        let SenderName    = dict_SenderName["name"]  as! String
                                                                        
                                                                        print(SenderName)
//                                                                        self.view.dodo.error("New Message Received from \(SenderName).")
                                                                    }
                                                                })
                                                           }

                                                    }
                                                }
                                                
                                            } else {
                                                
                                                        //Ref_chatheader
                                                        let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                                        
                                                        let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                                                        newMessage_channelHeader.setValue(messageData)
                                                        
                                                        if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
                                                            
                                                        } else {
                                                            
                                                            let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                            Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                                                
                                                                if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                                    
                                                                    //print(dict_SenderName)
                                                                    let SenderName    = dict_SenderName["name"]  as! String
                                                                    
                                                                    print(SenderName)
//                                                                    self.view.dodo.error("New Message Received from \(SenderName).")
                                                                }
                                                            })
                                                        }
                                            }
                                        
                                    })
                                }
                        }
                    })
                
            }
        })

        
    }
 
 func AutoUpLoadChannelHeaders111() {
 
     let user = FIRAuth.auth()?.currentUser
     print(String(describing: user?.email))
     print(String(describing:user?.uid))
     
     
     let Ref_locations = FIRDatabase.database().reference().child("locations")
     Ref_locations.observe(.childAdded, with: { (snapshot: FIRDataSnapshot!) in
     
         //if !g_AutoUpLoadChannelHeaders_locations_Flag {
         
             if snapshot.exists() {
             
                 //g_AutoUpLoadChannelHeaders_locations_Flag = true
                
                 let uid = snapshot.key //the uid of each user
                
                 /*4Tb5JSorh2SQluNpihMzG2KzMDI3 =     {
                    ".priority" = wxrtzdrxbd;
                    g = wxrtzdrxbd;
                    l =         {
                        0 = "41.80569768887181";
                        1 = "123.3867916000293";
                    };
                 };*/
                
                 print("location snapshot exists")
                 //print(snapshot.childrenCount)
                 
                 //************************************************************************************************************
//                 for snap in snapshot.children {
//                     let userSnap = snap as! FIRDataSnapshot
//                     let uid = userSnap.key //the uid of each user
                
                     //========================================================================================================
                     if uid != (user?.uid)! {
                     
                         //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                         let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                         Message_Ref.observe(.childAdded , with: { snapshot_conversasion in
                         
                             if snapshot_conversasion.exists() {
                             print("Message_Ref snapshot exists")
                             
                             //--------------------------------------------------------------------------------------------
                             let Ref_chatheader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                             Ref_chatheader.observe(.value, with: { (snapshot_chatheader: FIRDataSnapshot!) in
                             
                                 if snapshot_chatheader.exists() {
                                     //print("Ref_chatheader snapshot exists")
                                     
                                     /*let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                     let messageData = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                                     newMessage_channelHeader.updateChildValues(messageData)*/
                                     
                                     if let dict_chatheader = snapshot_chatheader.value as? [String: AnyObject] {
                                     
                                         DispatchQueue.main.async{
                                         
                                             //print(dict_chatheader)
                                             
                                             let updatedAt_header    = dict_chatheader["updatedAt"]      as! Double
                                             print(updatedAt_header)
                                             
                                             
                                             let Ref_LatestMessage = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                                             //.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
                                             Ref_LatestMessage.queryOrdered(byChild: "updatedAt").queryLimited(toFirst: 1).observe(.childAdded, with: { snapshot_query in
                                             
                                                 //print("The key: \(snapshot.key)") //the key
                                                 
                                                 if let dict_query = snapshot_query.value as? [String: AnyObject] {
                                                 
                                                     //print(dict_query)
                                                     
                                                     let updatedAt_query    = dict_query["updatedAt"]       as! Double
                                                     //print(updatedAt_query)
                                                     let reply_query    = dict_query["reply"]               as! Bool
                                                     //print(reply_query)
                                                     
                                                     if updatedAt_query < updatedAt_header  && reply_query == true {
                                                     
                                                         if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
                                                         
                                                         } else {
                                                            
                                                             let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                             Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                                             
                                                                 if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                                    
                                                                     print(dict_SenderName)
                                                                     let SenderName    = dict_SenderName["name"]  as! String
                                                                     
                                                                     print(SenderName)
//                                                                     self.view.dodo.error("New Message Received from \(SenderName).")
                                                                 }
                                                             })
                                                             //self.view.dodo.error("New Message Received from SenderName.")
                                                         
                                                         }
                                                     }
                                                 }
                                                
                                                 //print(snapshot_query) //the key
                                            })
                                        }
                                    }
                                                     
                                } else {
                                    
                                         let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                                    
                                         let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                                         newMessage_channelHeader.setValue(messageData)
                                        
                                         if UIApplication.shared.delegate?.window!!.rootViewController?.presentedViewController is ChatViewController {
                                         
                                         } else {
                                         
                                             let Ref_SenderName = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                             Ref_SenderName.observe(.value, with: { (snapshot_SenderName: FIRDataSnapshot!) in
                                             
                                                 if let dict_SenderName = snapshot_SenderName.value as? [String: AnyObject] {
                                                 
                                                     print(dict_SenderName)
                                                     let SenderName    = dict_SenderName["name"]  as! String
                                                     
                                                     print(SenderName)
//                                                     self.view.dodo.error("New Message Received from \(SenderName).")
                                                 }
                                             })
                                             //self.view.dodo.error("New Message Received from SenderName.")
                                         
                                         }
                                     }
                                 })
                             }
                         })
                     
                     //}
                 }
             }
         //}
     })
 }
 

}



