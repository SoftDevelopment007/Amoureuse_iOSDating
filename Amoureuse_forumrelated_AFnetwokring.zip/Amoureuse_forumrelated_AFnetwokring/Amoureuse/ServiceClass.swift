//
//  ServiceClass.swift
//  Wealth
//
//  Created by Rohit Ajmera on 12/17/16.
//  Copyright © 2016 Rohit Ajmera. All rights reserved.
//

import UIKit
import AFNetworking


class ServiceClass: NSObject {
    
    let GlobalVar = Globle()

    /*func serviceGetMethodWithAPIHeaderValue(headerValue: String, fields: String, completion completionBlock: @escaping (NSDictionary) -> Void) {
        
      let requestLink = "\(GlobalVar.APP_APIHEADER)\(headerValue)\(fields)/"

        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Accept")
        manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        
        manager.requestSerializer.timeoutInterval = GlobalVar.APP_TIMEOUT
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.get(requestLink, parameters: fields, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            
            completionBlock(responseObject)
            
        }) { (task, error) in
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
                
            }))
            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)
            
        }
 
    }*/
    
    
    //Alamofire.request("https://fcm.googleapis.com/fcm/send", method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: ["Authorization": "key=AIzaSyCN5A7LxI7XKpwn7Os16YeaK-JdYrV8Ms4" ,"Content-Type": "application/json"])//.authenticate(user: "invallid", password:
    
    
    func servicePostMethodWithAPIHeaderValue(headerValue: String, parameters params: [NSObject : AnyObject], completion completionBlock: (((NSDictionary)?) -> Void)?) -> () {
        
        let url = "\(GlobalVar.APP_APIHEADER)\(headerValue)"
        let manager = AFHTTPSessionManager()
         manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Accept")
        
        
        //manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("sun0dragon@gmail.com", password: "2017#dev")
        //"Authorization": "key=AIzaSyCN5A7LxI7XKpwn7Os16YeaK-JdYrV8Ms4"
        //manager.requestSerializer.setValue("Authorization", forHTTPHeaderField: "key=AIzaSyCN5A7LxI7XKpwn7Os16YeaK-JdYrV8Ms4")
        
        //manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("maria@mail.com", password: "test123")
        manager.requestSerializer.timeoutInterval = GlobalVar.APP_TIMEOUT
        manager.responseSerializer = AFJSONResponseSerializer()
        
        //manager.responseSerializer.setValuesForKeys(<#T##keyedValues: [String : Any]##[String : Any]#>)
        
        manager.post(url, parameters: params, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            
            completionBlock!(responseObject)
            
        }) { (task, error) in
            
//        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "loading_dismiss"), object: nil)
            ProgressHUD.dismiss()
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
                            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
            
                            }))
                            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
                            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)

        }
        
    }
    
   /* func serviceMultiPartPostMethodWithAPIHeaderValue(headerValue: String, parameters params: [NSObject : AnyObject], Image image: UIImage, completion completionBlock: ((NSArray)? -> Void)?) -> () {
        
        let url = "\(GlobalVar.APP_APIHEADER)\(headerValue)"
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Accept")
        manager.requestSerializer.setValue("KVn6XluiqLN5CFoOZl1F5QwIYGY=", forHTTPHeaderField: "X-APP-WealthApp-HEADER-KEY")
        manager.requestSerializer.timeoutInterval = GlobalVar.APP_TIMEOUT
        manager.responseSerializer = AFJSONResponseSerializer()

        manager.POST(url, parameters: params, constructingBodyWithBlock: { (formData: AFMultipartFormData!) -> Void in
            
            var imageData = NSData(data: UIImagePNGRepresentation(image)!)
            var newimage = image
            
            while imageData.length > 300000 {
                
                let originalSize = newimage.size
                let newSize = CGSizeMake(originalSize.width * 0.50, originalSize.height * 0.50)
                // Scale the original image to match the new size.
                UIGraphicsBeginImageContext(newSize)
                image.drawInRect(CGRectMake(0, 0, newSize.width, newSize.height))
                let compressedImage = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                newimage = compressedImage!
                imageData = UIImagePNGRepresentation(compressedImage!)!
            }
            formData.appendPartWithFormData(imageData, name: "IMAGE1")
            
            }, progress: { (NilLiteralConvertible) -> Void in
                
            }, success: { (task: URLSessionDataTask?, responseObject: AnyObject?) -> Void in
                
                let responceArray = responseObject as! NSArray
                
                completionBlock!(responceArray)
                
            }) { (task: URLSessionDataTask?, error: NSError!) -> Void in
                                
                let alertView = UIAlertController(title: "", message: "\(error.userInfo["data"])", preferredStyle: .Alert)
                alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (alertAction) -> Void in
                 
                }))
                alertView.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
            UIApplication.sharedApplication().delegate?.window!!.rootViewController?.presentViewController(alertView, animated: true, completion: nil)

        }
        
    }
*/
    
}
   
