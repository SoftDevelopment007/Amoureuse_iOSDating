//
//  ChatViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/10/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import JSQMessagesViewController
//import MobileCoreServices
import AVKit
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
//import SDWebImage
    
class ChatViewController: JSQMessagesViewController {

 
    var Temp_ChatList: ChatListInfo = ChatListInfo(name: temp_name!, lastMessage: "", time: Date(), avatarImage: temp_avatarImage!, uid: temp_uid!)
    
    func temp_init() {
        
    }
    
    
    var messages = [JSQMessage]()
    
    var avatarDict = [String: JSQMessagesAvatarImage]()
    //var messageRef = FIRDatabase.database().reference().child("messages")
    
    //@IBOutlet weak var viewNavBar: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.title = temp_title
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barStyle = UIBarStyle.black
        
        
        self.senderDisplayName = curProfileInfo.name    //g_Match_Array[g_Match_index].name
        
        if let currentUser = FIRAuth.auth()?.currentUser {
            self.senderId = currentUser.uid
        }
        
        observeMessages()

    }

    func setupAvatar(messageId: String) {
        
        if self.senderId == messageId {
            let userImg = JSQMessagesAvatarImageFactory.avatarImage(with: avatarThumb_UI , diameter: 30)
            avatarDict[messageId] = userImg
        } else {
            let userImg = JSQMessagesAvatarImageFactory.avatarImage(with: temp_avatarImage , diameter: 30)
            avatarDict[messageId] = userImg
        }
        
        collectionView.reloadData()
        
    }
    
    
    func observeMessages() {
        
        let user = FIRAuth.auth()?.currentUser
        
        //let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(g_Match_Array[g_Match_index].uid).child("-KhPt1KgPbcfggMk3EZA")
        
        let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(temp_uid!)
        
        print(user?.uid)
        print(temp_uid!)
        
        Message_Ref.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25).observe(.childAdded, with: { snapshot in
        //Message_Ref.queryOrdered(byChild: "createdAt").queryLimited(toFirst: 25).observe(.childAdded, with: { snapshot in
        //Message_Ref.observe(.childAdded , with: { snapshot in
            print(snapshot.value)
            
            if let dict = snapshot.value as? [String: AnyObject] {
                
                let createdAt    = dict["createdAt"]         as! Double
                print(createdAt)
                
                let dateTimeStamp = NSDate(timeIntervalSince1970:Double(createdAt)/1000)  //UTC time
                
                let dateFormatter = DateFormatter()
                dateFormatter.timeZone = NSTimeZone.local //Edit
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
                //dateFormatter.dateStyle = DateFormatter.Style.FullStyle
                //dateFormatter.timeStyle = DateFormatter.Style.ShortStyle
                
                let strDateSelect = dateFormatter.string(from: dateTimeStamp as Date)
                print(strDateSelect) //Local time
                
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy/MM/dd HH:mm"
                let someDateTime = formatter.date(from: strDateSelect)
       
                
                let reply = dict["reply"] as! Bool
                let text = dict["message"] as! String
               
                self.Temp_ChatList.name        = temp_name!
                self.Temp_ChatList.lastMessage = text
                self.Temp_ChatList.time        = someDateTime!
                self.Temp_ChatList.avatarImage = temp_avatarImage!
                self.Temp_ChatList.uid         = temp_uid!
                
                
                
                DispatchQueue.main.async{
                    
                    if reply == true {
                        self.setupAvatar(messageId: temp_uid!)
                        self.messages.append(JSQMessage(senderId: temp_uid!,
                                                        senderDisplayName: temp_name!,
                                                        date: someDateTime as Date!,
                                                        text: text))
                        self.finishSendingMessage()
                    } else {
                        self.setupAvatar(messageId: self.senderId)
                        self.messages.append(JSQMessage(senderId: self.senderId,
                                                        senderDisplayName: self.senderDisplayName,
                                                        date: someDateTime as Date!,
                                                        text: text))
                        self.finishSendingMessage()
                    }
                    
                    self.collectionView.reloadData()
                    
                    DispatchQueue.global(qos: .userInteractive).async{
                    //DispatchQueue.global(qos: .userInteractive).async(execute: {
                        
                        print(self.Temp_ChatList)
                        if g_ChatList_Array.count < 1 {
                            
                            g_ChatList_Array.append(self.Temp_ChatList)
                            g_ChatList_index = g_ChatList_Array.count - 1
                            
                            let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
                             let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                             newMessage_channelHeader.setValue(messageData)
                            
                            
                        } else {
                            if let search_index = g_ChatList_Array.index(where: {$0.uid == temp_uid}) {
                                
                                g_ChatList_Array[search_index] = self.Temp_ChatList
                                g_ChatList_index = g_ChatList_Array.count - 1
                                
                                let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
                                let messageData = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                                newMessage_channelHeader.updateChildValues(messageData)
                                
                                
                            } else {
                                
                                g_ChatList_Array.append(self.Temp_ChatList)
                                g_ChatList_index = g_ChatList_Array.count - 1
                                
                                let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
                                 let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                                 newMessage_channelHeader.setValue(messageData)
                            }
                        }
                    //})
                    }
                    
                    
                }
                
            }
        })
    }
    
    
    /*static func viewFromStoryboard() -> ChatViewController {
        let mainStoryboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let pfv : ChatViewController = mainStoryboard.instantiateViewController(withIdentifier: "ChatViewVC").view as! ChatViewController
        
        return pfv
    }    
    override func awakeFromNib() {
        super.awakeFromNib()
    }*/
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        //self.view.bringSubview(toFront: viewNavBar)
        //self.view.addSubview(viewNavBar)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //This is JSQMessage View ----------------------------------------------------------------------------------------------------------------------------
    // MARK: JSQMessagesViewController method overrides
    override func didPressSend(_ button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: Date!) {
        /**
         *  Sending a message. Your implementation of this method should do *at least* the following:
         *
         *  1. Play sound (optional)
         *  2. Add new id<JSQMessageData> object to your data source
         *  3. Call `finishSendingMessage`
         */
        
        
        let user = FIRAuth.auth()?.currentUser
        
        //Received Message SetValue  --- "reply": false
        let newMessage_Ref_received = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(temp_uid!).childByAutoId()
        let messageData_received = ["createdAt": [".sv": "timestamp"], "message": text, "reply": false, "updatedAt": [".sv": "timestamp"]] as [String : Any]
        newMessage_Ref_received.setValue(messageData_received)
        
        //Sent Message SetValue      ---"reply": true
        let newMessage_Ref_Sent = FIRDatabase.database().reference().child("conversations").child(temp_uid!).child((user?.uid)!).childByAutoId()
        let messageData_Sent = ["createdAt": [".sv": "timestamp"], "message": text, "reply": true, "updatedAt": [".sv": "timestamp"]] as [String : Any]
        newMessage_Ref_Sent.setValue(messageData_Sent)
        
        
        /*self.setupAvatar(messageId: self.senderId)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: "2016/10/08 22:31")
        self.messages.append(JSQMessage(senderId: senderId, senderDisplayName: senderDisplayName, date: someDateTime as Date!, text: text))
        self.finishSendingMessage(animated: true)*/
        
    }
    
    //for "Upload" button is active - send photo or video file
    override func didPressAccessoryButton(_ sender: UIButton!) {
        
        print("---------- didPressAccessoryButton ------------")
        
        /*let sheet = UIAlertController(title: "Media Messages", message: "Please select a media", preferredStyle: UIAlertControllerStyle.actionSheet)
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel){ (alert: UIAlertAction) in
        }
        
        let photoLibrary = UIAlertAction(title: "Photo Library", style: UIAlertActionStyle.default){ (alert: UIAlertAction) in
            self.getMediaFrom(type: kUTTypeImage)
        }
        let videoLibrary = UIAlertAction(title: "Video Library", style: UIAlertActionStyle.default){ (alert: UIAlertAction) in
            self.getMediaFrom(type: kUTTypeMovie)
        }
        
        sheet.addAction(photoLibrary)
        sheet.addAction(videoLibrary)
        sheet.addAction(cancel)
        self.present(sheet, animated: true, completion: nil)
        
        print("-----------------------------------------------")*/
    }
    /*func getMediaFrom(type: CFString){
        print(type)
        let mediaPicker = UIImagePickerController()
        mediaPicker.delegate = self
        mediaPicker.mediaTypes = [type as String]
        self.present(mediaPicker, animated: true, completion: nil)
    }*/
    
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, attributedTextForCellTopLabelAt indexPath: IndexPath) -> NSAttributedString? {
        /**
         *  This logic should be consistent with what you return from `heightForCellTopLabelAtIndexPath:`
         *  The other label text delegate methods should follow a similar pattern.
         *
         *  Show a timestamp for every 3rd message
         */
        
        //if (indexPath.item % 3 == 0) {
            let message = self.messages[indexPath.item]
            
            return JSQMessagesTimestampFormatter.shared().attributedTimestamp(for: message.date)
        //}
        //return nil
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout, heightForCellTopLabelAt indexPath: IndexPath) -> CGFloat {
        /**
         *  Each label in a cell has a `height` delegate method that corresponds to its text dataSource method
         */
        
        /**
         *  This logic should be consistent with what you return from `attributedTextForCellTopLabelAtIndexPath:`
         *  The other label height delegate methods should follow similarly
         *
         *  Show a timestamp for every 3rd message
         */
        //if indexPath.item % 3 == 0 {
            return kJSQMessagesCollectionViewCellLabelHeightDefault
        //}
        
        //return 0.0
    }
    
    //For Message Rect Effect---------------------------------------------------------------------------------------------------------------------------
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageDataForItemAt indexPath: IndexPath!) -> JSQMessageData! {
        return messages[indexPath.item]
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAt indexPath: IndexPath!) -> JSQMessageBubbleImageDataSource! {
        
        let bubblefactory = JSQMessagesBubbleImageFactory()
        
        
        let message = messages[indexPath.item]
        if message.senderId == self.senderId {
            //As Outgoing = true
            //return bubblefactory!.outgoingMessagesBubbleImage(with: UIColor.black) //UIColor.lightGray, greenColor()
            //return bubblefactory!.outgoingMessagesBubbleImage(with: UIColor(red: 211.0/255, green: 210.0/255, blue: 217.0/255, alpha: 1.0))
            return bubblefactory!.outgoingMessagesBubbleImage(with: UIColor(red: 46.0/255, green: 155.0/255, blue: 230.0/255, alpha: 1.0))
            
        } else {
            //As InComing = true
            //return bubblefactory!.incomingMessagesBubbleImage(with: UIColor.blue)
            return bubblefactory!.incomingMessagesBubbleImage(with: UIColor(red: 72.0/255, green: 210.0/255, blue: 60.0/255, alpha: 1.0))
        }
    }
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAt indexPath: IndexPath!) -> JSQMessageAvatarImageDataSource! {
        //return nil
        
        //chat icon
        let message = messages[indexPath.item]
        
        return avatarDict[message.senderId]
        //return JSQMessagesAvatarImageFactory.avatarImage(with: UIImage(named: "profile.png"), diameter: 30)
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("number of item:\(messages.count)")
        return messages.count
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        
        let cell = super.collectionView(collectionView, cellForItemAt: indexPath) as! JSQMessagesCollectionViewCell
        return cell
    }
    
    //for Select Photo or Video in chat view
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, didTapMessageBubbleAt indexPath: IndexPath!) {
        print("--------- didTapMessageBubbleAtIndexPath: \(indexPath.item) ----------")
        
        let message = messages[indexPath.item]
        if message.isMediaMessage{
            if let mediaItem = message.media as? JSQVideoMediaItem {
                
                let player = AVPlayer(url: mediaItem.fileURL)
                let playerViewController = AVPlayerViewController()
                playerViewController.player = player  //Sub Video View enable/dissable
                self.present(playerViewController, animated: true, completion: nil)
            }
        }
   }

    
    /*
    // MARK:

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        
        /*let array = g_ChatList_Array.filter({$0.uid == temp_uid})
        if array.count == 0 {
            
        } else {
            
        }*/

        /*let user = FIRAuth.auth()?.currentUser
        
        print(Temp_ChatList)
        if g_ChatList_Array.count < 1 {
            
            g_ChatList_Array.append(Temp_ChatList)
            g_ChatList_index = g_ChatList_Array.count - 1
            
            let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
            let messageData = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
            newMessage_channelHeader.setValue(messageData)
            
            
            
            /*let newMessage_channelHeader2 = FIRDatabase.database().reference().child("channelHeaders").child(g_ChatList_Array[g_ChatList_index].uid).child((user?.uid)!)
            let messageData2 = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
            newMessage_channelHeader2.setValue(messageData2)*/
            
        } else {
            if let search_index = g_ChatList_Array.index(where: {$0.uid == temp_uid}) {
                
                g_ChatList_Array[search_index] = Temp_ChatList
                g_ChatList_index = g_ChatList_Array.count - 1
                
                let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
                let messageData = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                newMessage_channelHeader.updateChildValues(messageData)
                
                
                
                /*let newMessage_channelHeader2 = FIRDatabase.database().reference().child("channelHeaders").child(g_ChatList_Array[g_ChatList_index].uid).child((user?.uid)!)
                let messageData2 = ["updatedAt": [".sv": "timestamp"]] as [String : Any]
                newMessage_channelHeader2.updateChildValues(messageData)*/

            } else {
                
                g_ChatList_Array.append(Temp_ChatList)
                g_ChatList_index = g_ChatList_Array.count - 1
                
                let newMessage_channelHeader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(g_ChatList_Array[g_ChatList_index].uid)
                let messageData = ["createdAt": createdAt1, "updatedAt": updatedAt1] as [String : Any]
                newMessage_channelHeader.setValue(messageData)
         
                /*let newMessage_channelHeader2 = FIRDatabase.database().reference().child("channelHeaders").child(g_ChatList_Array[g_ChatList_index].uid).child((user?.uid)!)
                let messageData2 = ["createdAt": [".sv": "timestamp"], "updatedAt": [".sv": "timestamp"]] as [String : Any]
                newMessage_channelHeader2.setValue(messageData2)*/
            }
        }*/
        
        //navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)

    }
    
    
}
