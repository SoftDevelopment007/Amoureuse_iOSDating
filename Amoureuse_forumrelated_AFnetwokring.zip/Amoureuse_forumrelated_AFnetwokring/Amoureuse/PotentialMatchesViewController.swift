//
//  PotentialMatchesViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/6/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import SDWebImage

import CoreLocation
import ImageSlideshow

import FirebaseMessaging

import Alamofire
import SwiftyJSON


class PotentialMatchesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var textBackNoSearchLabel: UILabel!
    @IBOutlet weak var BackNoSearchImageView: UIImageView!
    
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        tableView.tableHeaderView = UIView()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        
        
        

        /*refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        
        if g_Potential_Array.count < 1 {
            refreshControl.addTarget(self, action: #selector(self.handleRefresh(sender:)), for: UIControlEvents.valueChanged)
        }
        
        self.tableView.addSubview(refreshControl)*/
        
        //=================================================================================
        ProgressHUD.show("Loading...")
        DownLoadPotential(completion: {
            
            ProgressHUD.dismiss()
            
            /*if self.success == true {
                
                self.success = false
                
                self.textBackNoSearchLabel.isHidden = true
                self.BackNoSearchImageView.isHidden = true
            } else {
            
                //self.textBackNoSearchLabel.isHidden = false
                //self.BackNoSearchImageView.isHidden = false
            }*/
            
            if g_Potential_Array.count < 1 {
                self.textBackNoSearchLabel.isHidden = false
                self.BackNoSearchImageView.isHidden = false
            } else {
                self.textBackNoSearchLabel.isHidden = true
                self.BackNoSearchImageView.isHidden = true
            }
        })
        //================================================================================
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if g_Potential_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        if g_Potential_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
        
        tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handleRefresh(sender:AnyObject) {
        // Code to refresh table view
        
        
        /*g_Potential_Array.removeAll()
        g_Potential_localSource.removeAll()
        g_Potential_Grid_thumbUrl.removeAll()
        g_Potential_Grid_thumbImage.removeAll()
        g_Potential_index = -1*/
        
        /*if g_Potential_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }*/

//        initialPotential = false
//        DownLoadPotential()

        //refreshControl.endRefreshing()
        
    }
    
    //====================================================================================
    //
    //
    //      DownLoadPotential()
    //
    //
    //====================================================================================
    
    var success: Bool = false
    
    func DownLoadPotential(completion: @escaping (Void) -> Void) {
        
        self.success = false

        //initialPotential = false
        
        g_Potential_Array.removeAll()
        self.tableView.reloadData()
        
        g_Potential_localSource.removeAll()
        g_Potential_Grid_thumbUrl.removeAll()
        g_Potential_Grid_thumbImage.removeAll()
        g_Potential_index = -1

        
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)

        let date = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        
        var FlagCnt_1: Int = 0
        
        var handle: UInt = 0
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        handle = Ref_locations.observe(.value , with: { (snapshot: FIRDataSnapshot!) in
            
            
            if (!initialPotential) {
                
                if snapshot.exists() {
                    
                    initialPotential = true
                    Ref_locations.removeObserver(withHandle: handle)
                    
                    
                    print("location snapshot exists")
                    print(snapshot.childrenCount)
                    FlagCnt_1 = 0
                        //**********************************************************************************************************************************************
                        for snap in snapshot.children {
                            let userSnap = snap as! FIRDataSnapshot
                            let uid = userSnap.key //the uid of each user
                            
                            
                            
                                //--------------------------------------------------------------------------------------------------------------------------------------
                                if uid != (user?.uid)! {
                                    
                                    
                                        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                                        let Ref_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(uid)
                                        Ref_channelLikes.observe(.value, with: { (channelLikes_snapshot: FIRDataSnapshot!) in
                                            
                                            DispatchQueue.main.async {
                                            
                                            
                                                if !channelLikes_snapshot.exists() { //Don't have child --> True.(Before, user were not setting like or dislike)
                                                    print(uid)
                                                    
                                                    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                    DispatchQueue.main.async {
                                                        
                                                        let Ref_Profiles_uid = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                                        Ref_Profiles_uid.observe(.value, with: { (public_snapshot: FIRDataSnapshot!) in
                                                            
                                                            //DownLoad public.
                                                            if let public_dict = public_snapshot.value as?  NSDictionary {
                                                                
                                                                var yearOfBirth = public_dict["yearOfBirth"]        as? String ?? ""
                                                                var gender      = public_dict["gender"]             as? String ?? ""
                                                                
                                                                var avatarUrl   = public_dict["avatarThumb"]        as? String ?? ""
                                                                var coverUrl    = public_dict["coverImageThumb"]    as? String ?? ""
                                                                var name        = public_dict["name"]               as? String ?? ""
                                                                var bio         = public_dict["bio"]                as? String ?? ""
                                                                var interests   = public_dict["interests"]          as? String ?? ""
                                                                
                                                                
                                                                let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                yearOfBirth = yearOfBirth.substring(to: index)
                                                                print(yearOfBirth) // 2017
                          
                                                                //Condition1 Age ======================================================================================
                                                                if (Int(year) - Int(yearOfBirth)!) >= g_age_minimum && (Int(year) - Int(yearOfBirth)!) <= g_age_maximum {
                                                                    print(yearOfBirth)
                                                                    
                                                                    //Condition2 Gender -------------------------------------------------------------------------------
                                                                    if  (gender == "Male" && g_gender == 1)   ||
                                                                        (gender == "Female" && g_gender == 2) ||
                                                                        (g_gender == 3) {
                                                                      
                                                                        //Condition3 Distance .........................................................................
                                                                        var handle_2: UInt = 0
                                                                        
                                                                        
                                                                        let Ref_Locations_uid = FIRDatabase.database().reference().child("locations").child(uid).child("l")
                                                                        handle_2 = Ref_Locations_uid.observe(.value, with: { (Location_snapshot: FIRDataSnapshot!) in
                                                                            
                                                                            Ref_Locations_uid.removeObserver(withHandle: handle_2)
                                                                            
                                                                            
                                                                            print(Location_snapshot.value)
                                                                            
                                                                            if let Location_dict = Location_snapshot.value as?  [Double] {
                                                                                
                                                                                let latitude = Double(Location_dict[0])
                                                                                let longitude = Double(Location_dict[1])
                                                                                
                                                                                print(latitude)
                                                                                print(longitude)
                                                                                print(g_latitude)
                                                                                print(g_longitude)
                                                                                
                                                                                
                                                                                let coordinate1 = CLLocation(latitude: latitude, longitude: longitude)
                                                                                let coordinate2 = CLLocation(latitude: g_longitude, longitude: g_longitude)
                                                                                let distanceInMeters = coordinate1.distance(from: coordinate2)
                                                                                
                                                                                print(distanceInMeters)
                                                                                
                                                                                if(distanceInMeters <= Double(g_maxDistance) * 1000.0)
                                                                                {
                                                                                    // under g_maxDistance
                                                                                    
                                                                                    //================================================================================
                                                                                    // Start DownLoad Ok_Conditioned users...
                                                                                    //================================================================================
                                                                                    
                                                                                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                                                                                    print(uid)
                                                                                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                                                                                    
                                                                                    
                                                                                    
                                                                                    DispatchQueue.main.async {
                                                                                        
                                                                                        //avatarImage DownLoad
                                                                                        let downloader_avatar = SDWebImageDownloader.shared()
                                                                                        downloader_avatar.downloadImage(with: NSURL(string: avatarUrl)! as URL, options: [], progress: nil, completed: { (image_avatar, data_avatar, error_avatar, finished_avatar) in
                                                                                            
                                                                                            if error_avatar != nil {
                                                                                                
                                                                                                print("some error!")
                                                                                                
                                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                                if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                                                    completion()
                                                                                                }
                                                                                                
                                                                                                
                                                                                            } else {
                                                                                                            DispatchQueue.main.async{
                                                                                                                
                                                                                                                if image_avatar != nil {
                                                                                                                    
                                                                                                                    //coverImage DownLoad
                                                                                                                    let downloader_cover = SDWebImageDownloader.shared()
                                                                                                                    downloader_cover.downloadImage(with: NSURL(string: coverUrl)! as URL, options: [], progress: nil, completed: { (image_cover, data_cover, error_cover, finished_cover) in
                                                                                                                        
                                                                                                                        if error_cover != nil {
                                                                                                                            print("some error!")
                                                                                                                            
                                                                                                                            FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                            if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                                                                                completion()
                                                                                                                            }
                                                                                                                        } else {
                                                                                                                            
                                                                                                                                        DispatchQueue.main.async{
                                                                                                                                            
                                                                                                                                            if image_cover != nil {
                                                                                                                                                
                                                                                                                                                
                                                                                                                                                var Potentila_temp: UserInfo = UserInfo( title:     "",
                                                                                                                                                                                         avatarUrl: "",
                                                                                                                                                                                         coverUrl:  "",
                                                                                                                                                                                         name:      "",
                                                                                                                                                                                         bio:       "",
                                                                                                                                                                                         gender:    "",
                                                                                                                                                                                         interests: "",
                                                                                                                                                                                         
                                                                                                                                                                                         avatarImage:  #imageLiteral(resourceName: "profile.png"),
                                                                                                                                                                                         coverImage:   #imageLiteral(resourceName: "splash"),
                                                                                                                                                                                         
                                                                                                                                                                                         uid:       ""
                                                                                                                                                )
                                                                                                                                                
                                                                                                                                                Potentila_temp.avatarUrl   = avatarUrl
                                                                                                                                                Potentila_temp.coverUrl    = coverUrl
                                                                                                                                                Potentila_temp.name        = name
                                                                                                                                                Potentila_temp.bio         = bio
                                                                                                                                                Potentila_temp.gender      = gender
                                                                                                                                                Potentila_temp.interests   = interests
                                                                                                                                                
                                                                                                                                                Potentila_temp.uid         = uid
                                                                                                                                                
                                                                                                                                                Potentila_temp.title       = "\(Potentila_temp.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                                                                                                
                                                                                                                                                Potentila_temp.avatarImage = Utils.profileImage(image: image_avatar!)
                                                                                                                                                Potentila_temp.coverImage = image_cover!
                                                                                                                                                
                                                                                                                                                //New Data Append & Reload
                                                                                                                                                //+++++++++++++++++++++++++++++++++++++++
                                                                                                                                                g_Potential_Array.append(Potentila_temp)
                                                                                                                                                //+++++++++++++++++++++++++++++++++++++++
                                                                                                                                                
                                                                                                                                                //initialPotential = true
                                                                                                                                                
                                                                                                                                                //self.refreshControl.endRefreshing()
                                                                                                                                                
                                                                                                                                                print(FlagCnt_1)
                                                                                                                                                print(uid)                                                                                                                                                
                                                                                                                                                self.tableView.reloadData()
                                                                                                                                                
                                                                                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                                                                                print(Int(snapshot.childrenCount - 1))
                                                                                                                                                if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                                                                                                    
                                                                                                                                                    print(FlagCnt_1)
                                                                                                                                                    
                                                                                                                                                    self.success = true
                                                                                                                                                    //self.tableView.reloadData()
                                                                                                                                                    completion()
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                
                                                                                                                                                
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                    }) 
                                                                                                                    
                                                                                                                }
                                                                                                            }
                                                                                            }
                                                                                            
                                                                                        })
                                                                                        
                                                                                    }
                                                                                    
                                                                                    //=================================================================================
                                                                                    
                                                                                } else {
                                                                                    // out of g_maxDistance
                                                                                    print("don't find distance march.")
                                                                                    
                                                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                                                    if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                                        print("Ref_channelLikes doesn't snapshot exists")
                                                                                        
                                                                                        if g_Potential_Array.count < 1 {
                                                                                            self.textBackNoSearchLabel.isHidden = false
                                                                                            self.BackNoSearchImageView.isHidden = false
                                                                                        } else {
                                                                                            self.textBackNoSearchLabel.isHidden = true
                                                                                            self.BackNoSearchImageView.isHidden = true
                                                                                        }
                                                                                        self.success = false
                                                                                        completion()
                                                                                    }
                                                                                }
                                                                                
                                                                            } else {
                                                                                print("Error - Not Found Location...")
                                                                                
                                                                                FlagCnt_1 = FlagCnt_1 + 1
                                                                                if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                                    print("Ref_channelLikes doesn't snapshot exists")
                                                                                    
                                                                                    if g_Potential_Array.count < 1 {
                                                                                        self.textBackNoSearchLabel.isHidden = false
                                                                                        self.BackNoSearchImageView.isHidden = false
                                                                                    } else {
                                                                                        self.textBackNoSearchLabel.isHidden = true
                                                                                        self.BackNoSearchImageView.isHidden = true
                                                                                    }
                                                                                    self.success = false
                                                                                    completion()
                                                                                }
                                                                            }
                                                                            
                                                                        }) { (error) in
                                                                            
                                                                            if g_Potential_Array.count < 1 {
                                                                                self.textBackNoSearchLabel.isHidden = false
                                                                                self.BackNoSearchImageView.isHidden = false
                                                                            } else {
                                                                                self.textBackNoSearchLabel.isHidden = true
                                                                                self.BackNoSearchImageView.isHidden = true
                                                                            }
                                                                            self.success = false
                                                                            print(error.localizedDescription)
                                                                        }
                                                                        //.............................................................................................
                                                                        
                                                                        
                                                                        
                                                                    } else {
                                                                        print("don't find -- gender march.")
                                                                        //self.refreshControl.endRefreshing()
                                                                        
                                                                        FlagCnt_1 = FlagCnt_1 + 1
                                                                        if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                            print("Ref_channelLikes doesn't snapshot exists")
                                                                            
                                                                            if g_Potential_Array.count < 1 {
                                                                                self.textBackNoSearchLabel.isHidden = false
                                                                                self.BackNoSearchImageView.isHidden = false
                                                                            } else {
                                                                                self.textBackNoSearchLabel.isHidden = true
                                                                                self.BackNoSearchImageView.isHidden = true
                                                                            }
                                                                            self.success = false
                                                                            completion()
                                                                        }
                                                                    }
                                                                    // ------------------------------------------------------------------------------------------------
                                                                    
                                                                    
                                                                } else {
                                                                    print("don't find -- age march.")
                                                                    //self.refreshControl.endRefreshing()
                                                                    
                                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                                    if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                                        print("Ref_channelLikes doesn't snapshot exists")
                                                                        
                                                                        if g_Potential_Array.count < 1 {
                                                                            self.textBackNoSearchLabel.isHidden = false
                                                                            self.BackNoSearchImageView.isHidden = false
                                                                        } else {
                                                                            self.textBackNoSearchLabel.isHidden = true
                                                                            self.BackNoSearchImageView.isHidden = true
                                                                        }
                                                                        self.success = false
                                                                        completion()
                                                                    }
                                                                }
                                                                //=====================================================================================================
                                                                
                                                            } //Ref_Profile
                                                        })
                                                    }
                                                    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                    
                                                } else {
                                                    //self.refreshControl.endRefreshing()
                                                    
                                                    FlagCnt_1 = FlagCnt_1 + 1
                                                    if FlagCnt_1 == Int(snapshot.childrenCount - 1) {
                                                        print("Ref_channelLikes doesn't snapshot exists")
                                                        
                                                        if g_Potential_Array.count < 1 {
                                                            self.textBackNoSearchLabel.isHidden = false
                                                            self.BackNoSearchImageView.isHidden = false
                                                        } else {
                                                            self.textBackNoSearchLabel.isHidden = true
                                                            self.BackNoSearchImageView.isHidden = true
                                                        }
                                                        self.success = false
                                                        completion()
                                                    }
                                                    
                                                }
                                            }
                                        })
                                        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                                    
                                }
                                //----------------------------------------------------------------------------------------------------------------------------------------
                            
                            
                        }
                        //************************************************************************************************************************************************
                    
                } else {
                    print("location snapshot don't exists")
                    
                    if g_Potential_Array.count < 1 {
                        self.textBackNoSearchLabel.isHidden = false
                        self.BackNoSearchImageView.isHidden = false
                    } else {
                        self.textBackNoSearchLabel.isHidden = true
                        self.BackNoSearchImageView.isHidden = true
                    }
                    self.success = false
                    completion()
                }
            } else {
                //print(initialPotential)
                
                if g_Potential_Array.count < 1 {
                    self.textBackNoSearchLabel.isHidden = false
                    self.BackNoSearchImageView.isHidden = false
                } else {
                    self.textBackNoSearchLabel.isHidden = true
                    self.BackNoSearchImageView.isHidden = true
                }
                
                self.success = false
                
                completion()
            }
            
        }) { (error) in
            print(error.localizedDescription)
            
            if g_Potential_Array.count < 1 {
                self.textBackNoSearchLabel.isHidden = false
                self.BackNoSearchImageView.isHidden = false
            } else {
                self.textBackNoSearchLabel.isHidden = true
                self.BackNoSearchImageView.isHidden = true
            }
            self.success = false
            completion()
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func onTappedButton(_ sender: Any) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.popViewController(animated: true)
    }
    
    //=========================================================================================
    //
    //  Table Delegates
    //
    //=========================================================================================
    
    func initView() {
        tableView.reloadData()
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return g_Potential_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if g_Potential_Array.count < 1 {
            textBackNoSearchLabel.isHidden = false
            BackNoSearchImageView.isHidden = false
        } else {
            textBackNoSearchLabel.isHidden = true
            BackNoSearchImageView.isHidden = true
        }
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PotentialTableCell") as? PotentialTableCell
        
        
        
        
        
        cell?.avatarButton.setBackgroundImage(g_Potential_Array[indexPath.row].avatarImage, for: .normal)
        cell?.coverImageView.image = g_Potential_Array[indexPath.row].coverImage
        
        cell?.textNameAgeLabel.text     = g_Potential_Array[indexPath.row].title
        cell?.textAboutLabel.text       = g_Potential_Array[indexPath.row].bio
        cell?.textInterestLabel.text    = g_Potential_Array[indexPath.row].interests
        
        
        
        
        if indexPath.row == SECTION_INDEX {
            //cell?.ExpandButton.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png
        } else {
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)     //potential_menu_under.png
            //cell?.ExpandButton.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
        }
        
        
        
        
        cell?.dislikeButton.tag = indexPath.row
        //cell?.ExpandButton.addTarget(self, action: #selector(PotentialMatchesViewController.onTappedDisLikeButton(_:)), for: .touchUpInside)
        
        cell?.likeButton.tag = indexPath.row
        //cell?.ExpandButton.addTarget(self, action: #selector(PotentialMatchesViewController.onTappedLikeButton(_:)), for: .touchUpInside)
        
        cell?.ExpandButton.tag  =  indexPath.row
        //cell?.ExpandButton.addTarget(self, action: #selector(PotentialMatchesViewController.onTappedExpandButton(_:)), for: .touchUpInside)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? PotentialTableCell
        
        
        /*for dlg in (self.navigationController?.viewControllers)! {
            if dlg is HomeViewController {
                
                (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.name
                (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
            }
        }*/
        
        ProgressHUD.show("Loading...")
        DownLoadPictures(index: indexPath.row, completion: {
            
            g_Potential_index = indexPath.row
            self.performSegue(withIdentifier: StorySegues.FromPotentialToDetail.rawValue, sender: self)
            
            ProgressHUD.dismiss()
         })
        
        
        
        
    }
    
    var SECTION_INDEX: Int = -1
    
    //Change cell size
    func tableView(_ tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == SECTION_INDEX {
            return (410 + 0)
        } else {
            return (330 + 0)
        }
    }
    
    //====================================================================================================================
    //
    //  Cell Button Methods
    //
    //====================================================================================================================
    @IBAction func onTappedExpandButton(_ sender: Any) {
        
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PotentialTableCell
        
        /*if (sender as! UIButton).backgroundImage(for: .normal) == #imageLiteral(resourceName: "potential_menu_above.png") {   //potential_menu_above.png
            
            (sender as! UIButton).setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png

            SECTION_INDEX = -1
            tableView.reloadData()
            
        } else {
            
            (sender as! UIButton).setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
            
            SECTION_INDEX = index
            tableView.reloadData()
        }*/
        if cell?.ExpandButton_1.backgroundImage(for: .normal) == #imageLiteral(resourceName: "potential_menu_above.png") {   //potential_menu_above.png
            
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_under.png"), for: .normal)   //potential_menu_under.png
            
            SECTION_INDEX = -1
            tableView.reloadData()
            
        } else {
            
            cell?.ExpandButton_1.setBackgroundImage(#imageLiteral(resourceName: "potential_menu_above.png"), for: .normal)   //potential_menu_above.png
            
            SECTION_INDEX = index
            tableView.reloadData()
        }
        
    }
    
    @IBAction func onTappedDisLikeButton(_ sender: Any) {
 
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PotentialTableCell
        
        
        let user = FIRAuth.auth()?.currentUser
        
        //This is Dislikes
        /*let newMessage_dislike = FIRDatabase.database().reference().child("dislikes").childByAutoId()

        let messageData1 = ["potentialId": g_Potential_Array[index].uid, "userId": (user?.uid)!, "createdAt": [".sv": "timestamp"]] as [String : Any]
        //let messageData = ["createdAt": [".sv": "timestamp"], "potentialId": g_Potential_Array[index].uid, "userId": (user?.uid)!] as [String : Any]
        newMessage_dislike.setValue(messageData1)
        
        print(g_Potential_Array[index].uid)
        print((user?.uid)!)
        print([".sv": "timestamp"]) //FIRServerValue.timestamp()*/
 
        
        //This is channelLikes
        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Potential_Array[index].uid)
        newMessage_channelLikes.setValue(false)
        
        print(g_Potential_Array[index].uid)
        print((user?.uid)!)
        
        g_Potential_Array.remove(at: index)
        tableView.reloadData()
        
        if g_Potential_Array.count < 1 {
            self.textBackNoSearchLabel.isHidden = false
            self.BackNoSearchImageView.isHidden = false
        } else {
            self.textBackNoSearchLabel.isHidden = true
            self.BackNoSearchImageView.isHidden = true
        }
    }
    
    @IBAction func onTappedLikeButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PotentialTableCell
        
        let user = FIRAuth.auth()?.currentUser
        
        //This is likes
        /*let newMessage_like = FIRDatabase.database().reference().child("likes").childByAutoId()
        let messageData1 = ["createdAt": [".sv": "timestamp"], "potentialId": g_Potential_Array[index].uid, "userId": (user?.uid)!] as [String : Any]
        newMessage_like.setValue(messageData1)*/
        
        
        
        cell?.small_likeButton.setBackgroundImage(#imageLiteral(resourceName: "menu_icon_match_red.png"), for: .normal)
        //self.tableView.reloadData()
        
        //This is channelLikes
        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Potential_Array[index].uid)
        newMessage_channelLikes.setValue(true)
        
        print(g_Potential_Array[index].uid)
        print((user?.uid)!)
        
        // do stuff 2 seconds later
        //sleep(1)
        let when = DispatchTime.now() + 1 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            // Your code with delay
             g_Potential_Array.remove(at: index)
            cell?.small_likeButton.setBackgroundImage(#imageLiteral(resourceName: "potential_true.png"), for: .normal)
            self.tableView.reloadData()
        }
       
        self.tableView.reloadData()
        
        
        
        
        
        if g_Potential_Array.count < 1 {
            self.textBackNoSearchLabel.isHidden = false
            self.BackNoSearchImageView.isHidden = false
        } else {
            self.textBackNoSearchLabel.isHidden = true
            self.BackNoSearchImageView.isHidden = true
        }
        
        /*DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // do stuff 2 seconds later
            g_Potential_Array.remove(at: index)
            self.tableView.reloadData()
            
            if g_Potential_Array.count < 1 {
                self.textBackNoSearchLabel.isHidden = false
                self.BackNoSearchImageView.isHidden = false
            } else {
                self.textBackNoSearchLabel.isHidden = true
                self.BackNoSearchImageView.isHidden = true
            }
        }*/
        
        
        
        
        
            //===========================================================================================================
            //Post FCM
        
/*            PostNotificationFCM(SendUid: g_Potential_Array[index].uid, completion: {(flag) in
            
            if flag == true {
                
                print("okay")
                
                // [START log_fcm_reg_token]
//                let token = FIRMessaging.messaging().fcmToken
//                print("FCM token: \(token ?? "")")
                // [END log_fcm_reg_token]
                
                //FIRMessaging.messaging().sendMessage(message: ["title": "Hello", "body"‌​: "hello"], to: "/topics/topic2", withMessageID: "1", timeToLive: 1000)
                
                //============================================================================================
                
                
/////////       //self.postToFCM(SenderUid: g_Potential_Array[index].uid, SenderUserName: g_Potential_Array[index].name, myUserID: (user?.uid)!, completionHandler: {success in})
                
                
                
                let params: NSDictionary = [
                    
                    //"headers": ["Authorization": "key=AIzaSyCN5A7LxI7XKpwn7Os16YeaK-JdYrV8Ms4"],
                    
                    "notification": [
                        "body":         "UserName",
                        "title":        "New Match Added",
                        "sound":        "notification",
                        "click_action": "OPEN_HOME_ACTIVITY"
                    ],
                    
                    "data": [
                        "sender": "\(user?.uid)"
                    ],
                                            
                    "to": "/topics/\(g_Potential_Array[index].uid)"]
                
                
                let serviceObj = ServiceClass()
                
                serviceObj.servicePostMethodWithAPIHeaderValue(headerValue: "send", parameters: params as [NSObject : AnyObject], completion: { (responseObject) in
                    
                    
                    if (responseObject?["status"] as! NSNumber == 200 ) {
                        
                        let jsonData = try! JSONSerialization.data(withJSONObject: responseObject! as NSDictionary, options: JSONSerialization.WritingOptions.prettyPrinted)
                        
                        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
                        print(jsonString)
                    }
                        
                    else {
                        
                    }
                    
                })

                
                //============================================================================================
                
            } else {
            }
            
            //completion()
        })
*/
    }
 



    func postToFCM(SenderUid: String, SenderUserName: String, myUserID: String, completionHandler: @escaping (_ success: Bool) -> ()) {
        
//        let parameters = ["notification": [
//    
//                                            "title": "New Match Added",
//                                            //"text": SenderUserName,
//                                            "body": "king",
//                                            "sound": "notification",
//                                            "click_action": "OPEN_HOME_ACTIVITY"
//                                            ],
//                            "data":         [
//                                            "sender": myUserID
//                                            ],
//                            "to":           "/topics/" + SenderUid,
//                            "priority" :    "high"
//    
//        ] as [String : Any]
       
        
        let parameters = [
            
            "notification": [
                "body":         "UserName",
                "title":        "New Match Added",
                "sound":        "notification",
                "click_action": "OPEN_HOME_ACTIVITY"
            ],
            
            "data": [
                "sender": "\(myUserID)"
            ],
            
            "to": "/topics/\(SenderUid)"
            
        ] as [String : Any]
        
        Alamofire.request("https://fcm.googleapis.com/fcm/send", method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: ["Authorization": "key=AIzaSyCN5A7LxI7XKpwn7Os16YeaK-JdYrV8Ms4" ,"Content-Type": "application/json"])//.authenticate(user: "invallid", password: "credentials")
            .validate(statusCode: 200..<300)
            .responseJSON { response in
                
                switch response.result {
                case .success:
                    print(response)
                    //completionHandler(true)
                    
                case .failure(let error):
                    print(error)
                }
                
                //completionHandler(false)
        }
    }

    
    
    func PostNotificationFCM(SendUid: String, completion: @escaping (Bool) -> Void) {
        
        let user = FIRAuth.auth()?.currentUser
        print((user?.uid)!)
        
        let usersRef = FIRDatabase.database().reference(withPath: "channelLikes").child(SendUid)
        var handle: UInt = 0
        
        handle = usersRef.observe(.value, with: { snapshot in
            usersRef.removeObserver(withHandle: handle)
            
            if snapshot.exists() {
                
                let dic = snapshot.value as! [String: AnyObject]
                
                if dic[(user?.uid)!] == nil {
                    completion(false)
                } else {
                    
                    print(dic[(user?.uid)!])
                    completion(true)
                    //Start Post Notification to FCM
                    
                    
                    
                }
            } else {
                
                completion(false)
            }
            
        })
    }

    
    /*func PostNotificationFCM(completion: @escaping (Void) -> Void) {
        //func DownloadAllUsers(){
        
        //ProgressHUD.show("Loading...")
        
        //====================================================================
        //self.view.dodo.error("Coming soon...")
        
        let user = FIRAuth.auth()?.currentUser
        print((user?.email)!)
        
        let Ref = FIRDatabase.database().reference().child("users")
        let queryRef = Ref.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        var handle: UInt = 0
        handle = queryRef.observe(.childAdded, with: { (snapshot: FIRDataSnapshot!) in
            
            //queryRef.removeObserver(withHandle: handle)
            
            if let dict = snapshot.value as?  NSDictionary {
                
                let name        = dict["displayname"]       as? String ?? ""
                print(name)
                let userId      = dict["uID"]               as? String ?? ""
                print(userId)
                let profileUrl  = dict["profileUrl"]        as? String ?? ""
                print(profileUrl)
                
                
                self.view.dodo.error("Coming soon...")
                //ProgressHUD.dismiss()
                
                // Go back to the main thread to update the UI
                DispatchQueue.main.async {
                    
                    if userId != user?.uid {
                        self.addProfile(name: name, userId: userId, profileUrl: profileUrl)
                        
                        queryRef.removeObserver(withHandle: handle)
                        completion()
                        //self.tableView.reloadData()
                    } else {
                    }
                }
                
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }*/
    
    
    
    
    
    //====================================================================================================================
    //func DownLoadPictures(index: Int) {
    func DownLoadPictures(index: Int, completion: @escaping (Void) -> Void) {        
     
        g_Potential_localSource.removeAll()
        g_Potential_Grid_thumbUrl.removeAll()
        g_Potential_Grid_thumbImage.removeAll()
        
        
        
        let Ref_GridPictures = FIRDatabase.database().reference().child("gridPictures").child(g_Potential_Array[index].uid)
        
        Ref_GridPictures.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
                if snapshot.exists() {
                    print("Potential GridPicture snapshot exists")
                    print(snapshot.childrenCount)
                    
                    if let dict = snapshot.value as?  NSDictionary {
                        print(dict)
                        
                        let thumb_dict = dict["thumb"] as! Array<String>
                        print(thumb_dict)
                        print(thumb_dict.count)
                        
                        DispatchQueue.main.async {
                            
                            for i in 0 ... thumb_dict.count - 1 {
                                print("===================== \(i) ====================")
                                print(thumb_dict[Int(i)])
                                
                                //=============================================================================================
                                g_Potential_Grid_thumbUrl.append(thumb_dict[Int(i)])
                                //=============================================================================================
                                
                                //---------------------------------------------------------------------------------------------
                                DispatchQueue.main.async {
                                    
                                    //Grid Image DownLoad
                                    let downloader = SDWebImageDownloader.shared()
                                    downloader.downloadImage(with: NSURL(string: thumb_dict[Int(i)])! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                        
                                        DispatchQueue.main.async{
                                            
                                            if image != nil {
                                                
                                                //==============================================================================
                                                g_Potential_Grid_thumbImage.append(image!)
                                                g_Potential_localSource.append(ImageSource(image: image!))
                                                
                                                if i == thumb_dict.count - 1 {
                                                    completion()
                                                }
                                                //==============================================================================
                                                
                                            }
                                        }
                                    })
                                }
                                //----------------------------------------------------------------------------------------------
                            }
                        }
                        
                        
                    } else {
                        
                        print("Not --- if let dict = snapshot.value as?  NSDictionary {")
                    }
                }
                else {
                    print("Potential GridPicture doesn't snapshot exists")
                    completion()
                }
            
        })
        
    }
    
    
    

}
