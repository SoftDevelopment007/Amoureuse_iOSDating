//
//  Config.swift
//  Onefortheride
//
//  Created by mac on 25/11/15.
//  Copyright © 2015 mac. All rights reserved.
//

import Foundation
/*
 enum ProfileViewIndex: Int {
 case RESTAURANTS    = 0
 case SEARCHES       = 1
 case FRIENDS        = 2
 case REWARDS        = 3
 }*/

enum StorySegues: String {
    case FromSigninToHome               = "SigninToHome"
    case FromHomeToSignin               = "HomeToSignin"
    case FromHomeToEditProfile          = "HomeToEditProfile"
    
    case FromSigninToEmailSignin        = "SigninToEmailSignin"
    case FromEmailSigninToHome          = "EmailSigninToHome"
    case FromEmailSigninToEmailSignup   = "EmailSigninToEmailSignup"
    case FromEmailsignupToSignin        = "EmailsignupToSignin"
    
    case FromEmailSigninToEditProfile   = "EmailSigninToEditProfile"
    case FromSigninToEditProfile        = "SigninToEditProfile"
    case FromEditToGridImages           = "EditToGridImages"
    case FromHomeToSettings             = "HomeToSettings"
    case FromHomeToPotentialMatches     = "HomeToPotentialMatches"
    case FromEditProfileToHome          = "EditProfileToHome"
    case FromPotentialToDetail          = "PotentialToDetail"
    case FromHomeToMatched              = "HomeToMatched"
    case FromHomeToChatsList            = "HomeToChatsList"
    case FromMatchToChatView            = "MatchToChatView"
    //case FromMatchToChatContent         = "MatchToChatContent"
    case FromChatListToChatView         = "ChatListToChatView"
    case FromMatchDetailToChatView      = "MatchDetailToChatView"
    case FromMatchToMatchDetail         = "MatchToMatchDetail"
    

}

enum UserDialogs: String {
    /*case SigninIncorrect        = "Your login information is incorrect."
     case EmailIsTaken           = "That email address is already taken."*/
    case CompleteRequireFields  = "Please complete all required fields."
    /*case RequireEmailAddress    = "Email address should be required."
     case PasswordRecoveryFailed = "Recovery is failed. Try again."*/
    case PasswordNotMatch       = "Passwords do not match"
    case FacebookSignOK       = "success Login with Facebook"
    case GoogleSignOK       = "success Login with Google"
}
