//
//  MatchDetailViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/12/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import ImageSlideshow

class MatchDetailViewController: UIViewController {

    @IBOutlet weak var imageCover: UIImageView!
    @IBOutlet weak var buttonAvatar: UIButton!
    
    
    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textAboutLabel: UILabel!
    @IBOutlet weak var textInterestLabel: UILabel!
    
    //Grid Image
    @IBOutlet weak var gridImage1: UIImageView!
    @IBOutlet weak var gridImage2: UIImageView!
    @IBOutlet weak var gridImage3: UIImageView!
    @IBOutlet weak var gridImage4: UIImageView!
    @IBOutlet weak var gridImage5: UIImageView!
    @IBOutlet weak var gridImage6: UIImageView!
    
    //SlidShow
    @IBOutlet weak var slideshow: ImageSlideshow!
    
    @IBOutlet weak var image3Coma: UIImageView!
    @IBOutlet weak var btn3Coma: UIButton!
    @IBOutlet weak var btnRemove: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ShowRefresh()
        
        //SlideShow==========================================================================
        //slideshow.backgroundColor = UIColor.white
        slideshow.slideshowInterval = 5.0
        slideshow.pageControlPosition = PageControlPosition.underScrollView
        slideshow.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        slideshow.pageControl.pageIndicatorTintColor = UIColor.black
        slideshow.contentScaleMode = UIViewContentMode.scaleAspectFill
        
        slideshow.currentPageChanged = { page in
            //print("current page:", page)
        }
        
        // try out other sources such as `afNetworkingSource`, `alamofireSource` or `sdWebImageSource` or `kingfisherSource`
        slideshow.setImageInputs(g_Match_localSource)
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(MatchDetailViewController.didTap))
        slideshow.addGestureRecognizer(recognizer)
        //====================================================================================

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func didTap() {
        
        if g_Match_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
    
    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        self.textNameLabel.text     =   g_Match_Array[g_Match_index].title
        self.textAboutLabel.text    =   g_Match_Array[g_Match_index].bio
        self.textInterestLabel.text =   g_Match_Array[g_Match_index].interests
        
        
        self.imageCover.image =  g_Match_Array[g_Match_index].coverImage
        self.buttonAvatar.setBackgroundImage(g_Match_Array[g_Match_index].avatarImage, for: .normal)
        
        ShowRefresh()
        slideshow.setImageInputs(g_Match_localSource)
    }

    @IBAction func onTappedFullScreenViewButton(_ sender: Any) {
        if g_Match_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
    
    func ShowRefresh() {
        
        if g_Match_Grid_thumbImage.count > 0 {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
            
            for i in 0 ... g_Match_Grid_thumbImage.count - 1 {
                
                if i == 0 {
                    gridImage1.image = g_Match_Grid_thumbImage[0]
                }
                if i == 1 {
                    gridImage2.image = g_Match_Grid_thumbImage[1]
                }
                if i == 2 {
                    gridImage3.image = g_Match_Grid_thumbImage[2]
                }
                if i == 3 {
                    gridImage4.image = g_Match_Grid_thumbImage[3]
                }
                if i == 4 {
                    gridImage5.image = g_Match_Grid_thumbImage[4]
                }
                if i == 5 {
                    gridImage6.image = g_Match_Grid_thumbImage[5]
                }
            }
            
        } else {
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
        }
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTapped3ComaButton(_ sender: Any) {
        self.btn3Coma.isHidden = true
        self.image3Coma.isHidden = true
        self.btnRemove.isHidden = false
    }
    
    @IBAction func onTappedRemoveButton(_ sender: Any) {
        let user = FIRAuth.auth()?.currentUser
        
        let newMessage_channelLikes = FIRDatabase.database().reference().child("channelLikes").child((user?.uid)!).child(g_Match_Array[g_Match_index].uid)
        newMessage_channelLikes.setValue(false)
        
        print(g_Match_Array[g_Match_index].uid)
        print((user?.uid)!)
        
        g_Match_Array.remove(at: g_Match_index)
        
        self.btn3Coma.isHidden = false
        self.image3Coma.isHidden = false
        self.btnRemove.isHidden = true
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedChatButton(_ sender: Any) {
        self.performSegue(withIdentifier: StorySegues.FromMatchDetailToChatView.rawValue, sender: self)
    }
}
