//
//  ChatListTableCell.swift
//  Amoureuse
//
//  Created by LEE on 4/11/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit



class ChatListTableCell: UITableViewCell {
    
    
    @IBOutlet weak var avatarButton: UIButton!
   
    
    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textLastMessageLabel: UILabel!
    @IBOutlet weak var textTimeLabel: UILabel!

    
}
