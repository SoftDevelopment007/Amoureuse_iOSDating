//
//  EmailSignInController.swift
//  Amoureuse
//
//  Created by LEE on 3/16/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import Firebase

import FirebaseAuth
import FirebaseDatabase

import ImageSlideshow
import SDWebImage

class EmailSignInController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var passwordhintUIImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        passwordTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
      
    func textFieldDidChange(_ textField: UITextField) {
        if (passwordTextField.text?.isEmpty)! {
            passwordhintUIImageView.image = #imageLiteral(resourceName: "icon_password_false.jpg")
        }
        else {
            passwordhintUIImageView.image = #imageLiteral(resourceName: "icon_password_true.jpg")
        }
    }
    
    
    @IBAction func onTappedSigninButton(_ sender: Any) {
        //check the strlen of username and passname................................................................
        if ((emailTextField.text?.characters.count)! < 1 || (passwordTextField.text?.characters.count)! < 1) {
            self.view.dodo.error(UserDialogs.CompleteRequireFields.rawValue)
            return
        }
        
        //For Email_Signin using Firebase
        if self.emailTextField.text == "" || self.passwordTextField.text == ""
        {
            let alertController = UIAlertController(title: "Alert!", message: "Please enter an email and password.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            ProgressHUD.show("Loading...")
            
            FIRAuth.auth()?.signIn(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!) { (user, error) in
                
                if error == nil
                {
                    self.emailTextField.text = user!.email
                    //self.passwordTextField.text = ""
                    
                    //DispatchQueue.main.async {
                        
                        //ProgressHUD.dismiss()
                        
                        
                        //Set Firedatabase
                        /*let newUser = FIRDatabase.database().reference().child("Users").child(user!.uid)
                         newUser.setValue(["email": self.emailTextField.text!,
                         "profileUrl": "",
                         "id" : FIRAuth.auth()?.currentUser?.uid,
                         "userName" : "",
                         "overview": "This is my Overview"])
                         
                         newUser.setValue(["email": self.emailTextField.text!,
                         "profileUrl": "aaa",
                         "id" : FIRAuth.auth()?.currentUser?.uid,
                         "userName" : "bbb",
                         "overview": "This is my Overview"])*/
                        
                    
                        //=========================================================
                        //
                        //
                        
                        initialDataLoaded_private   = false;
                        initialDataLoaded_public    = false;
                        initialGridPictures         = false;
                        initialSearchingUsers       = false;
                        initialPotential            = false;
                        
                        self.DownLoadSettings()
                    
                        self.DownLoadPictures()
                        
                        self.DownLoadProfiles()
                        
                        
                        /*ProgressHUD.show("Loading...")
                        self.DownLoadProfiles(completion: {
                            
                            ProgressHUD.dismiss()
                            
                            if self.success == 3 {
                                
                                self.success = 0
                                
                                
                                let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                
                                rearView.delegate = frontView
                                let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                
                                //ok
                                UserDefaults.standard.set(true, forKey: "Signed")
                                
                                self.navigationController?.pushViewController(swViewController!, animated: true)
                                
                            }
                            
                            if self.success == 2 {
                                
                                self.success = 0
                                
                                //ok
                                UserDefaults.standard.set(true, forKey: "Signed")
                                
                                self.performSegue(withIdentifier: StorySegues.FromEmailSigninToEditProfile.rawValue, sender: self)
                            }
                    
                        })*/
                        
                        //
                        //
                        //=========================================================
/*
                        
                        let transition = CATransition()
                        transition.duration = 0.3
                        transition.type = "flip"
                        transition.subtype = kCATransitionFromLeft
                        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
                        
                        let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                        let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                        
                        rearView.delegate = frontView
                        let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                        self.navigationController?.pushViewController(swViewController!, animated: true)
 */
                    //}
                    
                }
                else
                {
                    ProgressHUD.dismiss()
                    
                    let alertController = UIAlertController(title: "Alert!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }

    
    @IBAction func onTappedSignupButton(_ sender: Any) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.performSegue(withIdentifier: StorySegues.FromEmailSigninToEmailSignup.rawValue, sender: self)
    }
    
    
    
    
    //=======================================================================================================================================
    //
    //
    //
    //    DownLoads All Infor
    //
    //
    //=======================================================================================================================================
/*    var success: Int = 0
    
    func DownLoadProfiles(completion: @escaping (Void) -> Void) {
        
        self.success = 0

        self.view.dodo.error("Coming Soon...")
        
        /*let transition = CATransition()
         transition.duration = 0.3
         transition.type = "flip"
         transition.subtype = kCATransitionFromLeft
         self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        
        //Check rigestered in firebase with profile before.........................................................
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        
        
        let Ref_private = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("private")
        //let queryRef_private = Ref_private.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        let Ref_public = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("public")
        //let queryRef_public = Ref_public.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)


        Ref_private.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialDataLoaded_private) {
                if snapshot.exists() {
                    
                    g_NewProfileFlag_private = 1
                    print("\((user?.uid)!) -- private snapshot exists")
                    
                    
                    //DownLoad private.
                    if let dict = snapshot.value as?  NSDictionary {
                        
                        let dob    = dict["dob"]         as? String ?? ""
                        print(dob)
                        let role   = dict["role"]        as? String ?? ""
                        print(role)
                        let createdAt_private    = dict["createdAt_private"]         as? String ?? ""
                        print(createdAt_private)
                        
                        self.success = self.success + 1
                        
                        // Go back to the main thread to update the UI
                        DispatchQueue.main.async {
                            
                            //====================================================================================
                            curProfileInfo.dob                  = dob
                            curProfileInfo.role                 = role
               
                            //====================================================================================
                            
                            Ref_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                                
                                if (!initialDataLoaded_public) {
                                    
                                    if snapshot.exists() {
                                        print("\((user?.uid)!) -- public snapshot exists")
                                        
                                        g_NewProfileFlag_public = 1
                                        
                                        //DownLoad private.
                                        if let dict = snapshot.value as?  NSDictionary {
                                            
                                            let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                            print(avatarStandard)
                                            let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                            print(avatarThumb)
                                            let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                            print(coverImageStandard)
                                            let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                            print(coverImageThumb)
                                            
                                            let bio                    = dict["bio"]                    as? String ?? ""
                                            print(bio)
                                            let gender                 = dict["gender"]                 as? String ?? ""
                                            print(gender)
                                            let interests              = dict["interests"]              as? String ?? ""
                                            print(interests)
                                            let name                   = dict["name"]                   as? String ?? ""
                                            print(name)
                                            let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                            print(yearOfBirth)
                                            let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                            print(createdAt_public)
                                            
                                            DispatchQueue.main.async {
                                                
                                                //---------------------------------------------------------------------------
                                                //Cover Image DownLoad
                                                let downloader_cover_thumb = SDWebImageDownloader.shared()
                                                downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image_cover, data_cover, error_cover, finished_cover) in
                                                    
                                                    DispatchQueue.main.async{
                                                        
                                                        if error_cover != nil {
                                                            
                                                            print("some error!")
                                                            completion()
                                                        } else {
                                                            
                                                            if image_cover != nil {
                                                                
                                                                Temp_coverImageThumb_UI = image_cover!
                                                                coverImageThumb_UI      = image_cover!
                                                                
                                                                let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                                downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image_avatar, data_avatar, error_avatar, finished_avatar) in
                                                                    
                                                                    DispatchQueue.main.async{
                                                                        
                                                                        if error_avatar != nil {
                                                                            
                                                                            print("some error!")
                                                                            completion()
                                                                        } else {
                                                                            
                                                                            if image_avatar != nil {
                                                                                //Temp_avatarThumb_UI      = image_avatar!
                                                                                Temp_avatarThumb_UI        = Utils.profileImage(image: image_avatar!)
                                                                                //avatarThumb_UI           = image_avatar!
                                                                                avatarThumb_UI             = Utils.profileImage(image: image_avatar!)
                                                                                
                                                                                //---------------------------------------------------------------------------
                                                                                //these are urls
                                                                                curProfileInfo.avatarStandard       = avatarStandard
                                                                                curProfileInfo.avatarThumb          = avatarThumb
                                                                                curProfileInfo.coverImageStandard   = coverImageStandard
                                                                                curProfileInfo.coverImageThumb      = coverImageThumb
                                                                                
                                                                                //these are texts
                                                                                curProfileInfo.bio                  = bio
                                                                                curProfileInfo.gender               = gender
                                                                                curProfileInfo.interests            = interests
                                                                                curProfileInfo.name                 = name
                                                                                curProfileInfo.yearOfBirth          = yearOfBirth
                                                                                
                                                                                let date = Date()
                                                                                let calendar = Calendar.current
                                                                                let year = calendar.component(.year, from: date)
                                                                                
                                                                                var yearOfBirth = curProfileInfo.yearOfBirth
                                                                                let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                                yearOfBirth = yearOfBirth.substring(to: index)
                                                                                print(yearOfBirth) // 2017
                                                                                curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                                
                                                                                
                                                                                print("==================== Success finished Loading =========================")
                                                                                
                                                                                for dlg in (self.navigationController?.viewControllers)! {
                                                                                    if dlg is HomeViewController {
                                                                                        
                                                                                        (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                                        (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                                        (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                                    }
                                                                                }
                                                                                
                                                                                
                                                                                self.success = self.success + 2
                                                                                initialDataLoaded_public = true
                                                                                initialDataLoaded_private = true
                                                                                completion()
                                                                                //----------------------------------------------------------------------------
                                                                                
                                                                            } else {
                                                                                self.success = self.success + 1
                                                                                initialDataLoaded_public = true
                                                                                initialDataLoaded_private = true
                                                                                completion()
                                                                            }
                                                                        }
                                                                        
                                                                        
                                                                        
                                                                    }
                                                                })
                                                            } else {
                                                                self.success = self.success + 1
                                                                initialDataLoaded_public = true
                                                                initialDataLoaded_private = true
                                                                completion()
                                                            }
                                                        }
                                                    }
                                                })
                                            }
                                        } else {
                                            self.success = self.success + 1
                                            initialDataLoaded_public = true
                                            initialDataLoaded_private = true
                                            completion()
                                        }
                                    } else {
                                        
                                        //...................................
                                        //Real First visit
                                        Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                                        Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                                        //...................................
                                        
                                        g_NewProfileFlag_public = 0
                                        print("public snapshot doesn't exists")
                                        
                                        self.success = self.success + 1
                                        initialDataLoaded_public = true
                                        initialDataLoaded_private = true
                                        completion()
                                    }
                                    
                                }//if (initialDataLoaded_public)
                            })
                        }//private DispatchQueue.main.async
                    }//if let dict = snapshot.value as?  NSDictionary
                    
                } else {
                    
                    self.success = self.success + 1
                    g_NewProfileFlag_private = 0
                    print("private snapshot doesn't exists")
                    
                    Ref_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                        
                        if (!initialDataLoaded_public) {
                            
                            if snapshot.exists() {
                                print("\((user?.uid)!) -- public snapshot exists")
                                
                                g_NewProfileFlag_public = 1
                                
                                //DownLoad private.
                                if let dict = snapshot.value as?  NSDictionary {
                                    
                                    let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                    print(avatarStandard)
                                    let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                    print(avatarThumb)
                                    let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                    print(coverImageStandard)
                                    let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                    print(coverImageThumb)
                                    
                                    let bio                    = dict["bio"]                    as? String ?? ""
                                    print(bio)
                                    let gender                 = dict["gender"]                 as? String ?? ""
                                    print(gender)
                                    let interests              = dict["interests"]              as? String ?? ""
                                    print(interests)
                                    let name                   = dict["name"]                   as? String ?? ""
                                    print(name)
                                    let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                    print(yearOfBirth)
                                    let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                    print(createdAt_public)
                                    
                                    DispatchQueue.main.async {
                                        
                                        //---------------------------------------------------------------------------
                                        //Cover Image DownLoad
                                        let downloader_cover_thumb = SDWebImageDownloader.shared()
                                        downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image_cover, data_cover, error_cover, finished_cover) in
                                            
                                            DispatchQueue.main.async{
                                                
                                                if error_cover != nil {
                                                    
                                                    print("some error!")
                                                    completion()
                                                } else {
                                                    
                                                    if image_cover != nil {
                                                        
                                                        Temp_coverImageThumb_UI = image_cover!
                                                        coverImageThumb_UI      = image_cover!
                                                        
                                                        let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                        downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image_avatar, data_avatar, error_avatar, finished_avatar) in
                                                            
                                                            DispatchQueue.main.async{
                                                                
                                                                if error_avatar != nil {
                                                                    
                                                                    print("some error!")
                                                                    completion()
                                                                } else {
                                                                    
                                                                    if image_avatar != nil {
                                                                        //Temp_avatarThumb_UI      = image_avatar!
                                                                        Temp_avatarThumb_UI        = Utils.profileImage(image: image_avatar!)
                                                                        //avatarThumb_UI           = image_avatar!
                                                                        avatarThumb_UI             = Utils.profileImage(image: image_avatar!)
                                                                        
                                                                        //---------------------------------------------------------------------------
                                                                        //these are urls
                                                                        curProfileInfo.avatarStandard       = avatarStandard
                                                                        curProfileInfo.avatarThumb          = avatarThumb
                                                                        curProfileInfo.coverImageStandard   = coverImageStandard
                                                                        curProfileInfo.coverImageThumb      = coverImageThumb
                                                                        
                                                                        //these are texts
                                                                        curProfileInfo.bio                  = bio
                                                                        curProfileInfo.gender               = gender
                                                                        curProfileInfo.interests            = interests
                                                                        curProfileInfo.name                 = name
                                                                        curProfileInfo.yearOfBirth          = yearOfBirth
                                                                        
                                                                        let date = Date()
                                                                        let calendar = Calendar.current
                                                                        let year = calendar.component(.year, from: date)
                                                                        
                                                                        var yearOfBirth = curProfileInfo.yearOfBirth
                                                                        let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                        yearOfBirth = yearOfBirth.substring(to: index)
                                                                        print(yearOfBirth) // 2017
                                                                        curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                        
                                                                        curProfileInfo.dob                  = yearOfBirth
                                                                        
                                                                        
                                                                        print("==================== Success finished Loading =========================")
                                                                        
                                                                        for dlg in (self.navigationController?.viewControllers)! {
                                                                            if dlg is HomeViewController {
                                                                                
                                                                                (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                                (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                                (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                            }
                                                                        }
                                                                        
                                                                        
                                                                        self.success = self.success + 1
                                                                        initialDataLoaded_public = true
                                                                        initialDataLoaded_private = true
                                                                        completion()
                                                                        //----------------------------------------------------------------------------
                                                                        
                                                                    } else {
                                                                        self.success = self.success + 1
                                                                        initialDataLoaded_public = true
                                                                        initialDataLoaded_private = true
                                                                        completion()
                                                                    }
                                                                }
                                                                
                                                                
                                                                
                                                            }
                                                        })
                                                    } else {
                                                        self.success = self.success + 1
                                                        initialDataLoaded_public = true
                                                        initialDataLoaded_private = true
                                                        completion()
                                                    }
                                                }
                                            }
                                        })
                                    }
                                } else {
                                    self.success = self.success + 1
                                    initialDataLoaded_public = true
                                    initialDataLoaded_private = true
                                    completion()
                                }
                            } else {
                                
                                //...................................
                                //Real First visit
                                Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                                Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                                //...................................
                                
                                g_NewProfileFlag_public = 0
                                print("public snapshot doesn't exists")
                                
                                self.success = self.success + 1
                                initialDataLoaded_public = true
                                initialDataLoaded_private = true
                                completion()
                            }
                            
                        }//if (initialDataLoaded_public)
                    })
                }
            }
        })
    }*/
    
    func DownLoadPictures() {
        
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        let Ref_GridPictures = FIRDatabase.database().reference().child("gridPictures").child((user?.uid)!) //.child("thumb")
        //let queryRef_GridPictures = Ref_GridPictures.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        
        Ref_GridPictures.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialGridPictures) {
                
                initialGridPictures = true
                
                if snapshot.exists() {
                    print("public snapshot exists")
                    print(snapshot.childrenCount)
                    
                    if let dict = snapshot.value as?  NSDictionary {
                        print(dict)
                        
                        
                        //let thumb_dict = dict["1"] as! [String: AnyObject]
                        let thumb_dict = dict["thumb"] as! Array<String>
                        print(thumb_dict)
                        print(thumb_dict.count)
                        
                        DispatchQueue.main.async {
                            
                            for i in 0 ... thumb_dict.count - 1 {
                                print("===================== \(i) ====================")
                                print(thumb_dict[Int(i)])
                                
                                //-------------------------------------------------------
                                DispatchQueue.main.async {
                                    
                                    //Grid Image DownLoad
                                    let downloader = SDWebImageDownloader.shared()
                                    downloader.downloadImage(with: NSURL(string: thumb_dict[Int(i)])! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                        
                                        DispatchQueue.main.async{
                                            
                                            if image != nil {
                                                g_gridImage.append(image!)
                                                g_localSource.append(ImageSource(image: image!))
                                                
                                                //initialGridPictures = true
                                            }
                                        }
                                    })
                                }
                                //-------------------------------------------------------
                            }
                        }
                        
                        
                    } else {
                        
                        print("Not --- if let dict = snapshot.value as?  NSDictionary {")
                    }
                }
                else {
                    print("public snapshot doesn't exists")
                    
                }
            }
        })
        
    }
    
    func DownLoadSettings() {
        
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        let Ref_SearchingUsers = FIRDatabase.database().reference().child("searchingUsers").child((user?.uid)!)
        
        Ref_SearchingUsers.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialSearchingUsers) {
                
                if snapshot.exists() {
                    print("public snapshot exists")
                    print(snapshot.childrenCount)
                    
                    if let dict = snapshot.value as?  NSDictionary {
                        print(dict)
                        
                        /*if let dict = snapshot.value as?  NSDictionary {
                         let avatarStandard         = dict["avatarStandard"]         as? String ?? ""*/
                        
                        //==========================================================
                        DispatchQueue.main.async {
                            
                            let age_dict = dict["age"] as? NSDictionary
                            g_age_maximum = (age_dict?["maximum"] as? Int)!
                            g_age_minimum = (age_dict?["minimum"] as? Int)!
                            
                            g_gender = (dict["gender"] as? Int)!
                            g_maxDistance = (dict["maxDistance"] as? Int)!
                            
                            initialSearchingUsers = true
                            
                        }
                        //==========================================================
                        
                    } else {
                        
                        print("Not --- if let dict = snapshot.value as?  NSDictionary {")
                    }
                }
                else {
                    print("public snapshot doesn't exists")
                    
                }
            }
        })
        
    }
    
    //=======================================================================================================================================
    //
    //
    //
    //    DownLoads All Infor
    //
    //
    //=======================================================================================================================================
    func DownLoadProfiles() {
        
//        self.view.dodo.error("Coming Soon...")
        
        /*let transition = CATransition()
         transition.duration = 0.3
         transition.type = "flip"
         transition.subtype = kCATransitionFromLeft
         self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        
        //Check rigestered in firebase with profile before.........................................................
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        
        
        let Ref_private = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("private")
        let queryRef_private = Ref_private.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        let Ref_public = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("public")
        let queryRef_public = Ref_public.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        
        ProgressHUD.show("Loading...")
        
        queryRef_private.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialDataLoaded_private) {
                if snapshot.exists() {
                    
                    initialDataLoaded_private = true
                    g_NewProfileFlag_private = 1
                    print("\((user?.uid)!) -- private snapshot exists")
                    
                    
                    //DownLoad private.
                    if let dict = snapshot.value as?  NSDictionary {
                        
                        let dob    = dict["dob"]         as? String ?? ""
                        print(dob)
                        let role   = dict["role"]        as? String ?? ""
                        print(role)
                        let createdAt_private    = dict["createdAt_private"]         as? String ?? ""
                        print(createdAt_private)
                        
                        
                        // Go back to the main thread to update the UI
                        DispatchQueue.main.async {
                            
                            //====================================================================================
                            curProfileInfo.dob                  = dob
                            curProfileInfo.role                 = role
                            
                            initialDataLoaded_private = true
                            //====================================================================================
                            
                            queryRef_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                                
                                if (!initialDataLoaded_public) {
                                    
                                    if snapshot.exists() {
                                        print("\((user?.uid)!) -- public snapshot exists")
                                        
                                        g_NewProfileFlag_public = 1
                                        //DownLoad private.
                                        if let dict = snapshot.value as?  NSDictionary {
                                            
                                            let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                            print(avatarStandard)
                                            let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                            print(avatarThumb)
                                            let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                            print(coverImageStandard)
                                            let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                            print(coverImageThumb)
                                            
                                            let bio                    = dict["bio"]                    as? String ?? ""
                                            print(bio)
                                            let gender                 = dict["gender"]                 as? String ?? ""
                                            print(gender)
                                            let interests              = dict["interests"]              as? String ?? ""
                                            print(interests)
                                            let name                   = dict["name"]                   as? String ?? ""
                                            print(name)
                                            let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                            print(yearOfBirth)
                                            let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                            print(createdAt_public)
                                            
                                            DispatchQueue.main.async {
                                                
                                                //---------------------------------------------------------------------------
                                                //Cover Image DownLoad
                                                let downloader_cover_thumb = SDWebImageDownloader.shared()
                                                downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                    
                                                    DispatchQueue.main.async{
                                                        
                                                        if image != nil {
                                                            Temp_coverImageThumb_UI = image!
                                                            coverImageThumb_UI      = image!
                                                            
                                                            let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                            downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                                
                                                                DispatchQueue.main.async{
                                                                    
                                                                    if image != nil {
                                                                        //Temp_avatarThumb_UI     = image!
                                                                        Temp_avatarThumb_UI     = Utils.profileImage(image: image!)
                                                                        //avatarThumb_UI          = image!
                                                                        avatarThumb_UI     = Utils.profileImage(image: image!)
                                                                        
                                                                        //---------------------------------------------------------------------------
                                                                        //these are urls
                                                                        curProfileInfo.avatarStandard       = avatarStandard
                                                                        curProfileInfo.avatarThumb          = avatarThumb
                                                                        curProfileInfo.coverImageStandard   = coverImageStandard
                                                                        curProfileInfo.coverImageThumb      = coverImageThumb
                                                                        
                                                                        //these are texts
                                                                        curProfileInfo.bio                  = bio
                                                                        curProfileInfo.gender               = gender
                                                                        curProfileInfo.interests            = interests
                                                                        curProfileInfo.name                 = name
                                                                        curProfileInfo.yearOfBirth          = yearOfBirth
                                                                        
                                                                        let date = Date()
                                                                        let calendar = Calendar.current
                                                                        let year = calendar.component(.year, from: date)
                                                                        
                                                                        var yearOfBirth = curProfileInfo.yearOfBirth
                                                                        let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                        yearOfBirth = yearOfBirth.substring(to: index)
                                                                        print(yearOfBirth) // 2017
                                                                        curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                        
                                                                        initialDataLoaded_private = true
                                                                        initialDataLoaded_public  = true
                                                                        //----------------------------------------------------------------------------
                                                                        
                                                                        
                                                                        print("============== Success finished Loading ==============")
                                                                        
                                                                        for dlg in (self.navigationController?.viewControllers)! {
                                                                            if dlg is HomeViewController {
                                                                                
                                                                                (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                                (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                                (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                            }
                                                                        }
                                                                        
                                                                        ProgressHUD.dismiss()
                                                                        
                                                                        let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                                                        let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                                                        
                                                                        rearView.delegate = frontView
                                                                        let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                                                        
                                                                        self.navigationController?.pushViewController(swViewController!, animated: true)
                                                                        
                                                                    } else {
                                                                        ProgressHUD.dismiss()
                                                                    }
                                                                }
                                                            })
                                                        } else {
                                                            ProgressHUD.dismiss()
                                                        }
                                                    }
                                                })
                                            }
                                        } else {
                                            ProgressHUD.dismiss()
                                        }
                                    } else {
                                        
                                        initialDataLoaded_public = true
                                        
                                        //...................................
                                        //Real First visit
                                        Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                                        Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                                        //...................................
                                        
                                        g_NewProfileFlag_public = 0
                                        print("public snapshot doesn't exists")
                                        
                                        ProgressHUD.dismiss()
                                        
                                        /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                         let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                         
                                         rearView.delegate = frontView
                                         let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                         
                                         self.navigationController?.pushViewController(swViewController!, animated: true)*/
                                        
                                        self.performSegue(withIdentifier: StorySegues.FromSigninToEditProfile.rawValue, sender: self)
                                    }
                                }//if (initialDataLoaded_public)
                                else {
                                    
                                }
                            })
                        }//private DispatchQueue.main.async
                    }//if let dict = snapshot.value as?  NSDictionary
                    
                } else {
                    
                    initialDataLoaded_private = true
                    initialDataLoaded_public  = true
                    
                    //...................................
                    //Real First visit
                    Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                    Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                    //...................................
                    
                    
                    g_NewProfileFlag_private = 0
                    print("private snapshot doesn't exists")
                    
                    ProgressHUD.dismiss()
                    
                    /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                     let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                     
                     rearView.delegate = frontView
                     let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                     
                     self.navigationController?.pushViewController(swViewController!, animated: true)*/
                    
                    self.performSegue(withIdentifier: StorySegues.FromEmailSigninToEditProfile.rawValue, sender: self)
                }
            }//if (initialDataLoaded_private)
            else{
                queryRef_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                    
                    if (!initialDataLoaded_public) {
                        
                        if snapshot.exists() {
                            print("public snapshot exists")
                            
                            g_NewProfileFlag_public = 1
                            //DownLoad private.
                            if let dict = snapshot.value as?  NSDictionary {
                                
                                let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                print(avatarStandard)
                                let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                print(avatarThumb)
                                let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                print(coverImageStandard)
                                let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                print(coverImageThumb)
                                
                                let bio                    = dict["bio"]                    as? String ?? ""
                                print(bio)
                                let gender                 = dict["gender"]                 as? String ?? ""
                                print(gender)
                                let interests              = dict["interests"]              as? String ?? ""
                                print(interests)
                                let name                   = dict["name"]                   as? String ?? ""
                                print(name)
                                let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                print(yearOfBirth)
                                let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                print(createdAt_public)
                                
                                DispatchQueue.main.async {
                                    
                                    //---------------------------------------------------------------------------
                                    //Cover Image DownLoad
                                    let downloader_cover_thumb = SDWebImageDownloader.shared()
                                    downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                        
                                        DispatchQueue.main.async{
                                            
                                            if image != nil {
                                                Temp_coverImageThumb_UI = image!
                                                coverImageThumb_UI      = image!
                                                
                                                
                                                let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                    
                                                    DispatchQueue.main.async{
                                                        
                                                        if image != nil {
                                                            //Temp_avatarThumb_UI     = image!
                                                            Temp_avatarThumb_UI     = Utils.profileImage(image: image!)
                                                            //avatarThumb_UI          = image!
                                                            avatarThumb_UI     = Utils.profileImage(image: image!)
                                                            
                                                            
                                                            //---------------------------------------------------------------------------
                                                            //these are urls
                                                            curProfileInfo.avatarStandard       = avatarStandard
                                                            curProfileInfo.avatarThumb          = avatarThumb
                                                            curProfileInfo.coverImageStandard   = coverImageStandard
                                                            curProfileInfo.coverImageThumb      = coverImageThumb
                                                            
                                                            //these are texts
                                                            curProfileInfo.bio                  = bio
                                                            curProfileInfo.gender               = gender
                                                            curProfileInfo.interests            = interests
                                                            curProfileInfo.name                 = name
                                                            curProfileInfo.yearOfBirth          = yearOfBirth
                                                            
                                                            let date = Date()
                                                            let calendar = Calendar.current
                                                            let year = calendar.component(.year, from: date)
                                                            
                                                            var yearOfBirth = curProfileInfo.yearOfBirth
                                                            let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                            yearOfBirth = yearOfBirth.substring(to: index)
                                                            print(yearOfBirth) // 2017
                                                            curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                            
                                                            initialDataLoaded_private = true
                                                            initialDataLoaded_public  = true
                                                            //----------------------------------------------------------------------------
                                                            
                                                            print("============== Success finished Loading ==============")
                                                            
                                                            for dlg in (self.navigationController?.viewControllers)! {
                                                                if dlg is HomeViewController {
                                                                    
                                                                    (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                    (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                    (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                }
                                                            }
                                                            
                                                            ProgressHUD.dismiss()
                                                            let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                                            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                                            
                                                            rearView.delegate = frontView
                                                            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                                            
                                                            self.navigationController?.pushViewController(swViewController!, animated: true)
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    })
                                }
                            }
                        } else {
                            
                            initialDataLoaded_private = true
                            initialDataLoaded_public = true
                            
                            //...................................
                            //Real First visit
                            Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                            Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                            //...................................
                            
                            
                            
                            g_NewProfileFlag_public = 0
                            print("public snapshot doesn't exists")
                            
                            ProgressHUD.dismiss()
                            
                            /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                             let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                             
                             rearView.delegate = frontView
                             let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                             
                             self.navigationController?.pushViewController(swViewController!, animated: true)*/
                            
                            self.performSegue(withIdentifier: StorySegues.FromEmailSigninToEditProfile.rawValue, sender: self)
                        }
                    }//if (initialDataLoaded_public)
                    else {
                        
                    }
                })
            }
        })
    }
    

}
