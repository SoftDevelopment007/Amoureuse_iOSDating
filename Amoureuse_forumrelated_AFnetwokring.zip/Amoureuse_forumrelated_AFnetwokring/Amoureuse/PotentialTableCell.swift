//
//  PotentialTableCell.swift
//  Amoureuse
//
//  Created by LEE on 4/6/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit

import ImageSlideshow

class PotentialTableCell: UITableViewCell {
    
    
    @IBOutlet weak var avatarButton: UIButton!
    @IBOutlet weak var coverImageView: UIImageView!
    
    @IBOutlet weak var textNameAgeLabel: UILabel!       //name, age
    @IBOutlet weak var textAboutLabel: UILabel!         //bio
    @IBOutlet weak var textInterestLabel: UILabel!      //interest   

    
    @IBOutlet weak var dislikeButton: UIButton!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var small_likeButton: UIButton!
    @IBOutlet weak var ExpandButton: UIButton!
    
    @IBOutlet weak var ExpandButton_1: UIButton!
    
    @IBOutlet weak var SlideShowCellButton: UIButton!
    
}
