	//
//  SignInController.swift
//  Amoureuse
//
//  Created by LEE on 3/4/17.
//  Copyright © 2017 LEE. All rights reserved.
//

    
import UIKit

import FBSDKCoreKit
import FBSDKLoginKit

import Firebase
import GoogleSignIn

import FirebaseAuth
import FirebaseDatabase
    
import FirebaseStorage
import SDWebImage
    
import ImageSlideshow

    
    
class SignInController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
        //Google
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        
        
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        //if Aleady Signed.............................................................................................
        let bSigned = UserDefaults.standard.bool(forKey: "Signed")
        if (bSigned) {
            
            //=========================================================
            //
            DownLoadSettings()
            
            DownLoadPictures()
            
            DownLoadProfiles()
            //
            //=========================================================
            
        } else {
        }        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //=============================================================================
    @IBAction func onTapEmailSigninButton(_ sender: Any) {
        
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.performSegue(withIdentifier: StorySegues.FromSigninToEmailSignin.rawValue, sender: self)
    }
    
    //=============================================================================
    @IBAction func onTapFacebookSigninButton(_ sender: Any) {
        
//        self.view.dodo.error("Coming Soon")
        
        FBSDKLoginManager().logIn(withReadPermissions: ["email", "public_profile"], from: self) { (result, err) in
            
            if err != nil {
                print("FB login failed: \(err)")
                return
            }
            
            self.showEmailAddress()
        }
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if error != nil {
            print(error)
            return
        }
        
        showEmailAddress()
    }
    
    func showEmailAddress() {
        
        let accessToken = FBSDKAccessToken.current()
        guard let accessTokenString = accessToken?.tokenString else { return }
        
        let credentials = FIRFacebookAuthProvider.credential(withAccessToken: accessTokenString)
        FIRAuth.auth()?.signIn(with: credentials, completion: { (user, error) in
            if error != nil {
                print("Something is wrong with FB user: \(error)")
            }
            
            print("successfully logged in with our user: \(user)")
            
        })

        
        
        //FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "email, id, name"]).start { (connection, result, err) in
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(normal), link"]).start { (connection, result, err) in
            
            if err != nil {
                print("failed to login: \(err)")
                return
            }
            
            print(result ?? "")
            
            //-----------------------------------------------------------
            let data:[String:AnyObject] = result as! [String : AnyObject]
            
            let userName : NSString? = data["name"]! as? NSString
            let facebookID : NSString? = data["id"]! as? NSString
            let firstName : NSString? = data["first_name"]! as? NSString
            let lastName : NSString? = data["last_name"]! as? NSString
            let email : NSString? = data["email"]! as? NSString
            
            print(userName!)
            print(facebookID!)
            print(firstName!)
            print(lastName!)
            print(email!)
            //----------------------------------------------------------
   
            //logout----------------------------------------------------
            /*if FBSDKAccessToken.current() != nil {
             let logout = FBSDKLoginManager()
             logout.logOut()
             }*/
            //----------------------------------------------------------
            
//            self.view.dodo.error(UserDialogs.FacebookSignOK.rawValue)
            
            /*let transition = CATransition()
            transition.duration = 0.3
            transition.type = "flip"
            transition.subtype = kCATransitionFromLeft
            self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
            
            
            //if At first Signed, Save Signed data.....................................................................
            UserDefaults.standard.set(true, forKey: "Signed")
            
            /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
            
            rearView.delegate = frontView
            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
            self.navigationController?.pushViewController(swViewController!, animated: true)
            
            //self.performSegue(withIdentifier: StorySegues.FromSigninToHomeWithoutAnim.rawValue, sender: self)*/
            
            //=========================================================
            //
            self.DownLoadSettings()
            
            self.DownLoadPictures()
            
            self.DownLoadProfiles()
            //
            //=========================================================

            
        }
    }
    
    //=============================================================================
    
    @IBAction func onTapGoogleSigninButton(_ sender: Any) {
//        self.view.dodo.error("Coming Soon")
        
        GIDSignIn.sharedInstance().signIn()
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let err = error {
            print("Failed to log in with Google: \(err)")
            return
        }
        print("Successfully logged in with Goodle: \(user)")
        
        guard let idToken = user.authentication.idToken else { return }
        guard let accessToken = user.authentication.accessToken else { return }
        let credentials = FIRGoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
        
        FIRAuth.auth()?.signIn(with: credentials, completion: { (user, error) in
            if let err = error {
                print("Failed to create a user with google sign in methond: \(err)")
                return
            }
            
            
            print("Successfully looged into Firebase with Google")
            
            
            print("------------------------- google infor ---------------------------")
            guard let uid = user?.uid else { return }
            let userName = user?.displayName
            let email = user?.email
            
            print(uid)
            print(userName!)
            print(email!)
            

//            self.view.dodo.error(UserDialogs.GoogleSignOK.rawValue)
            
            /*let transition = CATransition()
            transition.duration = 0.3
            transition.type = "flip"
            transition.subtype = kCATransitionFromLeft
            self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
            
            
            //if At first Signed, Save Signed data.....................................................................
            UserDefaults.standard.set(true, forKey: "Signed")

            
            //test code; to home page
            /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
            
            rearView.delegate = frontView
            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
            self.navigationController?.pushViewController(swViewController!, animated: true)*/
            
            //=========================================================
            //
            self.DownLoadSettings()
            
            self.DownLoadPictures()
            
            self.DownLoadProfiles()
            //
            //=========================================================
            
        })
    }


    
    
    //=======================================================================================================================================
    //
    //
    //
    //    DownLoads All Infor
    //
    //
    //=======================================================================================================================================
    func DownLoadProfiles() {
        
//        self.view.dodo.error("Coming Soon...")
        
        /*let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        
        //Check rigestered in firebase with profile before.........................................................
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        
        
        let Ref_private = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("private")
        let queryRef_private = Ref_private.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        let Ref_public = FIRDatabase.database().reference().child("profiles").child((user?.uid)!).child("public")
        let queryRef_public = Ref_public.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        
        ProgressHUD.show("Loading...")
        
        queryRef_private.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialDataLoaded_private) {
                if snapshot.exists() {
                    
                    initialDataLoaded_private = true
                    g_NewProfileFlag_private = 1
                    print("\((user?.uid)!) -- private snapshot exists")
                    
                    
                    //DownLoad private.
                    if let dict = snapshot.value as?  NSDictionary {
                        
                        let dob    = dict["dob"]         as? String ?? ""
                        print(dob)
                        let role   = dict["role"]        as? String ?? ""
                        print(role)
                        let createdAt_private    = dict["createdAt_private"]         as? String ?? ""
                        print(createdAt_private)
                        
                        
                        // Go back to the main thread to update the UI
                        DispatchQueue.main.async {
                            
                            //====================================================================================
                            curProfileInfo.dob                  = dob
                            curProfileInfo.role                 = role
                            
                            initialDataLoaded_private = true
                            //====================================================================================
                            
                            queryRef_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                                
                                if (!initialDataLoaded_public) {
                                    
                                    if snapshot.exists() {
                                        print("\((user?.uid)!) -- public snapshot exists")
                                        
                                        g_NewProfileFlag_public = 1
                                        //DownLoad private.
                                        if let dict = snapshot.value as?  NSDictionary {
                                          
                                            let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                            print(avatarStandard)
                                            let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                            print(avatarThumb)
                                            let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                            print(coverImageStandard)
                                            let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                            print(coverImageThumb)
                                            
                                            let bio                    = dict["bio"]                    as? String ?? ""
                                            print(bio)
                                            let gender                 = dict["gender"]                 as? String ?? ""
                                            print(gender)
                                            let interests              = dict["interests"]              as? String ?? ""
                                            print(interests)
                                            let name                   = dict["name"]                   as? String ?? ""
                                            print(name)
                                            let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                            print(yearOfBirth)
                                            let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                            print(createdAt_public)
                                            
                                                    DispatchQueue.main.async {
                                                        
                                                        //---------------------------------------------------------------------------
                                                        //Cover Image DownLoad
                                                        let downloader_cover_thumb = SDWebImageDownloader.shared()
                                                        downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                            
                                                            DispatchQueue.main.async{
                                                                
                                                                if image != nil {
                                                                    Temp_coverImageThumb_UI = image!
                                                                    coverImageThumb_UI      = image!
                                                                    
                                                                            let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                                            downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                                                
                                                                                DispatchQueue.main.async{
                                                                                    
                                                                                    if image != nil {
                                                                                        //Temp_avatarThumb_UI     = image!
                                                                                        Temp_avatarThumb_UI     = Utils.profileImage(image: image!)
                                                                                        //avatarThumb_UI          = image!
                                                                                        avatarThumb_UI     = Utils.profileImage(image: image!)
                                                                                        
                                                                                        //---------------------------------------------------------------------------
                                                                                        //these are urls
                                                                                        curProfileInfo.avatarStandard       = avatarStandard
                                                                                        curProfileInfo.avatarThumb          = avatarThumb
                                                                                        curProfileInfo.coverImageStandard   = coverImageStandard
                                                                                        curProfileInfo.coverImageThumb      = coverImageThumb
                                                                                        
                                                                                        //these are texts
                                                                                        curProfileInfo.bio                  = bio
                                                                                        curProfileInfo.gender               = gender
                                                                                        curProfileInfo.interests            = interests
                                                                                        curProfileInfo.name                 = name
                                                                                        curProfileInfo.yearOfBirth          = yearOfBirth
                                                                                        
                                                                                        let date = Date()
                                                                                        let calendar = Calendar.current
                                                                                        let year = calendar.component(.year, from: date)
                                                                                        
                                                                                        var yearOfBirth = curProfileInfo.yearOfBirth
                                                                                        let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                                                        yearOfBirth = yearOfBirth.substring(to: index)
                                                                                        print(yearOfBirth) // 2017
                                                                                        curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                                                        
                                                                                        initialDataLoaded_public = true
                                                                                        //----------------------------------------------------------------------------
                                                                                        
                                                                                        
                                                                                        print("============== Success finished Loading ==============")
                                                                                        
                                                                                        for dlg in (self.navigationController?.viewControllers)! {
                                                                                            if dlg is HomeViewController {
                                                                                                
                                                                                                (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                                                (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                                                (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                                            }
                                                                                        }
                                                                                        
                                                                                        ProgressHUD.dismiss()
                                                                                        
                                                                                        let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                                                                        let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                                                                        
                                                                                        rearView.delegate = frontView
                                                                                        let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                                                                        
                                                                                        self.navigationController?.pushViewController(swViewController!, animated: true)
                                                                                        
                                                                                    } else {
                                                                                        ProgressHUD.dismiss()
                                                                                    }
                                                                                }
                                                                            })
                                                                } else {
                                                                    ProgressHUD.dismiss()
                                                                }
                                                            }
                                                        })
                                                    }
                                        } else {
                                            ProgressHUD.dismiss()
                                        }
                                    } else {
                                        
                                        initialDataLoaded_public = true
                                        
                                        //...................................
                                        //Real First visit
                                        Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                                        Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                                        //...................................
                                        
                                        g_NewProfileFlag_public = 0
                                        print("public snapshot doesn't exists")
                                        
                                        ProgressHUD.dismiss()
                                        
                                        /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                         let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                         
                                         rearView.delegate = frontView
                                         let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                         
                                         self.navigationController?.pushViewController(swViewController!, animated: true)*/
                                        
                                        self.performSegue(withIdentifier: StorySegues.FromSigninToEditProfile.rawValue, sender: self)
                                    }
                                }//if (initialDataLoaded_public)
                                else {
                                    
                                }
                            })
                        }//private DispatchQueue.main.async
                    }//if let dict = snapshot.value as?  NSDictionary
                    
                } else {
                    
                    initialDataLoaded_private = true
                    
                    //...................................
                    //Real First visit
                    Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                    Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                    //...................................
                    
                    
                    g_NewProfileFlag_private = 0
                    print("private snapshot doesn't exists")
                    
                    ProgressHUD.dismiss()
                    
                    /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                     let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                     
                     rearView.delegate = frontView
                     let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                     
                     self.navigationController?.pushViewController(swViewController!, animated: true)*/
                    
                    self.performSegue(withIdentifier: StorySegues.FromSigninToEditProfile.rawValue, sender: self)
                }
            }//if (initialDataLoaded_private)
            else{
                queryRef_public.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
                    
                    if (!initialDataLoaded_public) {
                        
                        if snapshot.exists() {
                            print("public snapshot exists")
                            
                            g_NewProfileFlag_public = 1
                            //DownLoad private.
                            if let dict = snapshot.value as?  NSDictionary {
                                
                                let avatarStandard         = dict["avatarStandard"]         as? String ?? ""
                                print(avatarStandard)
                                let avatarThumb            = dict["avatarThumb"]            as? String ?? ""
                                print(avatarThumb)
                                let coverImageStandard     = dict["coverImageStandard"]     as? String ?? ""
                                print(coverImageStandard)
                                let coverImageThumb        = dict["coverImageThumb"]        as? String ?? ""
                                print(coverImageThumb)
                                
                                let bio                    = dict["bio"]                    as? String ?? ""
                                print(bio)
                                let gender                 = dict["gender"]                 as? String ?? ""
                                print(gender)
                                let interests              = dict["interests"]              as? String ?? ""
                                print(interests)
                                let name                   = dict["name"]                   as? String ?? ""
                                print(name)
                                let yearOfBirth            = dict["yearOfBirth"]            as? String ?? ""
                                print(yearOfBirth)
                                let createdAt_public       = dict["createdAt_public"]       as? String ?? ""
                                print(createdAt_public)
                                
                                DispatchQueue.main.async {
                                    
                                    //---------------------------------------------------------------------------
                                    //Cover Image DownLoad
                                    let downloader_cover_thumb = SDWebImageDownloader.shared()
                                    downloader_cover_thumb.downloadImage(with: NSURL(string: coverImageThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                        
                                        DispatchQueue.main.async{
                                            
                                            if image != nil {
                                                Temp_coverImageThumb_UI = image!
                                                coverImageThumb_UI      = image!
                                                
                                                
                                                let downloader_avatar_thumb = SDWebImageDownloader.shared()
                                                downloader_avatar_thumb.downloadImage(with: NSURL(string: avatarThumb)! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                                    
                                                    DispatchQueue.main.async{
                                                        
                                                        if image != nil {
                                                            //Temp_avatarThumb_UI     = image!
                                                            Temp_avatarThumb_UI     = Utils.profileImage(image: image!)
                                                            //avatarThumb_UI          = image!
                                                            avatarThumb_UI     = Utils.profileImage(image: image!)
                                                            
                                                            
                                                            //---------------------------------------------------------------------------
                                                            //these are urls
                                                            curProfileInfo.avatarStandard       = avatarStandard
                                                            curProfileInfo.avatarThumb          = avatarThumb
                                                            curProfileInfo.coverImageStandard   = coverImageStandard
                                                            curProfileInfo.coverImageThumb      = coverImageThumb
                                                            
                                                            //these are texts
                                                            curProfileInfo.bio                  = bio
                                                            curProfileInfo.gender               = gender
                                                            curProfileInfo.interests            = interests
                                                            curProfileInfo.name                 = name
                                                            curProfileInfo.yearOfBirth          = yearOfBirth
                                                            
                                                            let date = Date()
                                                            let calendar = Calendar.current
                                                            let year = calendar.component(.year, from: date)
                                                            
                                                            var yearOfBirth = curProfileInfo.yearOfBirth
                                                            let index = yearOfBirth.index((yearOfBirth.startIndex), offsetBy: 4)
                                                            yearOfBirth = yearOfBirth.substring(to: index)
                                                            print(yearOfBirth) // 2017
                                                            curProfileInfo.title = "\(curProfileInfo.name), \(String(Int(year) - Int(yearOfBirth)!))"
                                                            
                                                            initialDataLoaded_public = true
                                                            //----------------------------------------------------------------------------
                                                            
                                                            print("============== Success finished Loading ==============")
                                                            
                                                            for dlg in (self.navigationController?.viewControllers)! {
                                                                if dlg is HomeViewController {
                                                                    
                                                                    (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.title
                                                                    (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
                                                                    (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
                                                                }
                                                            }
                                                            
                                                            ProgressHUD.dismiss()
                                                            let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                                                            let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                                                            
                                                            rearView.delegate = frontView
                                                            let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                                                            
                                                            self.navigationController?.pushViewController(swViewController!, animated: true)
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    })
                                }
                            }
                        } else {
                            
                            initialDataLoaded_private = true
                            initialDataLoaded_public = true
                            
                            //...................................
                            //Real First visit
                            Temp_avatarThumb_UI = #imageLiteral(resourceName: "photo6")
                            Temp_coverImageThumb_UI = #imageLiteral(resourceName: "photo6")
                            //...................................
                            
                            
                            
                            g_NewProfileFlag_public = 0
                            print("public snapshot doesn't exists")
                            
                            ProgressHUD.dismiss()
                            
                            /*let frontView = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerVC") as! HomeViewController
                             let rearView = self.storyboard?.instantiateViewController(withIdentifier: "sideView") as! adminSideMenu
                             
                             rearView.delegate = frontView
                             let swViewController = SWRevealViewController(rearViewController: rearView, frontViewController: frontView)
                             
                             self.navigationController?.pushViewController(swViewController!, animated: true)*/
                            
                            self.performSegue(withIdentifier: StorySegues.FromSigninToEditProfile.rawValue, sender: self)
                        }
                    }//if (initialDataLoaded_public)
                    else {
                        
                    }
                })
            }
        })
    }
    
    func DownLoadPictures() {
        
        let user = FIRAuth.auth()?.currentUser
        //print(user?.email)
        //print(user?.uid)
        
        let Ref_GridPictures = FIRDatabase.database().reference().child("gridPictures").child((user?.uid)!) //.child("thumb")
        //let queryRef_GridPictures = Ref_GridPictures.queryOrdered(byChild: "createdAt").queryLimited(toLast: 25)
        
        
        Ref_GridPictures.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialGridPictures) {
                
                initialGridPictures = true
                
                if snapshot.exists() {
                    print("\((user?.uid)!) --- GridPictures exists")
                    print(snapshot.childrenCount)
                    
                    if let dict = snapshot.value as?  NSDictionary {
                        print(dict)
                        
                        
                        //let thumb_dict = dict["1"] as! [String: AnyObject]
                        let thumb_dict = dict["thumb"] as! Array<String>
                        print(thumb_dict)
                        print(thumb_dict.count)
                        
                        DispatchQueue.main.async {
                            
                            for i in 0 ... thumb_dict.count - 1 {
                                print("===================== \(i) ====================")
                                print(thumb_dict[Int(i)])
                                
                                //-------------------------------------------------------
                                DispatchQueue.main.async {
                                    
                                    //Grid Image DownLoad
                                    let downloader = SDWebImageDownloader.shared()
                                    downloader.downloadImage(with: NSURL(string: thumb_dict[Int(i)])! as URL, options: [], progress: nil, completed: { (image, data, error, finished) in
                                        
                                        DispatchQueue.main.async{
                                            
                                            if image != nil {
                                                g_gridImage.append(image!)
                                                g_localSource.append(ImageSource(image: image!))
                                                
                                                //initialGridPictures = true
                                            }
                                        }
                                    })
                                }
                                //-------------------------------------------------------
                            }
                        }
                        
                        
                    } else {
                        
                        print("Not --- if let dict = snapshot.value as?  NSDictionary {")
                    }
                }
                else {
                    print("\((user?.uid)!) --- GridPictures doesn't exists")
                    
                }
            }
        })
        
    }
    
    func DownLoadSettings() {
        
        let user = FIRAuth.auth()?.currentUser
        print(user?.email)
        print(user?.uid)
        
        let Ref_SearchingUsers = FIRDatabase.database().reference().child("searchingUsers").child((user?.uid)!)
        
        Ref_SearchingUsers.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if (!initialSearchingUsers) {
                
                if snapshot.exists() {
                    print("\((user?.uid)!) --- Settings exists")
                    print(snapshot.childrenCount)
                    
                    if let dict = snapshot.value as?  NSDictionary {
                        print(dict)
                        
                        /*if let dict = snapshot.value as?  NSDictionary {
                         let avatarStandard         = dict["avatarStandard"]         as? String ?? ""*/
                        
                        //==========================================================
                        DispatchQueue.main.async {
                            
                            let age_dict = dict["age"] as? NSDictionary
                            g_age_maximum = (age_dict?["maximum"] as? Int)!
                            g_age_minimum = (age_dict?["minimum"] as? Int)!
                            
                            g_gender = (dict["gender"] as? Int)!
                            g_maxDistance = (dict["maxDistance"] as? Int)!
                            
                            initialSearchingUsers = true
                            
                        }
                        //==========================================================
                        
                    } else {
                        
                        print("Not --- if let dict = snapshot.value as?  NSDictionary {")
                    }
                }
                else {
                    print("\((user?.uid)!) --- Settings doesn't exists")
                }
            }
        })
        
    }


}
