//
//  ChatsListViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/8/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit

import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import SDWebImage





class ChatsListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    private let kTimeoutInSeconds: TimeInterval = 60
    private var timer: Timer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        tableView.tableHeaderView = UIView()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        ///////////////////////////////////////////////////////////////////////////////////////
        //
        DownLoadChatList()
        
        startFetching()
        //
        ///////////////////////////////////////////////////////////////////////////////////////
    }

    func startFetching() {
        self.timer = Timer.scheduledTimer(timeInterval: kTimeoutInSeconds,
                                          target:self,
                                          selector:Selector("fetch"),
                                          userInfo:nil,
                                          repeats:true)
    }
    func stopFetching() {
        self.timer!.invalidate()
    }
    func fetch() {
        print("Fetch called!")
        
        self.tableView.reloadData()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    //=========================================================================================
    //
    //  Table Delegates
    //
    //=========================================================================================
    
    func initView() {
        tableView.reloadData()
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return g_ChatList_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatListTableCell") as? ChatListTableCell
        
        
        cell?.avatarButton.setBackgroundImage(g_ChatList_Array[indexPath.row].avatarImage, for: .normal)
        
        cell?.textNameLabel.text        = g_ChatList_Array[indexPath.row].name
        cell?.textLastMessageLabel.text = g_ChatList_Array[indexPath.row].lastMessage
        
        //Show Sent Time
        let date = g_ChatList_Array[indexPath.row].time  //NSDate()
        var dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        var dateString = dateFormatter.string(from: date)
        print(dateString)
        //cell?.textTimeLabel.text        = dateString
        
        //Show Sent Difference "A mins ago"
        dateString                  = self.timeElapsed(date: date)
        cell?.textTimeLabel.text    = dateString
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: IndexPath(row: indexPath.row, section: 0)) as? MatchedUserTableCell
        
        
        /*for dlg in (self.navigationController?.viewControllers)! {
         if dlg is HomeViewController {
         
         (dlg as! HomeViewController).textNameLabel.text = curProfileInfo.name
         (dlg as! HomeViewController).textAboutLabel.text = curProfileInfo.bio
         (dlg as! HomeViewController).textInterestLabel.text = curProfileInfo.interests
         }
         }*/
        
        g_ChatList_index = indexPath.row
        
        temp_avatarImage = g_ChatList_Array[g_ChatList_index].avatarImage
        temp_title       = g_ChatList_Array[g_ChatList_index].name
        temp_name        = g_ChatList_Array[g_ChatList_index].name
        temp_uid         = g_ChatList_Array[g_ChatList_index].uid
        
        self.performSegue(withIdentifier: StorySegues.FromChatListToChatView.rawValue, sender: self)
        
        
        ///*ProgressHUD.show("Loading...")
        // DownLoadPictures(index: indexPath.row, completion: {
         
        // g_Potential_index = indexPath.row
        // self.performSegue(withIdentifier: StorySegues.FromPotentialToDetail.rawValue, sender: self)
         
        // ProgressHUD.dismiss()
        // })*/
        
    }
    
    /*
    // MARK: - Navigation

     
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onTappedBackButton(_ sender: Any) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.type = "flip"
        transition.subtype = kCATransitionFromLeft
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.popViewController(animated: true)
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // DownLoad ChatList
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    //var success: Bool = false
    
    func DownLoadChatList() {
        
        //self.success = false
        
        g_ChatList_Array.removeAll()
        g_ChatList_index = -1
        
        
        
        //var FlagCnt_1: Int = 0
        var Temp_ChatList: ChatListInfo = ChatListInfo(name: "", lastMessage: "", time: Date(), avatarImage: #imageLiteral(resourceName: "profile.png"), uid: "")
        
        let user = FIRAuth.auth()?.currentUser
        
        let Ref_locations = FIRDatabase.database().reference().child("locations")
        Ref_locations.observe(.childAdded, with: { (snapshot: FIRDataSnapshot!) in
            
            if snapshot.exists() {
                
                let uid = snapshot.key //the uid of each user
                print(uid)
                print("location snapshot exists")
                
                var TempCNT: Int = 0
                let Ref_chatheader = FIRDatabase.database().reference().child("channelHeaders").child((user?.uid)!).child(uid)
                Ref_chatheader.observe(.childAdded, with: { (snapshot_chatheader: FIRDataSnapshot!) in
                    
                    if snapshot_chatheader.exists() {
                        
                        print(snapshot_chatheader)
                        print("Ref_chatheader snapshot exists")
                        
                        TempCNT = TempCNT + 1
                        if TempCNT == 1 {
                            
                                let Message_Ref = FIRDatabase.database().reference().child("conversations").child((user?.uid)!).child(uid)
                                Message_Ref.queryOrdered(byChild: "updatedAt").queryLimited(toLast : 1).observe(.childAdded, with: { snapshot_conversasion in
                                    //Message_Ref.observe(.childAdded , with: { snapshot_conversasion in
                                    
                                    if snapshot_conversasion.exists() {
                                        
                                        print("Message_Ref snapshot exists")
                                        
                                        if let dict_conversations  =  snapshot_conversasion.value  as?  [String: AnyObject] {
                                            
                                            let Ref_Profiles_uid = FIRDatabase.database().reference().child("profiles").child(uid).child("public")
                                            Ref_Profiles_uid.observe(.value, with: { (public_snapshot: FIRDataSnapshot!) in
                                                
                                                //DownLoad public.
                                                if let public_dict = public_snapshot.value as? [String: AnyObject] {
                                                    
                                                    let avatarUrl   = public_dict["avatarThumb"]        as? String ?? ""
                                                    let name        = public_dict["name"]               as? String ?? ""
                                                    
                                                    let downloader_avatar = SDWebImageDownloader.shared()
                                                    downloader_avatar.downloadImage(with: NSURL(string: avatarUrl)! as URL, options: [], progress: nil, completed: { (image_avatar, data, error, finished) in
                                                        
                                                        if error != nil {
                                                            
                                                            print("some error!")
                                                        } else {
                                                            
                                                            DispatchQueue.main.async{
                                                                
                                                                if image_avatar != nil {
                                                                    
                                                                    let updatedAt = dict_conversations["updatedAt"] as! Double
                                                                    print(updatedAt)
                                                                    
                                                                    let dateTimeStamp = NSDate(timeIntervalSince1970:Double(updatedAt)/1000)  //UTC time
                                                                    
                                                                    let dateFormatter = DateFormatter()
                                                                    dateFormatter.timeZone = NSTimeZone.local //Edit
                                                                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
                                                                    let strDateSelect = dateFormatter.string(from: dateTimeStamp as Date)
                                                                    print(strDateSelect) //Local time
                                                                    
                                                                    let formatter = DateFormatter()
                                                                    formatter.dateFormat = "yyyy/MM/dd HH:mm"
                                                                    let someDateTime = formatter.date(from: strDateSelect)
                                                                    
                                                                    let text = dict_conversations["message"] as! String
                                                                    
                                                                    Temp_ChatList.lastMessage = text
                                                                    Temp_ChatList.time        = someDateTime!
                                                                    Temp_ChatList.uid         = uid
                                                                    Temp_ChatList.name        = name
                                                                    Temp_ChatList.avatarImage = Utils.profileImage(image: image_avatar!)
                                                                    
                                                                    print(uid)
                                                                    print(Temp_ChatList)
                                                                    
                                                                    //========================================
                                                                    
                                                                    if g_ChatList_Array.count < 1 {
                                                                        
                                                                        g_ChatList_Array.append(Temp_ChatList)
                                                                        g_ChatList_index = g_ChatList_Array.count // - 1
                                                                        
                                                                        self.tableView.reloadData()
                                                                        //self.success = true
                                                                        //completion()
                                                                        
                                                                    } else {
                                                                        if let search_index = g_ChatList_Array.index(where: {$0.uid == temp_uid}) {
                                                                            
                                                                            g_ChatList_Array[search_index] = Temp_ChatList
                                                                            g_ChatList_index = g_ChatList_Array.count // - 1
                                                                            
                                                                            self.tableView.reloadData()
                                                                            //self.success = true
                                                                            //completion()
                                                                            
                                                                        } else {
                                                                            
                                                                            g_ChatList_Array.append(Temp_ChatList)
                                                                            g_ChatList_index = g_ChatList_Array.count // - 1
                                                                            
                                                                            self.tableView.reloadData()
                                                                            //self.success = true
                                                                            //completion()
                                                                        }
                                                                    }
                                                                    
                                                                }
                                                            }
                                                        }
                                                        
                                                    })
                                                }
                                            })
                                        }
                                    }
                                })
                        }
                    }
                })
            }
        })
        
    }
    
    func timeElapsed(date: Date) -> String {
        
        let date1:Date = date
        let date2: Date = Date() // Same you did before with timeNow variable
        
        let calender:Calendar = Calendar.current
        let components: DateComponents = calender.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date1, to: date2)
        print(components)
        var returnString:String = ""
        
        print(components.second!)
        
        if components.second! < 60 {
            returnString = "Just Now"
        }
        
        if components.minute! > 1{
            returnString = String(describing: components.minute!) + " mins ago"
        }
        else if components.minute! == 1 {
            
            returnString = "A minute ago"
        }
        
        if components.hour! > 1{
            returnString = String(describing: components.hour!) + " hours ago"
        }
        else if components.hour == 1 {
            
            returnString = "An hour ago"
        }
        
        if components.day! > 1{
            returnString = String(describing: components.day!) + " days ago"
        }
        else if components.day! == 1 {
            
            returnString = "Yesterday"
        }
        
        if components.month! > 1{
            returnString = String(describing: components.month!)+" months ago"
        }
        else if components.month! == 1 {
            
            returnString = "A month ago"
        }
        
        if components.year! > 1 {
            returnString = String(describing: components.year!)+" years ago"
        }
        else if components.year! == 1 {
            
            returnString = "A year ago"
        }
        
        return returnString
    }
    
    
}
