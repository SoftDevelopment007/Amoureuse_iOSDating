//
//  SettingsViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/5/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import SwiftRangeSlider

import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth


class SettingsViewController: UIViewController {
    
    
    @IBOutlet weak var rangeSlider: RangeSlider!
    
    @IBOutlet weak var sliderDistance: UISlider!
    @IBOutlet weak var textDistanceLabel: UILabel!
    
    
    @IBOutlet weak var myMaleSwitch: UISwitch!
    @IBOutlet weak var myFemaleSwitch: UISwitch!
    
    @IBOutlet weak var textAgeLabel: UILabel!
    
    
    var gender: Int = 0
    var maxDistance: Int = 0
    var age_maximum: Int = 0
    var age_minimum: Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateLabels_Distance(nV: Int(sliderDistance.value))
        
        sliderDistance.addTarget (self,
                          action: #selector(DistanceValueChanged),
            for: UIControlEvents.valueChanged)
            
        rangeSlider.addTarget(self, action: #selector(SettingsViewController.rangeSliderValueChanged(_:)), for: .valueChanged)
        
        myMaleSwitch.addTarget(self, action: #selector(SettingsViewController.MaleSwitchIsChanged(_:)), for: UIControlEvents.valueChanged)
        myFemaleSwitch.addTarget(self, action: #selector(SettingsViewController.FemaleSwitchIsChanged(_:)), for: UIControlEvents.valueChanged)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        Init_Settings()
    }
    
    func DistanceValueChanged(sender: UISlider) {
        
        sliderDistance.setValue(Float(Int(sliderDistance.value)), animated: true)
        
        updateLabels_Distance(nV: Int(sliderDistance.value))
    }
    /*func updateLabels(nV: Float?) {
        if let v = nV {
            self.textDistanceLabel.text = "\(v)"
        }
    }*/
    func updateLabels_Distance(nV: Int?) {
        if let v = nV {
            self.textDistanceLabel.text = "\(v)km"
        }
    }
    
    
    
    func updateLabels_Age(nV_min: Int?, nV_max: Int? ) {
        
        if nV_min == nV_max {
            if nV_max == 56 {
                self.textAgeLabel.text = "\(nV_max!)+"
            } else {
                self.textAgeLabel.text = "\(nV_max!)"
            }
            
        } else {
            if nV_max == 56 {
                self.textAgeLabel.text = "\(nV_min!) - \(nV_max!)+"
            } else {
                self.textAgeLabel.text = "\(nV_min!) - \(nV_max!)"
            }
        }
    }
    
    func rangeSliderValueChanged(_ rangeSlider: RangeSlider) {
        print("Range slider value changed: (\(rangeSlider.lowerValue) , \(rangeSlider.upperValue))")
        
        updateLabels_Age(nV_min: Int(rangeSlider.lowerValue * 10.0), nV_max: Int(rangeSlider.upperValue * 10.0))
        
    }

    //==============================================================================
    func Init_Settings() {
        
        maxDistance = g_maxDistance
        gender = g_gender
        age_minimum = g_age_minimum
        age_maximum = g_age_maximum
        
        
        sliderDistance.setValue(Float(g_maxDistance), animated: true)
        updateLabels_Distance(nV: g_maxDistance)
        
        if g_gender == 1 {
            myMaleSwitch.setOn(true, animated: true)
            myFemaleSwitch.setOn(false, animated: true)
        }
        if g_gender == 2 {
            myMaleSwitch.setOn(false, animated: true)
            myFemaleSwitch.setOn(true, animated: true)
        }
        if g_gender == 3 {
            myMaleSwitch.setOn(true, animated: true)
            myFemaleSwitch.setOn(true, animated: true)
        }
        
        rangeSlider.lowerValue = Double(g_age_minimum) / 10.0
        
        if g_age_maximum > 55 {
            rangeSlider.upperValue = 5.6
        } else {
            rangeSlider.upperValue = Double(g_age_maximum) / 10.0
        }
        updateLabels_Age(nV_min: Int(rangeSlider.lowerValue * 10.0), nV_max: Int(rangeSlider.upperValue * 10.0))
        
    }
    
    //==============================================================================
    func Detect_AllStatus() {
        
        //-----------------------------------------
        maxDistance = Int(sliderDistance.value)
        
        //-----------------------------------------
        if myMaleSwitch.isOn {
            
            if myFemaleSwitch.isOn{
                gender = 3
            } else {
                gender = 1
            }
            
        } else {
            if myFemaleSwitch.isOn{
                gender = 2
            } else {
                gender = 0
                print("============== This is gender setting Error =============")
            }
        }
        
        //-----------------------------------------
        age_minimum = Int(rangeSlider.lowerValue * 10.0)
        
        if Int(rangeSlider.upperValue * 10.0) == 56 {
            age_maximum = 60
        } else {
            age_maximum = Int(rangeSlider.upperValue * 10.0)
        }
        
    }
    
    func MaleSwitchIsChanged(_ myMaleSwitch: UISwitch) {
        if myMaleSwitch.isOn {
            print("myMaleSwitch is ON")
        } else {
            print("myMaleSwitch is OFF")
            
            if myFemaleSwitch.isOn{
            } else {
                myFemaleSwitch.setOn(true, animated: true)
            }
        }
    }
    func FemaleSwitchIsChanged(_ myFemaleSwitch: UISwitch) {
        if myFemaleSwitch.isOn {
            print("myFemaleSwitch is ON")
        } else {
            print("myFemaleSwitch is OFF")
            
            if myMaleSwitch.isOn{
            } else {
                myMaleSwitch.setOn(true, animated: true)
            }
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onTapBackButton(_ sender: Any) {
        
        Detect_AllStatus()
        
        g_maxDistance = maxDistance
        g_gender = gender
        g_age_minimum = age_minimum
        g_age_maximum = age_maximum
        
        //===========================================================
        //
        UpLoadSettings()
        //
        //===========================================================
        
        self.navigationController?.popViewController(animated: true)
    }
    
   
    func UpLoadSettings() {
        let user = FIRAuth.auth()?.currentUser
        let newMessage_searchingUsers = FIRDatabase.database().reference().child("searchingUsers").child((user?.uid)!)
        
        newMessage_searchingUsers.removeValue()
        
        let messageData =
            
            [
                "age":
                                [
                                    "maximum": g_age_maximum,
                                    "minimum": g_age_minimum
                                ],
             
                "gender":      g_gender,
             
                "maxDistance": g_maxDistance
                
            ] as [String : Any]
        
        
        newMessage_searchingUsers.setValue(messageData)
    }
    

}
