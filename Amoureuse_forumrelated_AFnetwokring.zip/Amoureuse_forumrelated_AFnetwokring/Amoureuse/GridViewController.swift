//
//  GridViewController.swift
//  Amoureuse
//
//  Created by LEE on 4/4/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import UIKit
import ImageSlideshow


class GridViewController: UIViewController, WDImagePickerDelegate, UIImagePickerControllerDelegate {

    
    //WDImagePicker
    var imagePicker: WDImagePicker!
    
    var gridImages = [UIImage]()
    var showIcon = [UIImage]()
    //var grid_index: Int = 0
    
    //var delete_index = [Int]()
    
    var total_selection: Int = 0
    
    
    @IBOutlet weak var gridImage1: UIImageView!
    @IBOutlet weak var showIcon1: UIImageView!
    @IBOutlet weak var gridImage2: UIImageView!
    @IBOutlet weak var showIcon2: UIImageView!
    @IBOutlet weak var gridImage3: UIImageView!
    @IBOutlet weak var showIcon3: UIImageView!
    @IBOutlet weak var gridImage4: UIImageView!
    @IBOutlet weak var showIcon4: UIImageView!
    @IBOutlet weak var gridImage5: UIImageView!
    @IBOutlet weak var showIcon5: UIImageView!
    @IBOutlet weak var gridImage6: UIImageView!
    @IBOutlet weak var showIcon6: UIImageView!
    
    
    //background
    @IBOutlet weak var iconGridImage: UIImageView!
    @IBOutlet weak var textNoPhoto: UILabel!
    
    //Red title bar - selection count
    @IBOutlet weak var textSelectionCount: UILabel!
    
    @IBOutlet weak var btnBackCancel: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    
    
    @IBOutlet weak var btnBackCancel_1: UIButton!
    @IBOutlet weak var btnDelete_1: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        
        InitRefresh()
        ShowRefresh()
        show_selection()
        
    }

    override func viewWillAppear(_ animated: Bool) {
//        InitRefresh()
//        ShowRefresh()
//        show_selection()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func InitRefresh() {
        
        if g_gridImage.count > 0 {
            
            for i in 0 ... g_gridImage.count - 1 {
                
                gridImages.append(g_gridImage[i])
                showIcon.append(#imageLiteral(resourceName: "btn_selection_check_none.png"))
            }
            
        }
    }

    
    func ShowRefresh() {
        
        if gridImages.count > 0 {
            
            iconGridImage.isHidden = true
            textNoPhoto.isHidden = true
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
            showIcon1.image = nil
            showIcon2.image = nil
            showIcon3.image = nil
            showIcon4.image = nil
            showIcon5.image = nil
            showIcon6.image = nil
            
            
            for i in 0 ... gridImages.count - 1 {
                
                if i == 0 {
                    gridImage1.image = gridImages[0]
                    showIcon1.image = showIcon[0]
                }
                if i == 1 {
                    gridImage2.image = gridImages[1]
                    showIcon2.image = showIcon[1]
                }
                if i == 2 {
                    gridImage3.image = gridImages[2]
                    showIcon3.image = showIcon[2]
                }
                if i == 3 {
                    gridImage4.image = gridImages[3]
                    showIcon4.image = showIcon[3]
                }
                if i == 4 {
                    gridImage5.image = gridImages[4]
                    showIcon5.image = showIcon[4]
                }
                if i == 5 {
                    gridImage6.image = gridImages[5]
                    showIcon6.image = showIcon[5]
                }
            }
            
        } else {
            iconGridImage.isHidden = false
            textNoPhoto.isHidden = false
            
            gridImage1.image = nil
            gridImage2.image = nil
            gridImage3.image = nil
            gridImage4.image = nil
            gridImage5.image = nil
            gridImage6.image = nil
            
            showIcon1.image = nil
            showIcon2.image = nil
            showIcon3.image = nil
            showIcon4.image = nil
            showIcon5.image = nil
            showIcon6.image = nil
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func onTappedBackButton(_ sender: Any) {
        if total_selection == 0 {
            
                g_gridImage.removeAll()
                g_localSource.removeAll()
            
                if gridImages.count > 0 {
                    for i in 0 ... gridImages.count - 1 {
                        g_gridImage.append(gridImages[i])
                        
                        g_localSource.append(ImageSource(image: gridImages[i]))
                        //g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "btn_selection_check_full.png"))!)
                        
                        //ImageSource.init(image: gridImages[i])
                    }
                }
            
                gridImages.removeAll()
                showIcon.removeAll()
            
                ShowRefresh()
                show_selection()
            
                self.navigationController?.popViewController(animated: true)
            
        } else {
            
                total_selection = 0
                for i in 0 ... gridImages.count - 1 {
                    self.showIcon[i] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none
                }
                ShowRefresh()
                show_selection()
        }
        
    }
    
    @IBAction func onTappedPlusButton(_ sender: Any) {
        
        if gridImages.count < 6 {
            
            imagePicker = WDImagePicker()
            imagePicker.cropSize = CGSize(width: 280, height: 200)
            imagePicker.delegate = self
            let alert = UIAlertController(title: "Options", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:{
                action in
                self.imagePicker.imagePickerController.sourceType = .camera
                self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
            }))
            alert.addAction(UIAlertAction(title: "PhotoLibary", style: .default, handler: {
                action in
                self.imagePicker.imagePickerController.sourceType = .photoLibrary
                self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)

        } else {
            self.view.dodo.error("You can add only 6th images.")
        }
        
    }
    
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        
        if gridImages.count < 6 {
            self.gridImages.append(self.imageWithImage(image: pickedImage, newSize: CGSize(width: 80, height: 80)))
            //self.gridImages.append(pickedImage)
            self.showIcon.append(#imageLiteral(resourceName: "btn_selection_check_none.png"))
            print(gridImages.count)
            
            ShowRefresh()
        }
        
        
        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            //self.avatarImage.image = image
            
            //-------------------------------------------------------
            //self.gridImage1.image = Utils.imageWithImage(image: image, newSize: CGSize(width: 80, height: 80))
            //self.showIcon1.image = #imageLiteral(resourceName: "btn_selection_check_full.png") //btn_selection_check_full
            //-------------------------------------------------------
            //self.showIcon1.image = #imageLiteral(resourceName: "btn_selection_check_none.png")
            
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    func show_selection(){
        
        if total_selection > 0 {
            var str_section = "Selection ("
            str_section = str_section + String(total_selection)
            str_section = str_section + ")"
            
            textSelectionCount.text = str_section
            
            /*btnBackCancel.setBackgroundImage(#imageLiteral(resourceName: "btn_selection_cancel.png"), for: .normal) //btn_selection_cancel
            btnDelete.setBackgroundImage(#imageLiteral(resourceName: "btn_selection_delete.png"), for: .normal) //btn_selection_delete*/
            btnBackCancel_1.setBackgroundImage(#imageLiteral(resourceName: "btn_selection_cancel.png"), for: .normal) //btn_selection_cancel
            btnDelete_1.setBackgroundImage(#imageLiteral(resourceName: "btn_selection_delete.png"), for: .normal) //btn_selection_delete

        } else {
            
            textSelectionCount.text = "Grid Images"
            
            /*btnBackCancel.setBackgroundImage(#imageLiteral(resourceName: "menu_icon_left.png"), for: .normal) //menu_icon_left
            btnDelete.setBackgroundImage(nil, for: .normal) //btn_selection_delete*/
            btnBackCancel_1.setBackgroundImage(#imageLiteral(resourceName: "menu_icon_left.png"), for: .normal) //menu_icon_left
            btnDelete_1.setBackgroundImage(nil, for: .normal) //btn_selection_delete
        }
    }
    
    
    //---------------------------------------------------
    @IBAction func onTappedImage1(_ sender: Any) {
        
        if gridImages.count < 1 {
            return
        }
        
        if self.showIcon1.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[0] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[0] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }
    
    @IBAction func onTappedImage2(_ sender: Any) {
        if gridImages.count < 2 {
            return
        }
        
        if self.showIcon2.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[1] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none....
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[1] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection....
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }
    
    @IBAction func onTappedImage3(_ sender: Any) {
        if gridImages.count < 3 {
            return
        }
        
        if self.showIcon3.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[2] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none....
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[2] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection....
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }
    
    @IBAction func onTappedImage4(_ sender: Any) {
        if gridImages.count < 4 {
            return
        }
        
        if self.showIcon4.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[3] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none....
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[3] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection....
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }

    @IBAction func onTappedImage5(_ sender: Any) {
        if gridImages.count < 5 {
            return
        }
        
        if self.showIcon5.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[4] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none....
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[4] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection....
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }

    @IBAction func onTappedImage6(_ sender: Any) {
        
        print(gridImages.count)
        
        if gridImages.count < 6 {
            return
        }
        
        if self.showIcon6.image == #imageLiteral(resourceName: "btn_selection_check_full.png") {
            
            self.showIcon[5] = #imageLiteral(resourceName: "btn_selection_check_none.png") // none....
            ShowRefresh()
            
            if  total_selection == 0 {
                
            } else {
                total_selection = total_selection - 1
                
                show_selection()
            }
            
        } else {
            
            self.showIcon[5] = #imageLiteral(resourceName: "btn_selection_check_full.png") //selection....
            ShowRefresh()
            
            total_selection = total_selection + 1
            
            show_selection()
        }
    }
    
    @IBAction func onTappedDelete(_ sender: Any) {
        
        if total_selection == 0 {
            return
        }
        
        var Temp_gridImages = [UIImage]()
        var Temp_showIcon = [UIImage]()
        
        
        for i in 0 ... gridImages.count - 1 {
            
            //var gridImages = [UIImage]()
            //var showIcon = [UIImage]()

            
            if showIcon[i] == #imageLiteral(resourceName: "btn_selection_check_full.png") { //btn_selection_check_full.png
                
            }
            
            if showIcon[i] == #imageLiteral(resourceName: "btn_selection_check_none.png") { //btn_selection_check_none.png
                Temp_gridImages.append(gridImages[i])
                Temp_showIcon.append(#imageLiteral(resourceName: "btn_selection_check_none.png"))
            }
        }
        gridImages.removeAll()
        showIcon.removeAll()
        
        if Temp_gridImages.count > 0 {
            for i in 0 ... Temp_gridImages.count - 1 {
                
                gridImages.append(Temp_gridImages[i])
                showIcon.append(#imageLiteral(resourceName: "btn_selection_check_none.png"))
            }
            Temp_gridImages.removeAll()
            Temp_showIcon.removeAll()
        }
        
        total_selection = 0
        ShowRefresh()
        show_selection()
        
    }
    

}
